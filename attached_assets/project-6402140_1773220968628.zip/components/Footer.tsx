import Link from 'next/link';

export default function Footer() {
  const currentYear = new Date().getFullYear();
  
  return (
    <footer className="bg-[#ad023b] text-white py-16">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div>
            <img 
              alt="Grupo Avisa" 
              className="h-10 mb-6 brightness-0 invert" 
              src="https://static.readdy.ai/image/ecd9e0a88a19846633f9ef23a8543c57/f5a8ff11b436d5f4b52bda2d56dcfaf6.webp"
            />
            <p className="text-white/90 text-sm leading-relaxed mb-4">
              Concesionario oficial líder en vehículos eléctricos e híbridos enchufables. Tu partner en movilidad sostenible.
            </p>
            <div className="space-y-2 text-sm">
              <a href="tel:955034600" className="flex items-center gap-2 hover:text-white/80 transition-colors">
                <i className="ri-phone-line"></i>
                <span>955 034 600</span>
              </a>
              <a href="mailto:info@grupoavisa.com" className="flex items-center gap-2 hover:text-white/80 transition-colors">
                <i className="ri-mail-line"></i>
                <span>info@grupoavisa.com</span>
              </a>
            </div>
          </div>

          <div>
            <h3 className="font-bold text-lg mb-4">Vehículos</h3>
            <ul className="space-y-2">
              <li>
                <Link className="text-white/90 hover:text-yellow-300 text-sm transition-colors cursor-pointer" href="/promociones-electricos">
                  Gama Eléctrica
                </Link>
              </li>
              <li>
                <Link className="text-white/90 hover:text-yellow-300 text-sm transition-colors cursor-pointer" href="/promociones-electricos">
                  Promociones Eléctricos
                </Link>
              </li>
              <li>
                <Link className="text-white/90 hover:text-yellow-300 text-sm transition-colors cursor-pointer" href="/promociones-hibridos">
                  Promociones Híbridos
                </Link>
              </li>
              <li>
                <Link className="text-white/90 hover:text-yellow-300 text-sm transition-colors cursor-pointer" href="#test-drive">
                  Ven a probarlo
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-bold text-lg mb-4">Servicios</h3>
            <ul className="space-y-2">
              <li>
                <Link className="text-white/90 hover:text-yellow-300 text-sm transition-colors cursor-pointer" href="/postventa">
                  Postventa
                </Link>
              </li>
              <li>
                <Link className="text-white/90 hover:text-yellow-300 text-sm transition-colors cursor-pointer" href="/autoplus">
                  Autoplus
                </Link>
              </li>
              <li>
                <Link className="text-white/90 hover:text-yellow-300 text-sm transition-colors cursor-pointer" href="/preguntas">
                  Preguntas Frecuentes
                </Link>
              </li>
              <li>
                <Link className="text-white/90 hover:text-yellow-300 text-sm transition-colors cursor-pointer" href="/concesionarios">
                  Concesionarios
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-bold text-lg mb-4">Información Legal</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/terminos" className="text-white/90 hover:text-yellow-300 text-sm transition-colors cursor-pointer">
                  Aviso Legal
                </Link>
              </li>
              <li>
                <Link href="/terminos" className="text-white/90 hover:text-yellow-300 text-sm transition-colors cursor-pointer">
                  Política de Privacidad
                </Link>
              </li>
              <li>
                <Link href="/terminos" className="text-white/90 hover:text-yellow-300 text-sm transition-colors cursor-pointer">
                  Política de Cookies
                </Link>
              </li>
              <li>
                <Link href="/terminos" className="text-white/90 hover:text-yellow-300 text-sm transition-colors cursor-pointer">
                  Condiciones de Uso
                </Link>
              </li>
              <li>
                <Link href="/terminos" className="text-white/90 hover:text-yellow-300 text-sm transition-colors cursor-pointer">
                  Declaración de Accesibilidad
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-white/20 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-white/80 text-sm">
              © {currentYear} Grupo Avisa. Todos los derechos reservados.
            </p>
            <div className="flex items-center gap-4">
              <a href="https://www.linkedin.com/company/grupoavisa" target="_blank" rel="noopener noreferrer" className="text-white hover:text-white/80 transition-colors">
                <i className="ri-linkedin-fill text-xl"></i>
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}