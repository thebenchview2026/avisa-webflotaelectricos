
"use client";

import { useState, useEffect } from "react";
import Link from "next/link";

export default function CookieBanner() {
  const [isVisible, setIsVisible] = useState(false);
  const [showPreferences, setShowPreferences] = useState(false);
  const [preferences, setPreferences] = useState({
    necessary: true,
    analytics: false,
    marketing: false,
    personalization: false,
  });

  useEffect(() => {
    const consent = localStorage.getItem("cookieConsent");
    if (!consent) {
      setIsVisible(true);
    }
  }, []);

  const handleAcceptAll = () => {
    const allAccepted = {
      necessary: true,
      analytics: true,
      marketing: true,
      personalization: true,
    };
    localStorage.setItem("cookieConsent", JSON.stringify(allAccepted));
    setIsVisible(false);
  };

  const handleRejectAll = () => {
    const onlyNecessary = {
      necessary: true,
      analytics: false,
      marketing: false,
      personalization: false,
    };
    localStorage.setItem("cookieConsent", JSON.stringify(onlyNecessary));
    setIsVisible(false);
  };

  const handleSavePreferences = () => {
    localStorage.setItem("cookieConsent", JSON.stringify(preferences));
    setIsVisible(false);
    setShowPreferences(false);
  };

  if (!isVisible) return null;

  return (
    <div className="fixed inset-0 z-[9999] flex items-end justify-center bg-black/40 backdrop-blur-sm">
      <div className="w-full max-w-7xl mx-4 mb-4 bg-white rounded-lg shadow-2xl border border-gray-200">
        {!showPreferences ? (
          <div className="p-6 md:p-8">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-12 h-12 flex items-center justify-center bg-teal-50 rounded-lg">
                <i className="ri-cookie-line text-2xl text-teal-600"></i>
              </div>
              <div className="flex-1">
                <h3 className="text-xl font-bold text-gray-900 mb-2">Utilizamos cookies</h3>
                <p className="text-sm text-gray-600 mb-4 leading-relaxed">
                  Utilizamos cookies propias y de terceros para mejorar nuestros servicios, analizar el tráfico web y personalizar el contenido. Puedes aceptar todas las cookies, rechazarlas o configurar tus preferencias. Para más información, consulta nuestra{" "}
                  <Link href="/politica-cookies" className="text-teal-600 hover:text-teal-700 font-medium underline whitespace-nowrap">
                    Política de Cookies
                  </Link>{" "}
                  y nuestra{" "}
                  <Link href="/politica-privacidad" className="text-teal-600 hover:text-teal-700 font-medium underline whitespace-nowrap">
                    Política de Privacidad
                  </Link>.
                </p>
                <div className="flex flex-wrap gap-3">
                  <button
                    onClick={handleAcceptAll}
                    className="px-6 py-2.5 bg-teal-600 text-white text-sm font-semibold rounded-lg hover:bg-teal-700 transition-colors whitespace-nowrap cursor-pointer"
                  >
                    Aceptar todas
                  </button>
                  <button
                    onClick={handleRejectAll}
                    className="px-6 py-2.5 bg-gray-100 text-gray-700 text-sm font-semibold rounded-lg hover:bg-gray-200 transition-colors whitespace-nowrap cursor-pointer"
                  >
                    Rechazar todas
                  </button>
                  <button
                    onClick={() => setShowPreferences(true)}
                    className="px-6 py-2.5 bg-white text-gray-700 text-sm font-semibold rounded-lg border border-gray-300 hover:bg-gray-50 transition-colors whitespace-nowrap cursor-pointer"
                  >
                    Configurar preferencias
                  </button>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="p-6 md:p-8">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-bold text-gray-900">Configurar preferencias de cookies</h3>
              <button
                onClick={() => setShowPreferences(false)}
                className="w-8 h-8 flex items-center justify-center text-gray-500 hover:text-gray-700 cursor-pointer"
              >
                <i className="ri-close-line text-xl"></i>
              </button>
            </div>
            <div className="space-y-4 mb-6">
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <h4 className="font-semibold text-gray-900">Cookies necesarias</h4>
                  <p className="text-sm text-gray-600">Esenciales para el funcionamiento del sitio web. No se pueden desactivar.</p>
                </div>
                <div className="w-12 h-6 bg-teal-600 rounded-full flex items-center justify-end px-1">
                  <div className="w-4 h-4 bg-white rounded-full"></div>
                </div>
              </div>
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <h4 className="font-semibold text-gray-900">Cookies analíticas</h4>
                  <p className="text-sm text-gray-600">Nos ayudan a entender cómo interactúas con el sitio web.</p>
                </div>
                <button
                  onClick={() => setPreferences({ ...preferences, analytics: !preferences.analytics })}
                  className={`w-12 h-6 rounded-full flex items-center px-1 cursor-pointer transition-colors ${
                    preferences.analytics ? "bg-teal-600 justify-end" : "bg-gray-300 justify-start"
                  }`}
                >
                  <div className="w-4 h-4 bg-white rounded-full"></div>
                </button>
              </div>
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <h4 className="font-semibold text-gray-900">Cookies de marketing</h4>
                  <p className="text-sm text-gray-600">Utilizadas para mostrarte anuncios relevantes.</p>
                </div>
                <button
                  onClick={() => setPreferences({ ...preferences, marketing: !preferences.marketing })}
                  className={`w-12 h-6 rounded-full flex items-center px-1 cursor-pointer transition-colors ${
                    preferences.marketing ? "bg-teal-600 justify-end" : "bg-gray-300 justify-start"
                  }`}
                >
                  <div className="w-4 h-4 bg-white rounded-full"></div>
                </button>
              </div>
              <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <h4 className="font-semibold text-gray-900">Cookies de personalización</h4>
                  <p className="text-sm text-gray-600">Permiten recordar tus preferencias y personalizar tu experiencia.</p>
                </div>
                <button
                  onClick={() => setPreferences({ ...preferences, personalization: !preferences.personalization })}
                  className={`w-12 h-6 rounded-full flex items-center px-1 cursor-pointer transition-colors ${
                    preferences.personalization ? "bg-teal-600 justify-end" : "bg-gray-300 justify-start"
                  }`}
                >
                  <div className="w-4 h-4 bg-white rounded-full"></div>
                </button>
              </div>
            </div>
            <div className="flex flex-wrap gap-3">
              <button
                onClick={handleSavePreferences}
                className="px-6 py-2.5 bg-teal-600 text-white text-sm font-semibold rounded-lg hover:bg-teal-700 transition-colors whitespace-nowrap cursor-pointer"
              >
                Guardar preferencias
              </button>
              <button
                onClick={handleAcceptAll}
                className="px-6 py-2.5 bg-gray-100 text-gray-700 text-sm font-semibold rounded-lg hover:bg-gray-200 transition-colors whitespace-nowrap cursor-pointer"
              >
                Aceptar todas
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
