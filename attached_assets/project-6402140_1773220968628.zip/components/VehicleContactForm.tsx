
'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

interface VehicleContactFormProps {
  vehicleName: string;
  vehicleBrand: string;
  accentColor?: 'green' | 'blue';
}

export default function VehicleContactForm({ vehicleName, vehicleBrand, accentColor = 'green' }: VehicleContactFormProps) {
  const router = useRouter();
  const [formData, setFormData] = useState({
    nombre: '',
    email: '',
    telefono: '',
    empresa: '',
    mensaje: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [acceptTerms, setAcceptTerms] = useState(false);
  const [acceptMarketing, setAcceptMarketing] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!acceptTerms) {
      return;
    }
    
    setIsSubmitting(true);
    setSubmitStatus('idle');

    const formBody = new URLSearchParams();
    formBody.append('nombre', formData.nombre);
    formBody.append('email', formData.email);
    formBody.append('telefono', formData.telefono);
    formBody.append('empresa', formData.empresa);
    formBody.append('vehiculo', `${vehicleBrand} ${vehicleName}`);
    formBody.append('mensaje', formData.mensaje);
    formBody.append('acepta_terminos', acceptTerms ? 'Sí' : 'No');
    formBody.append('acepta_marketing', acceptMarketing ? 'Sí' : 'No');

    try {
      const response = await fetch('https://readdy.ai/api/form/d69g187mvg9ih2c7a0og', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: formBody.toString(),
      });

      if (response.ok) {
        const tipo = accentColor === 'green' ? 'electrico' : 'hibrido';
        const params = new URLSearchParams({
          vehiculo: `${vehicleBrand} ${vehicleName}`,
          nombre: formData.nombre,
          tipo: tipo
        });
        router.push(`/confirmacion-solicitud?${params.toString()}`);
      } else {
        setSubmitStatus('error');
      }
    } catch (error) {
      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const colorClasses = accentColor === 'green' 
    ? {
        gradient: 'from-green-600 to-green-700',
        button: 'bg-green-600 hover:bg-green-700',
        focus: 'focus:ring-green-500 focus:border-green-500',
        icon: 'text-green-500'
      }
    : {
        gradient: 'from-blue-600 to-blue-700',
        button: 'bg-blue-600 hover:bg-blue-700',
        focus: 'focus:ring-blue-500 focus:border-blue-500',
        icon: 'text-blue-500'
      };

  return (
    <section className="py-16 bg-slate-50">
      <div className="max-w-4xl mx-auto px-6">
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
          <div className={`bg-gradient-to-r ${colorClasses.gradient} px-8 py-6`}>
            <h2 className="text-2xl md:text-3xl font-bold text-white flex items-center gap-3">
              <i className="ri-mail-send-line"></i>
              Solicita información sobre el {vehicleBrand} {vehicleName}
            </h2>
            <p className="text-white/80 mt-2">Completa el formulario y un asesor te contactará en menos de 24h</p>
          </div>
          
          <form 
            id="vehicle-contact-form"
            data-readdy-form
            onSubmit={handleSubmit} 
            className="p-8"
          >
            <div className="grid md:grid-cols-2 gap-6 mb-6">
              <div>
                <label htmlFor="nombre" className="block text-sm font-semibold text-slate-700 mb-2">
                  Nombre completo *
                </label>
                <input
                  type="text"
                  id="nombre"
                  name="nombre"
                  required
                  value={formData.nombre}
                  onChange={handleChange}
                  className={`w-full px-4 py-3 border border-slate-300 rounded-lg text-sm ${colorClasses.focus} transition-colors`}
                  placeholder="Tu nombre"
                />
              </div>
              <div>
                <label htmlFor="email" className="block text-sm font-semibold text-slate-700 mb-2">
                  Email *
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  required
                  value={formData.email}
                  onChange={handleChange}
                  className={`w-full px-4 py-3 border border-slate-300 rounded-lg text-sm ${colorClasses.focus} transition-colors`}
                  placeholder="tu@email.com"
                />
              </div>
              <div>
                <label htmlFor="telefono" className="block text-sm font-semibold text-slate-700 mb-2">
                  Teléfono *
                </label>
                <input
                  type="tel"
                  id="telefono"
                  name="telefono"
                  required
                  value={formData.telefono}
                  onChange={handleChange}
                  className={`w-full px-4 py-3 border border-slate-300 rounded-lg text-sm ${colorClasses.focus} transition-colors`}
                  placeholder="600 000 000"
                />
              </div>
              <div>
                <label htmlFor="empresa" className="block text-sm font-semibold text-slate-700 mb-2">
                  Empresa
                </label>
                <input
                  type="text"
                  id="empresa"
                  name="empresa"
                  value={formData.empresa}
                  onChange={handleChange}
                  className={`w-full px-4 py-3 border border-slate-300 rounded-lg text-sm ${colorClasses.focus} transition-colors`}
                  placeholder="Nombre de tu empresa"
                />
              </div>
            </div>
            
            <div className="mb-6">
              <label htmlFor="mensaje" className="block text-sm font-semibold text-slate-700 mb-2">
                Mensaje o consulta
              </label>
              <textarea
                id="mensaje"
                name="mensaje"
                rows={4}
                maxLength={500}
                value={formData.mensaje}
                onChange={handleChange}
                className={`w-full px-4 py-3 border border-slate-300 rounded-lg text-sm ${colorClasses.focus} transition-colors resize-none`}
                placeholder="Cuéntanos qué necesitas: kilometraje estimado, plazo de entrega, opcionales..."
              />
              <p className="text-xs text-slate-500 mt-1">{formData.mensaje.length}/500 caracteres</p>
            </div>

            <div className="bg-slate-50 rounded-lg p-4 mb-6">
              <div className="flex items-start gap-3">
                <i className={`ri-car-line text-xl ${colorClasses.icon} mt-0.5`}></i>
                <div>
                  <p className="text-sm font-semibold text-slate-700">Vehículo de interés</p>
                  <p className="text-sm text-slate-600">{vehicleBrand} {vehicleName}</p>
                </div>
              </div>
            </div>

            {submitStatus === 'success' && (
              <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-center gap-3">
                <i className="ri-checkbox-circle-fill text-green-600 text-xl"></i>
                <div>
                  <p className="font-semibold text-green-800">¡Solicitud enviada correctamente!</p>
                  <p className="text-sm text-green-700">Un asesor te contactará en breve.</p>
                </div>
              </div>
            )}

            {submitStatus === 'error' && (
              <div className="mb-6 p-4 bg-red-50 border border-red-200 rounded-lg flex items-center gap-3">
                <i className="ri-error-warning-fill text-red-600 text-xl"></i>
                <div>
                  <p className="font-semibold text-red-800">Error al enviar</p>
                  <p className="text-sm text-red-700">Por favor, inténtalo de nuevo o llámanos directamente.</p>
                </div>
              </div>
            )}

            <div className="space-y-3 mb-6">
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={acceptTerms}
                  onChange={(e) => setAcceptTerms(e.target.checked)}
                  className={`mt-1 w-4 h-4 border-slate-300 rounded cursor-pointer ${accentColor === 'green' ? 'text-green-600 focus:ring-green-500' : 'text-blue-600 focus:ring-blue-500'}`}
                  required
                />
                <span className="text-sm text-slate-600">
                  He leído y acepto <a href="/terminos" className={`underline ${accentColor === 'green' ? 'text-green-600 hover:text-green-700' : 'text-blue-600 hover:text-blue-700'}`}>los términos y condiciones de la política de privacidad</a>. *
                </span>
              </label>
              
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={acceptMarketing}
                  onChange={(e) => setAcceptMarketing(e.target.checked)}
                  className={`mt-1 w-4 h-4 border-slate-300 rounded cursor-pointer ${accentColor === 'green' ? 'text-green-600 focus:ring-green-500' : 'text-blue-600 focus:ring-blue-500'}`}
                />
                <span className="text-sm text-slate-600">
                  Doy mi consentimiento para el tratamiento de mis datos personales con fines de marketing y comerciales (Opcional)
                </span>
              </label>
            </div>

            <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
              <p className="text-xs text-slate-500">
                Los campos marcados con * son obligatorios
              </p>
              <button
                type="submit"
                disabled={isSubmitting || !acceptTerms}
                className={`${colorClasses.button} text-white px-8 py-4 rounded-lg font-bold transition-all shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 cursor-pointer whitespace-nowrap`}
              >
                {isSubmitting ? (
                  <>
                    <i className="ri-loader-4-line animate-spin"></i>
                    Enviando...
                  </>
                ) : (
                  <>
                    <i className="ri-send-plane-fill"></i>
                    Solicitar información
                  </>
                )}
              </button>
            </div>
          </form>
        </div>

        <div className="mt-8 grid md:grid-cols-3 gap-6">
          <div className="bg-white rounded-xl p-6 border border-slate-200 text-center">
            <div className={`w-12 h-12 ${colorClasses.button} rounded-full flex items-center justify-center mx-auto mb-4`}>
              <i className="ri-phone-fill text-white text-xl"></i>
            </div>
            <h3 className="font-bold text-slate-900 mb-1">Llámanos</h3>
            <a href="tel:955034600" className="text-slate-600 hover:text-slate-900 cursor-pointer">955 034 600</a>
          </div>
          <div className="bg-white rounded-xl p-6 border border-slate-200 text-center">
            <div className="w-12 h-12 bg-[#25D366] rounded-full flex items-center justify-center mx-auto mb-4">
              <i className="ri-whatsapp-fill text-white text-xl"></i>
            </div>
            <h3 className="font-bold text-slate-900 mb-1">WhatsApp</h3>
            <a href="https://wa.me/34955034600" target="_blank" rel="noopener noreferrer" className="text-slate-600 hover:text-slate-900 cursor-pointer">955 034 600</a>
          </div>
          <div className="bg-white rounded-xl p-6 border border-slate-200 text-center">
            <div className={`w-12 h-12 ${colorClasses.button} rounded-full flex items-center justify-center mx-auto mb-4`}>
              <i className="ri-map-pin-fill text-white text-xl"></i>
            </div>
            <h3 className="font-bold text-slate-900 mb-1">Visítanos</h3>
            <a href="/concesionarios" className="text-slate-600 hover:text-slate-900 cursor-pointer">Ver concesionarios</a>
          </div>
        </div>
      </div>
    </section>
  );
}
