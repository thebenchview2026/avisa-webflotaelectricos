'use client';

import { useState } from 'react';

const hybridVehicles = [
  {
    id: 1,
    brand: 'Cupra',
    model: 'Formentor e-Hybrid',
    type: 'Híbrido Enchufable',
    price: '445€/mes',
    duration: '48 meses',
    badge: 'Más deportivo',
    autonomiaElectrica: '62 km',
    images: [
      'https://readdy.ai/api/search-image?query=sporty%20Cupra%20Formentor%20plug-in%20hybrid%20SUV%20in%20magnetic%20tech%20matte%20gray%20color%20on%20clean%20minimalist%20white%20studio%20background%20with%20professional%20lighting%20highlighting%20aggressive%20Spanish%20design%20and%20performance%20hybrid%20technology%20front%20three%20quarter%20view&width=480&height=320&seq=cupra-formentor-ehybrid-1&orientation=landscape&format=webp'
    ]
  },
  {
    id: 2,
    brand: 'Seat',
    model: 'Leon e-Hybrid',
    type: 'Híbrido Enchufable',
    price: '365€/mes',
    duration: '48 meses',
    badge: 'Mejor precio',
    autonomiaElectrica: '64 km',
    images: [
      'https://readdy.ai/api/search-image?query=stylish%20Seat%20Leon%20e-Hybrid%20compact%20hatchback%20in%20desire%20red%20color%20on%20pristine%20white%20studio%20background%20with%20professional%20lighting%20emphasizing%20Spanish%20design%20excellence%20and%20plug-in%20hybrid%20efficiency%20front%20three%20quarter%20view&width=480&height=320&seq=seat-leon-ehybrid-1&orientation=landscape&format=webp'
    ]
  },
  {
    id: 3,
    brand: 'Volkswagen',
    model: 'Tiguan eHybrid',
    type: 'Híbrido Enchufable',
    price: '425€/mes',
    duration: '48 meses',
    badge: 'Más versátil',
    autonomiaElectrica: '50 km',
    images: [
      'https://readdy.ai/api/search-image?query=elegant%20Volkswagen%20Tiguan%20eHybrid%20plug-in%20hybrid%20SUV%20in%20pure%20white%20color%20on%20clean%20white%20studio%20background%20with%20soft%20professional%20lighting%20showcasing%20German%20engineering%20and%20sustainable%20family%20SUV%20design%20front%20three%20quarter%20view&width=480&height=320&seq=vw-tiguan-ehybrid-1&orientation=landscape&format=webp'
    ]
  }
];

export default function HybridPromotions() {
  const [currentImageIndex, setCurrentImageIndex] = useState<{[key: number]: number}>({});

  return (
    <section id="promociones-hibridos" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Promociones híbridos enchufables
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Lo mejor de dos mundos: conducción eléctrica en ciudad y autonomía ilimitada en carretera
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {hybridVehicles.map((vehicle) => (
            <div key={vehicle.id} className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 group flex flex-col border border-gray-100">
              <div className="relative">
                <div className="w-full h-48 bg-slate-100">
                  <img 
                    alt={`${vehicle.brand} ${vehicle.model}`}
                    className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500"
                    src={vehicle.images[0]}
                  />
                </div>
                <div className="absolute top-3 right-3 bg-green-600 text-white px-3 py-1.5 rounded-full text-xs font-bold shadow-lg">
                  {vehicle.badge}
                </div>
                <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-sm px-3 py-1.5 rounded-full text-xs font-bold text-gray-900">
                  {vehicle.autonomiaElectrica} eléctricos
                </div>
              </div>

              <div className="p-5 flex flex-col flex-grow">
                <div className="mb-4">
                  <div className="text-xs text-gray-500 mb-1 uppercase tracking-wide">
                    {vehicle.brand}
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 mb-2 leading-tight">
                    {vehicle.model}
                  </h3>
                  <span className="inline-block px-2.5 py-1 bg-green-100 text-green-700 text-xs font-medium rounded-full">
                    {vehicle.type}
                  </span>
                </div>

                <div className="flex items-end justify-between mb-5 mt-auto">
                  <div>
                    <div className="text-2xl font-bold text-gray-900">{vehicle.price}</div>
                    <div className="text-xs text-gray-500">IVA incluido</div>
                  </div>
                  <div className="text-right text-xs text-gray-600">{vehicle.duration}</div>
                </div>

                <a 
                  className="block w-full bg-green-600 text-white text-center py-2.5 rounded-lg text-sm font-bold hover:bg-green-700 transition-colors cursor-pointer whitespace-nowrap"
                  href="#contacto"
                >
                  Solicitar oferta
                </a>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-gradient-to-r from-green-50 to-blue-50 rounded-xl p-8 border border-green-100">
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">
                ¿Por qué elegir un híbrido enchufable?
              </h3>
              <ul className="space-y-3">
                <li className="flex items-start gap-3">
                  <div className="w-6 h-6 flex items-center justify-center bg-green-600 text-white rounded-full flex-shrink-0 mt-0.5">
                    <i className="ri-check-line text-sm"></i>
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">Cero emisiones en ciudad</p>
                    <p className="text-sm text-gray-600">Hasta 75 km en modo 100% eléctrico</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-6 h-6 flex items-center justify-center bg-green-600 text-white rounded-full flex-shrink-0 mt-0.5">
                    <i className="ri-check-line text-sm"></i>
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">Sin ansiedad de autonomía</p>
                    <p className="text-sm text-gray-600">Motor de combustión para viajes largos</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-6 h-6 flex items-center justify-center bg-green-600 text-white rounded-full flex-shrink-0 mt-0.5">
                    <i className="ri-check-line text-sm"></i>
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">Etiqueta ECO de la DGT</p>
                    <p className="text-sm text-gray-600">Acceso a zonas restringidas y ventajas fiscales</p>
                  </div>
                </li>
              </ul>
            </div>
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">
                Ventajas adicionales
              </h3>
              <ul className="space-y-3">
                <li className="flex items-start gap-3">
                  <div className="w-6 h-6 flex items-center justify-center bg-blue-600 text-white rounded-full flex-shrink-0 mt-0.5">
                    <i className="ri-check-line text-sm"></i>
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">Ahorro de hasta 70% en combustible</p>
                    <p className="text-sm text-gray-600">En uso urbano y periurbano</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-6 h-6 flex items-center justify-center bg-blue-600 text-white rounded-full flex-shrink-0 mt-0.5">
                    <i className="ri-check-line text-sm"></i>
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">Carga en casa o trabajo</p>
                    <p className="text-sm text-gray-600">Carga completa en 3-4 horas</p>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <div className="w-6 h-6 flex items-center justify-center bg-blue-600 text-white rounded-full flex-shrink-0 mt-0.5">
                    <i className="ri-check-line text-sm"></i>
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">Ayudas del Plan MOVES</p>
                    <p className="text-sm text-gray-600">Hasta 5.000€ de subvención</p>
                  </div>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
