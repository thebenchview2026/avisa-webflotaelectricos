'use client';

import { useState } from 'react';

const faqs = [
  {
    category: 'Autonomía',
    questions: [
      {
        q: '¿Cuántos kilómetros puedo recorrer con un coche eléctrico?',
        a: 'Los vehículos eléctricos actuales ofrecen entre 300 y 600 km de autonomía real. Modelos como el Tesla Model 3 Long Range superan los 500 km, mientras que opciones más compactas como el Volkswagen ID.3 ofrecen alrededor de 400 km. La autonomía real depende del estilo de conducción, climatología y uso de sistemas auxiliares.'
      },
      {
        q: '¿La autonomía disminuye en invierno?',
        a: 'Sí, en condiciones de frío extremo la autonomía puede reducirse entre un 10-30%. Esto se debe al uso de calefacción y a que las baterías funcionan de forma menos eficiente a bajas temperaturas. Los modelos modernos incluyen sistemas de precondicionamiento que minimizan esta pérdida.'
      }
    ]
  },
  {
    category: 'Carga',
    questions: [
      {
        q: '¿Cuánto tiempo tarda en cargar un coche eléctrico?',
        a: 'Depende del tipo de carga: en casa con wallbox (7-11 kW) tarda 6-8 horas para carga completa, en cargadores rápidos públicos (50 kW) entre 30-60 minutos al 80%, y en supercargadores (150-350 kW) solo 15-30 minutos al 80%. La mayoría de usuarios cargan por la noche en casa.'
      },
      {
        q: '¿Puedo instalar un punto de carga en mi garaje comunitario?',
        a: 'Sí, la ley garantiza el derecho a instalar puntos de recarga en garajes comunitarios. Solo necesitas notificarlo a la comunidad y cumplir requisitos técnicos básicos. Grupo Avisa gestiona todo el proceso incluyendo permisos y ayudas disponibles del Plan MOVES.'
      }
    ]
  },
  {
    category: 'Costes',
    questions: [
      {
        q: '¿Cuánto cuesta cargar un coche eléctrico?',
        a: 'Cargar en casa cuesta aproximadamente 2-3€ por cada 100 km (con tarifa nocturna puede ser menos de 1€). En cargadores públicos rápidos el coste sube a 6-10€ por 100 km. Aún así, es significativamente más barato que la gasolina o diésel, con ahorros anuales de 800-1.200€ para un uso medio.'
      },
      {
        q: '¿Qué mantenimiento necesita un coche eléctrico?',
        a: 'El mantenimiento es mucho más económico: no hay cambios de aceite, filtros de combustible, embrague ni correas de distribución. Solo revisiones de frenos, neumáticos, líquido refrigerante y sistemas electrónicos. El ahorro en mantenimiento puede superar los 300€ anuales.'
      }
    ]
  },
  {
    category: 'Ayudas',
    questions: [
      {
        q: '¿Qué ayudas existen para comprar un coche eléctrico?',
        a: 'El Plan MOVES III ofrece hasta 7.000€ para vehículos eléctricos y 5.000€ para híbridos enchufables (con achatarramiento). Además, existen ayudas autonómicas y municipales adicionales, bonificaciones en el impuesto de circulación (hasta 75% de descuento) y ventajas en aparcamiento en muchas ciudades.'
      },
      {
        q: '¿Grupo Avisa gestiona las ayudas del Plan MOVES?',
        a: 'Sí, nos encargamos de toda la tramitación sin coste adicional. Además, adelantamos el importe de la ayuda para que no tengas que esperar los 3-6 meses que tarda la administración en aprobarla. Tú solo disfrutas de tu vehículo desde el primer día.'
      }
    ]
  },
  {
    category: 'Híbridos',
    questions: [
      {
        q: '¿Qué diferencia hay entre un híbrido y un híbrido enchufable?',
        a: 'Los híbridos enchufables (PHEV) tienen baterías más grandes que se cargan en la red eléctrica y pueden circular en modo 100% eléctrico hasta 50-80 km. Los híbridos convencionales (HEV) solo se cargan con el motor y la frenada regenerativa. Solo los PHEV tienen acceso a las ayudas del Plan MOVES III.'
      },
      {
        q: '¿Merece la pena un híbrido enchufable?',
        a: 'Sí, especialmente si haces trayectos diarios cortos (menos de 50 km) y puedes cargar en casa o el trabajo. Usarás el motor eléctrico el 80% del tiempo, ahorrando combustible, pero tendrás la tranquilidad del motor de gasolina para viajes largos. Además, accedes a ayudas de hasta 5.000€.'
      }
    ]
  },
  {
    category: 'Uso diario',
    questions: [
      {
        q: '¿Es práctico un coche eléctrico para viajes largos?',
        a: 'Sí, la red de cargadores rápidos en autopistas está muy desarrollada. Con autonomías de 400-500 km y cargadores que recuperan el 80% en 20-30 minutos, los viajes largos son perfectamente viables. Aplicaciones como Electromaps muestran todos los puntos de carga disponibles en tu ruta.'
      },
      {
        q: '¿Puedo remolcar con un coche eléctrico?',
        a: 'Muchos modelos eléctricos pueden remolcar. Por ejemplo, el Tesla Model X puede arrastrar hasta 2.250 kg, y SUVs eléctricos como el Audi e-tron o Mercedes EQC ofrecen capacidades de remolque de 1.800 kg. El par motor instantáneo de los eléctricos es ideal para remolcar.'
      }
    ]
  }
];

export default function FAQSection() {
  const [openCategory, setOpenCategory] = useState<string | null>('Autonomía');
  const [openQuestion, setOpenQuestion] = useState<number | null>(0);

  return (
    <section id="faqs" className="py-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Preguntas frecuentes
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Resolvemos todas tus dudas sobre vehículos eléctricos e híbridos enchufables
          </p>
        </div>

        <div className="grid lg:grid-cols-4 gap-8">
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl p-4 shadow-lg sticky top-24">
              <h3 className="font-bold text-gray-900 mb-4 px-2">Categorías</h3>
              <nav className="space-y-1">
                {faqs.map((category) => (
                  <button
                    key={category.category}
                    onClick={() => {
                      setOpenCategory(category.category);
                      setOpenQuestion(null);
                    }}
                    className={`w-full text-left px-4 py-3 rounded-lg transition-colors cursor-pointer ${
                      openCategory === category.category
                        ? 'bg-[#ad023b] text-white'
                        : 'text-gray-700 hover:bg-gray-100'
                    }`}
                  >
                    {category.category}
                  </button>
                ))}
              </nav>
            </div>
          </div>

          <div className="lg:col-span-3">
            <div className="space-y-4">
              {faqs
                .filter((cat) => cat.category === openCategory)
                .map((category) =>
                  category.questions.map((faq, index) => (
                    <div
                      key={index}
                      className="bg-white rounded-xl shadow-lg overflow-hidden border border-gray-100"
                    >
                      <button
                        onClick={() => setOpenQuestion(openQuestion === index ? null : index)}
                        className="w-full text-left px-6 py-5 flex items-center justify-between cursor-pointer hover:bg-gray-50 transition-colors"
                      >
                        <h4 className="font-bold text-gray-900 pr-4">{faq.q}</h4>
                        <i
                          className={`ri-arrow-down-s-line text-2xl text-[#ad023b] flex-shrink-0 transition-transform ${
                            openQuestion === index ? 'rotate-180' : ''
                          }`}
                        ></i>
                      </button>
                      {openQuestion === index && (
                        <div className="px-6 pb-5">
                          <p className="text-gray-600 leading-relaxed">{faq.a}</p>
                        </div>
                      )}
                    </div>
                  ))
                )}
            </div>
          </div>
        </div>

        <div className="mt-16 bg-gradient-to-r from-blue-50 to-green-50 rounded-2xl p-8 text-center border border-blue-100">
          <h3 className="text-2xl font-bold text-gray-900 mb-4">
            ¿No encuentras la respuesta que buscas?
          </h3>
          <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
            Nuestro equipo de expertos está disponible para resolver cualquier duda sobre movilidad eléctrica
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a
              href="#contacto"
              className="inline-block bg-[#ad023b] hover:bg-[#8d0230] text-white px-8 py-3 rounded-lg font-bold transition-colors cursor-pointer whitespace-nowrap"
            >
              Contactar con un experto
            </a>
            <a
              href="https://wa.me/34955034600"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-[#25D366] hover:bg-[#20BD5A] text-white px-8 py-3 rounded-lg font-bold transition-colors cursor-pointer whitespace-nowrap flex items-center justify-center gap-2"
            >
              <i className="ri-whatsapp-line text-xl"></i>
              Escríbeme
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}