'use client';

const dealers = [
  {
    name: 'Avisa Volkswagen Sevilla',
    brand: 'Volkswagen',
    logo: 'https://cdn.dealerk.es/cars/make/brand/48/white/volkswagen.png',
    address: 'C/ Alhami, 2-4, 41020 Sevilla',
    phone: '955 03 46 00',
    phoneLink: '+34955034600',
    mapUrl: 'https://www.google.com/maps/search/?api=1&query=C/Alhami,+2-4,+41020+Sevilla',
    lat: 37.4019,
    lng: -5.9426
  },
  {
    name: 'Avisa Audi Sevilla',
    brand: 'Audi',
    logo: 'https://cdn.dealerk.es/cars/make/brand/48/white/audi.png',
    address: 'Av. Averroes, 12, 41020 Sevilla',
    phone: '955 03 46 04',
    phoneLink: '+34955034604',
    mapUrl: 'https://www.google.com/maps/search/?api=1&query=Av.+Averroes,+12,+41020+Sevilla',
    lat: 37.4025,
    lng: -5.9398
  },
  {
    name: 'Cartuja Motor Sevilla',
    brand: 'Škoda',
    logo: 'https://cdn.dealerk.es/cars/make/brand/48/white/skoda.png',
    address: 'Pol. Ind. Su Eminencia, C/ D, 1-2, 41006 Sevilla',
    phone: '954 32 21 21',
    phoneLink: '+34954322121',
    mapUrl: 'https://www.google.com/maps/search/?api=1&query=Pol.+Ind.+Su+Eminencia,+C/D,+1-2,+41006+Sevilla',
    lat: 37.3650,
    lng: -5.9650
  },
  {
    name: 'Cartuja Motor Dos Hermanas',
    brand: 'Škoda',
    logo: 'https://cdn.dealerk.es/cars/make/brand/48/white/skoda.png',
    address: 'Pol. Ind. La Isla, C/ Astronomía, 1, 41703 Dos Hermanas, Sevilla',
    phone: '955 03 46 00',
    phoneLink: '+34955034600',
    mapUrl: 'https://www.google.com/maps/search/?api=1&query=Pol.+Ind.+La+Isla,+C/Astronomia,+1,+41703+Dos+Hermanas,+Sevilla',
    lat: 37.2850,
    lng: -5.9250
  },
  {
    name: 'Cartuja Motor Huelva',
    brand: 'Škoda',
    logo: 'https://cdn.dealerk.es/cars/make/brand/48/white/skoda.png',
    address: 'Pol. Ind. La Paz, Av. de las Veredas, 18, 21007 Huelva',
    phone: '959 81 10 45',
    phoneLink: '+34959811045',
    mapUrl: 'https://www.google.com/maps/search/?api=1&query=Pol.+Ind.+La+Paz,+Av.+de+las+Veredas,+18,+21007+Huelva',
    lat: 37.2614,
    lng: -6.9447
  },
  {
    name: 'Avisa Škoda Badajoz',
    brand: 'Škoda',
    logo: 'https://cdn.dealerk.es/cars/make/brand/48/white/skoda.png',
    address: 'Ctra. Madrid-Lisboa, Km. 409, 06008 Badajoz',
    phone: '924 29 11 00',
    phoneLink: '+34924291100',
    mapUrl: 'https://www.google.com/maps/search/?api=1&query=Ctra.+Madrid-Lisboa,+Km.+409,+06008+Badajoz',
    lat: 38.8794,
    lng: -6.9706
  },
  {
    name: 'Avisa Škoda Cáceres',
    brand: 'Škoda',
    logo: 'https://cdn.dealerk.es/cars/make/brand/48/white/skoda.png',
    address: 'Pol. Ind. Las Capellanías, C/ Hojalateros, 121 Oeste, 10005 Cáceres',
    phone: '927 23 48 88',
    phoneLink: '+34927234888',
    mapUrl: 'https://www.google.com/maps/search/?api=1&query=Pol.+Ind.+Las+Capellanias,+C/Hojalateros,+121+Oeste,+10005+Caceres',
    lat: 39.4697,
    lng: -6.3724
  },
  {
    name: 'Avisa Škoda Fuente de Cantos',
    brand: 'Škoda',
    logo: 'https://cdn.dealerk.es/cars/make/brand/48/white/skoda.png',
    address: 'C/ Real, 48, 06240 Fuente de Cantos, Badajoz',
    phone: '924 50 00 69',
    phoneLink: '+34924500069',
    mapUrl: 'https://www.google.com/maps/search/?api=1&query=C/Real,+48,+06240+Fuente+de+Cantos,+Badajoz',
    lat: 38.2419,
    lng: -6.3058
  },
  {
    name: 'Avisa Škoda Córdoba',
    brand: 'Škoda',
    logo: 'https://cdn.dealerk.es/cars/make/brand/48/white/skoda.png',
    address: 'C/ Esteban de Cabrera, 90, 14014 Córdoba',
    phone: '957 42 17 00',
    phoneLink: '+34957421700',
    mapUrl: 'https://www.google.com/maps/search/?api=1&query=C/Esteban+de+Cabrera,+90,+14014+Cordoba',
    lat: 37.8882,
    lng: -4.7794
  }
];

export default function DealerMapSection() {
  const mapUrl = `https://www.google.com/maps/embed/v1/view?key=AIzaSyBFw0Qbyq9zTFTd-tUY6dZWTgaQzuU17R8&center=38.0,-5.5&zoom=7&maptype=roadmap`;

  return (
    <section id="concesionarios" className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Nuestras Ubicaciones
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Grupo Avisa cuenta con concesionarios en Sevilla, Huelva, Badajoz, Cáceres y Córdoba. Encuentra el más cercano a ti.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {dealers.map((dealer, index) => (
            <div key={index} className="bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-shadow">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-slate-900 rounded-lg flex items-center justify-center p-2">
                  <img 
                    alt={`${dealer.brand} logo`} 
                    className="w-full h-full object-contain" 
                    src={dealer.logo}
                  />
                </div>
                <h3 className="font-bold text-slate-900">{dealer.name}</h3>
              </div>
              <p className="text-slate-600 text-sm mb-3">
                <i className="ri-map-pin-line text-teal-600 mr-2"></i>
                {dealer.address}
              </p>
              <p className="text-slate-600 text-sm mb-3">
                <i className="ri-phone-line text-teal-600 mr-2"></i>
                <a href={`tel:${dealer.phoneLink}`} className="hover:text-teal-600 cursor-pointer">{dealer.phone}</a>
              </p>
              <a 
                href={dealer.mapUrl} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="inline-flex items-center text-teal-600 hover:text-teal-700 text-sm font-medium mt-2 cursor-pointer"
              >
                Ver en mapa <i className="ri-arrow-right-line ml-1"></i>
              </a>
            </div>
          ))}
        </div>

        <div className="rounded-2xl overflow-hidden shadow-lg border border-slate-200 bg-white">
          <div className="relative" style={{ height: '450px', width: '100%' }}>
            <iframe
              src={mapUrl}
              width="100%"
              height="100%"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            />
          </div>
          <div className="bg-white p-4 border-t border-slate-200">
            <div className="flex flex-wrap gap-6 justify-center text-sm">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 bg-slate-900 rounded-full flex items-center justify-center flex-shrink-0">
                  <i className="ri-map-pin-fill text-white text-xs"></i>
                </div>
                <span className="text-slate-600">9 concesionarios en Andalucía y Extremadura</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
