'use client';

import { useState } from 'react';

const vehicles = [
  {
    id: 1,
    brand: 'Volkswagen',
    model: 'ID.4 Pro Performance',
    type: 'Eléctrico',
    price: '485€/mes',
    duration: '48 meses',
    badge: 'Más vendido',
    images: [
      'https://readdy.ai/api/search-image?query=modern%20Volkswagen%20ID4%20electric%20SUV%20in%20moonstone%20gray%20metallic%20color%20on%20pristine%20white%20studio%20background%20with%20professional%20lighting%20emphasizing%20sustainable%20crossover%20design%20and%20German%20engineering%20excellence%20front%20three%20quarter%20view&width=480&height=320&seq=vw-id4-promo-home-1&orientation=landscape&format=webp'
    ]
  },
  {
    id: 2,
    brand: 'Skoda',
    model: 'Enyaq iV 80',
    type: 'Eléctrico',
    price: '465€/mes',
    duration: '48 meses',
    badge: 'Mejor relación calidad-precio',
    images: [
      'https://readdy.ai/api/search-image?query=elegant%20Skoda%20Enyaq%20iV%20electric%20SUV%20in%20crystal%20white%20color%20on%20clean%20white%20studio%20background%20with%20soft%20professional%20lighting%20highlighting%20modern%20Czech%20design%20and%20sustainable%20electric%20mobility%20front%20three%20quarter%20view&width=480&height=320&seq=skoda-enyaq-promo-1&orientation=landscape&format=webp'
    ]
  },
  {
    id: 3,
    brand: 'Audi',
    model: 'Q4 e-tron 45',
    type: 'Eléctrico',
    price: '595€/mes',
    duration: '48 meses',
    badge: 'Premium',
    images: [
      'https://readdy.ai/api/search-image?query=luxurious%20Audi%20Q4%20e-tron%20electric%20SUV%20in%20glacier%20white%20metallic%20color%20on%20minimalist%20white%20studio%20background%20with%20professional%20lighting%20showcasing%20premium%20German%20electric%20vehicle%20design%20and%20quattro%20heritage%20front%20three%20quarter%20view&width=480&height=320&seq=audi-q4-etron-promo-1&orientation=landscape&format=webp'
    ]
  }
];

export default function ElectricPromotions() {
  const [currentImageIndex, setCurrentImageIndex] = useState<{[key: number]: number}>({});

  const nextImage = (vehicleId: number) => {
    setCurrentImageIndex(prev => ({
      ...prev,
      [vehicleId]: ((prev[vehicleId] || 0) + 1) % 4
    }));
  };

  const prevImage = (vehicleId: number) => {
    setCurrentImageIndex(prev => ({
      ...prev,
      [vehicleId]: ((prev[vehicleId] || 0) - 1 + 4) % 4
    }));
  };

  return (
    <section id="promociones-electricos" className="py-24 bg-gradient-to-br from-slate-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="inline-block px-4 py-2 bg-[#ad023b]/10 text-[#ad023b] text-sm font-bold rounded-full mb-4">
            Promociones activas
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Ofertas en vehículos eléctricos
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Aprovecha nuestras mejores ofertas en vehículos 100% eléctricos con Plan MOVES incluido
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {vehicles.map((vehicle) => (
            <div key={vehicle.id} className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 group flex flex-col">
              <div className="relative">
                <div className="w-full h-48 bg-slate-100">
                  <img 
                    alt={`${vehicle.brand} ${vehicle.model}`}
                    className="w-full h-full object-cover object-top group-hover:scale-105 transition-transform duration-500"
                    src={vehicle.images[0]}
                  />
                </div>
                <div className="absolute top-3 right-3 bg-[#ad023b] text-white px-3 py-1.5 rounded-full text-xs font-bold shadow-lg">
                  {vehicle.badge}
                </div>
                <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5">
                  {[0, 1, 2, 3].map((index) => (
                    <button
                      key={index}
                      className={`w-2 h-2 rounded-full transition-all cursor-pointer ${
                        (currentImageIndex[vehicle.id] || 0) === index 
                          ? 'bg-white w-6' 
                          : 'bg-white/50 hover:bg-white/75'
                      }`}
                      aria-label={`Ver imagen ${index + 1}`}
                    />
                  ))}
                </div>
                <button
                  onClick={() => prevImage(vehicle.id)}
                  className="absolute left-2 top-1/2 -translate-y-1/2 w-8 h-8 flex items-center justify-center bg-white/80 hover:bg-white rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                  aria-label="Imagen anterior"
                >
                  <i className="ri-arrow-left-s-line text-xl text-slate-900"></i>
                </button>
                <button
                  onClick={() => nextImage(vehicle.id)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 w-8 h-8 flex items-center justify-center bg-white/80 hover:bg-white rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer"
                  aria-label="Imagen siguiente"
                >
                  <i className="ri-arrow-right-s-line text-xl text-slate-900"></i>
                </button>
              </div>

              <div className="p-5 flex flex-col flex-grow">
                <div className="mb-4">
                  <div className="text-xs text-gray-500 mb-1 uppercase tracking-wide">
                    {vehicle.brand}
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 mb-2 leading-tight">
                    {vehicle.model}
                  </h3>
                  <span className="inline-block px-2.5 py-1 bg-slate-100 text-slate-700 text-xs font-medium rounded-full">
                    {vehicle.type}
                  </span>
                </div>

                <div className="flex items-end justify-between mb-5 mt-auto">
                  <div>
                    <div className="text-2xl font-bold text-gray-900">{vehicle.price}</div>
                    <div className="text-xs text-gray-500">IVA incluido</div>
                  </div>
                  <div className="text-right text-xs text-gray-600">{vehicle.duration}</div>
                </div>

                <a 
                  className="block w-full bg-slate-900 text-white text-center py-2.5 rounded-lg text-sm font-bold hover:bg-slate-800 transition-colors cursor-pointer whitespace-nowrap"
                  href="#contacto"
                >
                  Solicitar oferta
                </a>
              </div>
            </div>
          ))}
        </div>

        <div className="text-center">
          <a 
            className="inline-flex items-center gap-2 text-slate-900 font-bold hover:gap-4 transition-all cursor-pointer"
            href="#contacto"
          >
            Ver todas las promociones
            <i className="ri-arrow-right-line text-xl"></i>
          </a>
        </div>

        <div className="mt-12 bg-amber-50 border border-amber-200 rounded-lg p-6">
          <div className="flex items-start gap-4">
            <div className="w-6 h-6 flex items-center justify-center flex-shrink-0">
              <i className="ri-information-line text-xl text-amber-600"></i>
            </div>
            <div>
              <h4 className="font-bold text-slate-900 mb-2">Promociones sujetas a disponibilidad</h4>
              <p className="text-slate-700 text-sm leading-relaxed">
                Las cuotas mostradas incluyen IVA y pueden variar según financiación. Consulta condiciones específicas y disponibilidad de stock. Plan MOVES sujeto a aprobación.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
