export default function HeroSection() {
  return (
    <section className="relative min-h-[580px] flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0">
        <div className="relative overflow-hidden w-full h-full">
          <img 
            alt="Vehículo eléctrico moderno en carretera sostenible" 
            title="Movilidad eléctrica del futuro"
            width={1440}
            height={580}
            loading="eager"
            decoding="async"
            fetchPriority="high"
            className="w-full h-full object-cover transition-opacity duration-500 opacity-100"
            src="https://readdy.ai/api/search-image?query=modern%20electric%20vehicle%20driving%20on%20scenic%20highway%20with%20sustainable%20green%20landscape%20and%20blue%20sky%20background%20cinematic%20wide%20angle%20view%20emphasizing%20eco-friendly%20transportation%20and%20clean%20energy%20future%20with%20natural%20lighting%20and%20professional%20photography%20style&width=1440&height=580&seq=hero-electric-road-1&orientation=landscape&format=webp"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/30 to-black/40"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center py-12">
        <div className="space-y-6">
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-tight">
            El futuro es eléctrico<br />¿Estás preparado?
          </h1>
          <p className="text-lg md:text-xl text-white/90 max-w-3xl mx-auto font-light">
            Descubre la gama más completa de vehículos eléctricos e híbridos enchufables. Ahorro, sostenibilidad y tecnología de vanguardia.
          </p>

          <div className="flex flex-col items-center pt-4">
            <a href="https://wa.me/34955034600" target="_blank" rel="noopener noreferrer" className="block mb-3 cursor-pointer">
              <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-white shadow-lg hover:scale-105 transition-transform">
                <img 
                  alt="Asesor comercial Grupo Avisa" 
                  loading="lazy"
                  width={64}
                  height={64}
                  className="w-full h-full object-cover object-top"
                  src="https://static.readdy.ai/image/ecd9e0a88a19846633f9ef23a8543c57/7da821f8687606f5711af9936393378a.jpeg"
                />
              </div>
            </a>
            <p className="text-white/90 text-sm mb-1">¿Hablamos por WhatsApp?</p>
            <p className="text-white/70 text-xs">Asesor Grupo Avisa · Experto en movilidad eléctrica</p>
          </div>

          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center pt-4">
            <a 
              className="whitespace-nowrap bg-[#ad023b] hover:bg-[#8d0230] text-white px-8 py-3 rounded-lg font-semibold text-sm transition-all duration-300 shadow-lg hover:shadow-xl flex items-center justify-center cursor-pointer"
              href="#promociones-electricos"
            >
              Ver promociones
            </a>
            <a 
              href="https://wa.me/34955034600" 
              target="_blank" 
              rel="noopener noreferrer"
              className="whitespace-nowrap bg-[#25D366] hover:bg-[#20BD5A] text-white px-6 py-3 rounded-lg font-semibold text-sm transition-all duration-300 shadow-lg hover:shadow-xl flex items-center gap-2 cursor-pointer"
            >
              <i className="ri-whatsapp-line text-lg"></i>
              Escríbeme
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
