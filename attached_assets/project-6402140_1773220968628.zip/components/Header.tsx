
'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [electricosSubmenuOpen, setElectricosSubmenuOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-black shadow-md">
      <div className="border-b border-white/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-10">
            <div className="flex items-center gap-6 text-sm">
              <a href="tel:955034600" className="flex items-center gap-2 text-white hover:opacity-80 transition-opacity min-h-[44px] py-2">
                <i className="ri-phone-line"></i>
                <span>955 034 600</span>
              </a>
              <a href="mailto:info@grupoavisa.com" className="hidden sm:flex items-center gap-2 text-white hover:opacity-80 transition-opacity min-h-[44px] py-2">
                <i className="ri-mail-line"></i>
                <span>info@grupoavisa.com</span>
              </a>
            </div>
            <div className="flex items-center gap-4">
              <a href="https://www.linkedin.com/company/grupoavisa" target="_blank" rel="noopener noreferrer" className="text-white hover:opacity-80 transition-opacity min-w-[44px] min-h-[44px] flex items-center justify-center">
                <i className="ri-linkedin-fill text-lg"></i>
              </a>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <Link className="flex items-center min-h-[44px]" href="/">
            <img 
              alt="Grupo Avisa" 
              className="h-12" 
              src="https://static.readdy.ai/image/ecd9e0a88a19846633f9ef23a8543c57/f5a8ff11b436d5f4b52bda2d56dcfaf6.webp"
            />
          </Link>

          <nav className="hidden lg:flex items-center space-x-8">
            <Link className="text-white hover:text-slate-200 font-medium transition-colors cursor-pointer min-h-[44px] flex items-center" href="/">
              Inicio
            </Link>
            
            <div className="relative group">
              <button className="text-white hover:text-slate-200 font-medium transition-colors cursor-pointer min-h-[44px] flex items-center whitespace-nowrap">
                Promociones Eléctricos
                <i className="ri-arrow-down-s-line ml-1"></i>
              </button>
              <div className="absolute top-full left-0 mt-0 w-72 bg-white rounded-lg shadow-xl border border-slate-200 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all duration-200 z-50">
                <div className="py-2">
                  <Link 
                    href="/promociones-electricos" 
                    className="flex items-center gap-3 px-4 py-3 text-slate-700 hover:bg-slate-50 hover:text-[#14B8A6] transition-colors"
                  >
                    <span className="w-8 h-8 flex items-center justify-center bg-[#14B8A6]/10 rounded-lg">
                      <i className="ri-price-tag-3-line text-[#14B8A6]"></i>
                    </span>
                    <div>
                      <span className="font-medium block">Ofertas Eléctricos</span>
                      <span className="text-xs text-slate-500">Modelos y promociones</span>
                    </div>
                  </Link>
                  <Link 
                    href="/electrificacion" 
                    className="flex items-center gap-3 px-4 py-3 text-slate-700 hover:bg-slate-50 hover:text-[#14B8A6] transition-colors"
                  >
                    <span className="w-8 h-8 flex items-center justify-center bg-[#14B8A6]/10 rounded-lg">
                      <i className="ri-flashlight-line text-[#14B8A6]"></i>
                    </span>
                    <div>
                      <span className="font-medium block">¿Cuándo electrificar?</span>
                      <span className="text-xs text-slate-500">Guía de decisión</span>
                    </div>
                  </Link>
                  <Link 
                    href="/conductores-adopcion" 
                    className="flex items-center gap-3 px-4 py-3 text-slate-700 hover:bg-slate-50 hover:text-[#14B8A6] transition-colors"
                  >
                    <span className="w-8 h-8 flex items-center justify-center bg-[#14B8A6]/10 rounded-lg">
                      <i className="ri-user-settings-line text-[#14B8A6]"></i>
                    </span>
                    <div>
                      <span className="font-medium block">Conductores y Adopción</span>
                      <span className="text-xs text-slate-500">Gestión del cambio</span>
                    </div>
                  </Link>
                  <div className="border-t border-slate-100 my-2"></div>
                  <Link 
                    href="/autoplus" 
                    className="flex items-center gap-3 px-4 py-3 text-slate-700 hover:bg-slate-50 hover:text-[#14B8A6] transition-colors"
                  >
                    <span className="w-8 h-8 flex items-center justify-center bg-green-100 rounded-lg">
                      <i className="ri-government-line text-green-600"></i>
                    </span>
                    <div>
                      <span className="font-medium block">Autoplus</span>
                      <span className="text-xs text-slate-500">Ayudas hasta 7.000€</span>
                    </div>
                  </Link>
                </div>
              </div>
            </div>

            <Link className="text-white hover:text-slate-200 font-medium transition-colors cursor-pointer min-h-[44px] flex items-center" href="/promociones-hibridos">
              Promociones Híbridos
            </Link>
            <Link className="text-white hover:text-slate-200 font-medium transition-colors cursor-pointer min-h-[44px] flex items-center" href="/autoplus">
              Autoplus
            </Link>
            <Link className="text-white hover:text-slate-200 font-medium transition-colors cursor-pointer min-h-[44px] flex items-center" href="/postventa">
              Postventa
            </Link>
            <Link className="text-white hover:text-slate-200 font-medium transition-colors cursor-pointer min-h-[44px] flex items-center" href="/preguntas">
              FAQs
            </Link>
            <Link className="text-white hover:text-slate-200 font-medium transition-colors cursor-pointer min-h-[44px] flex items-center" href="/concesionarios">
              Concesionarios
            </Link>
          </nav>

          <button 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="lg:hidden min-w-[44px] min-h-[44px] text-white rounded-lg cursor-pointer flex items-center justify-center"
          >
            <i className={`text-2xl ${mobileMenuOpen ? 'ri-close-line' : 'ri-menu-line'}`}></i>
          </button>
        </div>
      </div>

      {mobileMenuOpen && (
        <div className="lg:hidden bg-black border-t border-white/20">
          <nav className="max-w-7xl mx-auto px-4 py-4 space-y-2">
            <Link className="block text-white hover:text-slate-200 py-3 transition-colors" href="/" onClick={() => setMobileMenuOpen(false)}>
              Inicio
            </Link>
            
            <div>
              <button 
                onClick={() => setElectricosSubmenuOpen(!electricosSubmenuOpen)}
                className="flex items-center justify-between w-full text-white hover:text-slate-200 py-3 transition-colors cursor-pointer"
              >
                <span>Promociones Eléctricos</span>
                <i className={`ri-arrow-${electricosSubmenuOpen ? 'up' : 'down'}-s-line`}></i>
              </button>
              {electricosSubmenuOpen && (
                <div className="pl-4 space-y-2 border-l-2 border-[#14B8A6] ml-2">
                  <Link 
                    className="block text-white/80 hover:text-white py-2 transition-colors" 
                    href="/promociones-electricos" 
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Ofertas Eléctricos
                  </Link>
                  <Link 
                    className="block text-white/80 hover:text-white py-2 transition-colors" 
                    href="/electrificacion" 
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    ¿Cuándo electrificar?
                  </Link>
                  <Link 
                    className="block text-white/80 hover:text-white py-2 transition-colors" 
                    href="/conductores-adopcion" 
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Conductores y Adopción
                  </Link>
                  <Link 
                    className="block text-white/80 hover:text-white py-2 transition-colors" 
                    href="/autoplus" 
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Autoplus
                  </Link>
                </div>
              )}
            </div>

            <Link className="block text-white hover:text-slate-200 py-3 transition-colors" href="/promociones-hibridos" onClick={() => setMobileMenuOpen(false)}>
              Promociones Híbridos
            </Link>
            <Link className="block text-white hover:text-slate-200 py-3 transition-colors" href="/autoplus" onClick={() => setMobileMenuOpen(false)}>
              Autoplus
            </Link>
            <Link className="block text-white hover:text-slate-200 py-3 transition-colors" href="/postventa" onClick={() => setMobileMenuOpen(false)}>
              Postventa
            </Link>
            <Link className="block text-white hover:text-slate-200 py-3 transition-colors" href="/preguntas" onClick={() => setMobileMenuOpen(false)}>
              FAQs
            </Link>
            <Link className="block text-white hover:text-slate-200 py-3 transition-colors" href="/concesionarios" onClick={() => setMobileMenuOpen(false)}>
              Concesionarios
            </Link>
          </nav>
        </div>
      )}
    </header>
  );
}
