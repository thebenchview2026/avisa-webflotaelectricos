
'use client';

export default function GestionQuejas() {
  const pasos = [
    {
      numero: 1,
      titulo: "Escucha Activa (Sin Interrumpir)",
      descripcion: "Deja que el conductor explique completamente su problema sin interrumpir. Toma notas. Haz preguntas aclaratorias solo cuando termine.",
      frases: [
        "\"Cuéntame exactamente qué pasó\"",
        "\"¿Cuándo empezaste a notar este problema?\"",
        "\"¿Cómo te está afectando en tu trabajo diario?\""
      ]
    },
    {
      numero: 2,
      titulo: "Valida su Experiencia (Aunque No Estés de Acuerdo)",
      descripcion: "Reconoce que su experiencia es real para él, incluso si crees que el problema es menor o está mal interpretado.",
      frases: [
        "\"Entiendo que esto te está generando frustración\"",
        "\"Tiene sentido que te preocupe esto\"",
        "\"Gracias por compartirlo, es importante que lo sepamos\""
      ],
      evitar: "\"No es para tanto\", \"Otros no se quejan\", \"Es normal al principio\""
    },
    {
      numero: 3,
      titulo: "Diagnostica: ¿Técnico o de Adaptación?",
      descripcion: "Identifica si es un problema real del vehículo o una dificultad de adaptación al cambio.",
      tecnico: ["Pérdida anormal de autonomía", "Cargador que no funciona", "Ruidos extraños", "Avisos en el cuadro", "Problemas de conectividad"],
      adaptacion: ["\"No me acostumbro\"", "\"Es incómodo planificar cargas\"", "\"Prefiero el diésel\"", "\"Me da ansiedad la batería\"", "\"Es diferente a lo que conocía\""]
    },
    {
      numero: 4,
      titulo: "Ofrece Soluciones Específicas",
      descripcion: "No te quedes en \"lo miramos\". Propón acciones concretas con plazos."
    },
    {
      numero: 5,
      titulo: "Seguimiento y Cierre",
      descripcion: "No dejes la queja en el aire. Haz seguimiento para verificar que se resolvió.",
      seguimiento: [
        "A las 48 horas: \"¿Cómo va? ¿Se solucionó el problema?\"",
        "A la semana: \"¿Notas mejora con [solución aplicada]?\"",
        "Al mes: \"¿Cómo te sientes ahora con el vehículo?\""
      ]
    }
  ];

  const quejasComunes = [
    {
      queja: "\"La autonomía no es suficiente para mis rutas\"",
      diagnostico: ["¿Es real o percepción? Revisa datos de consumo", "¿Está conduciendo de forma eficiente?", "¿Las rutas son realmente más largas de lo previsto?"],
      soluciones: ["Formación en conducción eficiente", "Ajuste de rutas o inclusión de paradas de carga", "Si es real: cambio a modelo con más autonomía"]
    },
    {
      queja: "\"Pierdo mucho tiempo cargando\"",
      diagnostico: ["¿Está usando carga rápida cuando debería?", "¿Hay suficientes cargadores en la empresa?", "¿Está planificando bien las cargas?"],
      soluciones: ["Optimizar horarios de carga (nocturna, durante pausas)", "Instalar más cargadores o de mayor potencia", "Reorganizar turnos para aprovechar tiempos muertos"]
    },
    {
      queja: "\"El vehículo no responde como esperaba\"",
      diagnostico: ["¿Problema técnico real o expectativas incorrectas?", "¿Está usando el modo de conducción adecuado?", "¿Hay avisos o códigos de error?"],
      soluciones: ["Revisión técnica completa", "Explicar diferencias con vehículos de combustión", "Test drive con técnico para identificar el problema"]
    },
    {
      queja: "\"Simplemente no me gusta, prefiero el diésel\"",
      diagnostico: ["Resistencia al cambio pura", "¿Hay razones específicas o es rechazo general?", "¿Ha dado tiempo suficiente para adaptarse?"],
      soluciones: ["Conversación profunda: ¿qué específicamente no le gusta?", "Periodo de prueba extendido con apoyo intensivo", "Emparejamiento con conductor entusiasta", "Si persiste tras 3-6 meses: evaluar si es viable mantenerlo en diésel"]
    }
  ];

  return (
    <section className="mb-16">
      <h2 className="text-3xl font-bold text-gray-900 mb-6 flex items-center">
        <span className="w-10 h-10 flex items-center justify-center mr-3">
          <i className="ri-customer-service-2-line text-[#14B8A6] text-2xl"></i>
        </span>
        Qué Hacer Cuando el Conductor se Queja
      </h2>

      <p className="text-lg text-gray-700 mb-6">
        Las quejas son <strong>oportunidades de mejora</strong>, no problemas. Un conductor que se queja está dando feedback valioso. La clave es gestionarlo de forma constructiva.
      </p>

      <h3 className="text-2xl font-bold text-gray-900 mb-4">Protocolo de Gestión de Quejas en 5 Pasos</h3>
      <div className="space-y-6 mb-8">
        {pasos.map((paso, index) => (
          <div key={index} className="bg-white border border-gray-200 rounded-lg p-6">
            <div className="flex items-start">
              <div className="w-12 h-12 bg-[#14B8A6]/20 rounded-full flex items-center justify-center flex-shrink-0">
                <span className="text-[#14B8A6] font-bold text-xl">{paso.numero}</span>
              </div>
              <div className="ml-4 flex-1">
                <h4 className="text-xl font-bold text-gray-900 mb-2">{paso.titulo}</h4>
                <p className="text-gray-700 mb-3">{paso.descripcion}</p>
                
                {paso.frases && (
                  <div className="bg-gray-50 rounded p-4">
                    <p className="text-sm text-gray-700 mb-2"><strong>Frases útiles:</strong></p>
                    <ul className="text-sm text-gray-600 space-y-1">
                      {paso.frases.map((frase, idx) => (
                        <li key={idx}>• {frase}</li>
                      ))}
                    </ul>
                  </div>
                )}

                {paso.evitar && (
                  <div className="mt-3 bg-red-50 border-l-4 border-red-400 p-3">
                    <p className="text-sm text-red-700"><strong>Evita:</strong> {paso.evitar}</p>
                  </div>
                )}

                {paso.tecnico && paso.adaptacion && (
                  <div className="grid md:grid-cols-2 gap-4 mt-3">
                    <div className="bg-blue-50 rounded p-4">
                      <p className="font-bold text-blue-900 mb-2">Problema Técnico</p>
                      <ul className="text-sm text-blue-800 space-y-1">
                        {paso.tecnico.map((item, idx) => (
                          <li key={idx}>• {item}</li>
                        ))}
                      </ul>
                      <p className="text-sm text-blue-700 mt-2"><strong>Acción:</strong> Revisión técnica inmediata</p>
                    </div>
                    <div className="bg-green-50 rounded p-4">
                      <p className="font-bold text-green-900 mb-2">Problema de Adaptación</p>
                      <ul className="text-sm text-green-800 space-y-1">
                        {paso.adaptacion.map((item, idx) => (
                          <li key={idx}>• {item}</li>
                        ))}
                      </ul>
                      <p className="text-sm text-green-700 mt-2"><strong>Acción:</strong> Formación adicional y acompañamiento</p>
                    </div>
                  </div>
                )}

                {paso.seguimiento && (
                  <div className="bg-gray-50 rounded p-4">
                    <ul className="text-sm text-gray-700 space-y-2">
                      {paso.seguimiento.map((item, idx) => (
                        <li key={idx}><strong>{item.split(':')[0]}:</strong>{item.split(':')[1]}</li>
                      ))}
                    </ul>
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      <h3 className="text-2xl font-bold text-gray-900 mb-4">Tipos de Quejas Comunes y Cómo Responder</h3>
      <div className="space-y-4 mb-8">
        {quejasComunes.map((queja, index) => (
          <div key={index} className="bg-white border border-gray-200 rounded-lg overflow-hidden">
            <div className="bg-gray-50 px-6 py-3 border-b border-gray-200">
              <h4 className="font-bold text-gray-900">{queja.queja}</h4>
            </div>
            <div className="p-6">
              <p className="text-gray-700 mb-3"><strong>Diagnóstico:</strong></p>
              <ul className="list-disc list-inside text-gray-700 mb-4 space-y-1">
                {queja.diagnostico.map((item, idx) => (
                  <li key={idx}>{item}</li>
                ))}
              </ul>
              <p className="text-gray-700 mb-2"><strong>Soluciones:</strong></p>
              <ul className="list-disc list-inside text-gray-700 space-y-1">
                {queja.soluciones.map((item, idx) => (
                  <li key={idx}>{item}</li>
                ))}
              </ul>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-[#14B8A6]/10 rounded-lg p-6">
        <h4 className="font-bold text-gray-900 mb-3 flex items-center">
          <span className="w-6 h-6 flex items-center justify-center mr-2">
            <i className="ri-lightbulb-line text-[#14B8A6]"></i>
          </span>
          Principio Clave
        </h4>
        <p className="text-gray-700">
          <strong>Trata cada queja como una oportunidad de mejora del sistema, no como un problema del conductor.</strong> Si un conductor se queja, probablemente otros tienen la misma dificultad pero no lo expresan. Resuelve la raíz del problema para mejorar la experiencia de todos.
        </p>
      </div>
    </section>
  );
}
