
'use client';

export default function ConductoresHero() {
  return (
    <div className="bg-gradient-to-br from-[#14B8A6] to-[#0d9488] text-white py-20">
      <div className="max-w-5xl mx-auto px-6">
        <nav className="mb-6">
          <ol className="flex items-center space-x-2 text-sm text-white/80">
            <li>
              <a href="/" className="hover:text-white transition-colors">Inicio</a>
            </li>
            <li className="flex items-center space-x-2">
              <span>/</span>
              <span className="text-white font-medium">Conductores y Adopción</span>
            </li>
          </ol>
        </nav>
        <h1 className="text-4xl md:text-5xl font-bold mb-4">
          Conductores y Adopción de Vehículos Eléctricos
        </h1>
        <p className="text-xl text-white/90 max-w-3xl">
          Guía completa para gestionar con éxito la transición de tu equipo a la movilidad eléctrica, evitando resistencias y maximizando la adopción.
        </p>
      </div>
    </div>
  );
}
