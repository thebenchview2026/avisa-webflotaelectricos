
'use client';

export default function EvitarRechazo() {
  const causasRechazo = [
    {
      titulo: "Miedo a lo desconocido",
      descripcion: "Los conductores temen quedarse sin batería, no saber dónde cargar o no poder completar sus rutas habituales."
    },
    {
      titulo: "Pérdida de control",
      descripcion: "Sienten que pierden autonomía: deben planificar cargas, seguir nuevas normas y cambiar hábitos establecidos."
    },
    {
      titulo: "Falta de información",
      descripcion: "No conocen las ventajas reales: menor ruido, mejor aceleración, sin paradas en gasolineras, menor mantenimiento."
    },
    {
      titulo: "Experiencias negativas previas",
      descripcion: "Han oído historias de problemas con eléctricos (muchas veces desactualizadas o exageradas)."
    },
    {
      titulo: "Imposición sin participación",
      descripcion: "El cambio se comunica como decisión tomada, sin consultar ni involucrar a los afectados."
    }
  ];

  const fases = [
    {
      fase: "Fase 1: Comunicación Temprana (Mes -3)",
      items: [
        "Anuncia el proyecto de electrificación con antelación",
        "Explica el por qué: sostenibilidad, ahorro, imagen corporativa",
        "Enfatiza que es un proceso gradual, no un cambio abrupto",
        "Abre un canal de preguntas y sugerencias"
      ]
    },
    {
      fase: "Fase 2: Involucración (Mes -2)",
      items: [
        "Crea un comité de conductores que participe en decisiones",
        "Pide opinión sobre modelos, características necesarias y preocupaciones",
        "Organiza visitas a concesionarios o empresas que ya usan eléctricos",
        "Permite que prueben diferentes modelos antes de decidir"
      ]
    },
    {
      fase: "Fase 3: Pruebas Reales (Mes -1)",
      items: [
        "Organiza test drives con vehículos eléctricos durante 1-2 semanas",
        "Permite que los conductores los usen en sus rutas habituales",
        "Recoge feedback detallado: qué les gustó, qué les preocupa",
        "Ajusta el plan según sus comentarios"
      ]
    },
    {
      fase: "Fase 4: Embajadores Internos (Mes 0)",
      items: [
        "Identifica a los early adopters: conductores entusiastas del cambio",
        "Asígnales los primeros vehículos eléctricos",
        "Pídeles que compartan su experiencia con el resto del equipo",
        "Que actúen como mentores para los más escépticos"
      ]
    },
    {
      fase: "Fase 5: Formación Práctica (Mes 1)",
      items: [
        "Ofrece formación hands-on, no solo teórica",
        "Incluye simulaciones de situaciones reales: carga en ruta, planificación de viajes largos",
        "Proporciona guías rápidas y apps útiles",
        "Asegura soporte técnico 24/7 durante los primeros meses"
      ]
    },
    {
      fase: "Fase 6: Seguimiento y Ajustes (Meses 2-6)",
      items: [
        "Realiza encuestas mensuales de satisfacción",
        "Organiza reuniones de feedback cada 2 meses",
        "Ajusta rutas, horarios de carga o vehículos según necesidades reales",
        "Celebra hitos: primeros 10.000 km eléctricos, ahorro de CO₂, etc."
      ]
    }
  ];

  return (
    <section className="mb-16">
      <h2 className="text-3xl font-bold text-gray-900 mb-6 flex items-center">
        <span className="w-10 h-10 flex items-center justify-center mr-3">
          <i className="ri-shield-check-line text-[#14B8A6] text-2xl"></i>
        </span>
        Cómo Evitar el Rechazo al Vehículo Eléctrico
      </h2>

      <div className="bg-gray-50 rounded-lg p-6 mb-8">
        <h3 className="text-xl font-bold text-gray-900 mb-4">Las 5 Causas Principales del Rechazo</h3>
        <div className="space-y-4">
          {causasRechazo.map((causa, index) => (
            <div key={index} className="flex items-start">
              <div className="w-8 h-8 bg-red-100 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                <span className="text-red-600 font-bold">{index + 1}</span>
              </div>
              <div className="ml-4">
                <h4 className="font-bold text-gray-900 mb-1">{causa.titulo}</h4>
                <p className="text-gray-700">{causa.descripcion}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <h3 className="text-2xl font-bold text-gray-900 mb-4">Estrategia de Prevención en 6 Fases</h3>
      <div className="space-y-6 mb-8">
        {fases.map((fase, index) => (
          <div key={index} className="border-l-4 border-[#14B8A6] pl-6">
            <h4 className="text-xl font-bold text-gray-900 mb-2">{fase.fase}</h4>
            <ul className="list-disc list-inside space-y-2 text-gray-700">
              {fase.items.map((item, idx) => (
                <li key={idx}>{item}</li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="bg-[#14B8A6]/10 rounded-lg p-6">
        <h4 className="font-bold text-gray-900 mb-3 flex items-center">
          <span className="w-6 h-6 flex items-center justify-center mr-2">
            <i className="ri-lightbulb-line text-[#14B8A6]"></i>
          </span>
          Consejo Clave
        </h4>
        <p className="text-gray-700">
          <strong>El rechazo se evita con participación, no con imposición.</strong> Los conductores que sienten que su opinión importa y que el cambio se hace "con ellos" y no "a ellos" adoptan el eléctrico 3 veces más rápido.
        </p>
      </div>
    </section>
  );
}
