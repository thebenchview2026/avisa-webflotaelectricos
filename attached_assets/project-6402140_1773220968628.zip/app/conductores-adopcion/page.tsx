
import ConductoresHero from './ConductoresHero';
import EvitarRechazo from './EvitarRechazo';
import FormacionMinima from './FormacionMinima';
import NormasUso from './NormasUso';
import GestionQuejas from './GestionQuejas';
import ConductoresCTA from './ConductoresCTA';

export default function ConductoresAdopcionPage() {
  return (
    <main className="pt-[120px]">
      <div className="min-h-screen bg-white">
        <ConductoresHero />
        
        <article className="max-w-5xl mx-auto px-6 py-12">
          <section className="mb-16">
            <div className="bg-[#14B8A6]/10 border-l-4 border-[#14B8A6] p-6 mb-8">
              <p className="text-lg text-gray-700 leading-relaxed">
                <strong>El factor humano es el mayor desafío en la transición a vehículos eléctricos.</strong> Puedes tener los mejores vehículos eléctricos y la infraestructura perfecta, pero si los <strong>conductores rechazan el cambio</strong>, el proyecto fracasará. Esta guía te muestra cómo gestionar la adopción de forma efectiva.
              </p>
            </div>
            <p className="text-lg text-gray-700 leading-relaxed mb-4">
              Según estudios recientes, el <strong>68% de los proyectos de electrificación</strong> enfrentan resistencia inicial de los conductores. Sin embargo, quienes aplican estrategias de gestión del cambio adecuadas logran una <strong>tasa de adopción del 95% en menos de 6 meses</strong>.
            </p>
            <p className="text-lg text-gray-700 leading-relaxed">
              En esta página encontrarás estrategias probadas para evitar el rechazo, diseñar formación efectiva, establecer normas sin generar conflictos y gestionar quejas de forma constructiva.
            </p>
          </section>

          <EvitarRechazo />
          <FormacionMinima />
          <NormasUso />
          <GestionQuejas />
          <ConductoresCTA />
        </article>
      </div>
    </main>
  );
}
