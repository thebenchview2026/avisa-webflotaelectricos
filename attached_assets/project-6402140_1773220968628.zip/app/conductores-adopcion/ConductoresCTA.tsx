
'use client';

import Link from 'next/link';

export default function ConductoresCTA() {
  const preguntasRelacionadas = [
    {
      icono: "ri-user-settings-line",
      titulo: "¿Cómo gestionar la resistencia al cambio?",
      descripcion: "Estrategias para manejar la transición a vehículos eléctricos.",
      href: "/preguntas"
    },
    {
      icono: "ri-graduation-cap-line",
      titulo: "¿Qué formación necesitan los conductores?",
      descripcion: "Programa completo de formación para conductores de vehículos eléctricos.",
      href: "/preguntas"
    },
    {
      icono: "ri-file-text-line",
      titulo: "¿Cómo crear una política de uso efectiva?",
      descripcion: "Guía para establecer normas claras sin generar conflictos con los conductores.",
      href: "/preguntas"
    },
    {
      icono: "ri-refresh-line",
      titulo: "¿Cómo gestionar el cambio organizacional?",
      descripcion: "Plan completo de gestión del cambio para la transición a vehículos eléctricos.",
      href: "/preguntas"
    }
  ];

  return (
    <>
      <section className="py-16 bg-gradient-to-br from-gray-50 to-white -mx-6 px-6">
        <div className="max-w-5xl mx-auto">
          <div className="grid md:grid-cols-2 gap-8">
            <div className="bg-white rounded-2xl shadow-lg p-8 border border-gray-100 flex flex-col">
              <div className="flex-1">
                <div className="w-14 h-14 bg-[#14B8A6]/10 rounded-xl flex items-center justify-center mb-6">
                  <i className="ri-file-list-3-line text-2xl text-[#14B8A6]"></i>
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Análisis Personalizado Gratuito</h3>
                <p className="text-gray-600 mb-6">
                  Descubre el potencial de electrificación con nuestro diagnóstico detallado. Sin compromiso.
                </p>
              </div>
              <Link 
                href="/concesionarios" 
                className="inline-flex items-center justify-center px-8 py-4 bg-[#14B8A6] text-white font-semibold rounded-xl hover:bg-[#0d9488] transition-all duration-300 shadow-lg hover:shadow-xl whitespace-nowrap cursor-pointer"
              >
                Diagnóstico Gratuito
                <i className="ri-arrow-right-line ml-2"></i>
              </Link>
            </div>

            <div className="bg-gradient-to-br from-green-600 to-green-700 rounded-2xl shadow-lg p-8 text-white flex flex-col">
              <div className="flex-1">
                <div className="flex items-start gap-6 mb-6">
                  <img 
                    alt="Ana - Asesora de Vehículos Eléctricos" 
                    className="w-20 h-20 rounded-full object-cover border-4 border-white/30 shadow-lg flex-shrink-0"
                    src="https://static.readdy.ai/image/ecd9e0a88a19846633f9ef23a8543c57/7da821f8687606f5711af9936393378a.jpeg"
                  />
                  <div>
                    <h3 className="text-2xl font-bold mb-2">¿Necesitas Ayuda?</h3>
                    <p className="text-green-50 mb-1"><strong>Ana</strong></p>
                    <p className="text-green-100 text-sm">Especialista en Vehículos Eléctricos e Híbridos</p>
                  </div>
                </div>
                <p className="text-green-50 mb-6">
                  La persona que te va a atender es Ana, lleva más de 10 años como profesional en Avisa y de forma rápida tendrás un asesoramiento directo de alta calidad.
                </p>
              </div>
              <a 
                href="tel:955034600" 
                className="inline-flex items-center justify-center px-8 py-4 bg-white text-green-600 font-semibold rounded-xl hover:bg-green-50 transition-all duration-300 shadow-lg hover:shadow-xl whitespace-nowrap cursor-pointer"
              >
                <i className="ri-phone-line text-xl mr-2"></i>
                Llamar a Ana
              </a>
            </div>
          </div>
        </div>
      </section>

      <section className="mt-16">
        <h2 className="text-2xl font-bold text-gray-900 mb-6">Preguntas Relacionadas</h2>
        <div className="grid md:grid-cols-2 gap-4">
          {preguntasRelacionadas.map((pregunta, index) => (
            <Link 
              key={index}
              href={pregunta.href}
              className="bg-white border border-gray-200 rounded-lg p-6 hover:border-[#14B8A6] hover:shadow-md transition-all cursor-pointer"
            >
              <h3 className="font-bold text-gray-900 mb-2 flex items-center">
                <i className={`${pregunta.icono} text-[#14B8A6] mr-2`}></i>
                {pregunta.titulo}
              </h3>
              <p className="text-gray-600 text-sm">{pregunta.descripcion}</p>
            </Link>
          ))}
        </div>
      </section>
    </>
  );
}
