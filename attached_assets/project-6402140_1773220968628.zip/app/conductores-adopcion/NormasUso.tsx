
'use client';

export default function NormasUso() {
  const normas = [
    {
      titulo: "1. Nivel Mínimo de Carga al Finalizar el Turno",
      norma: "El vehículo debe tener al menos 30% de batería al finalizar la jornada (o el nivel que permita al siguiente conductor completar su ruta).",
      porque: "Garantiza que el siguiente conductor pueda trabajar sin problemas. Es la norma más importante."
    },
    {
      titulo: "2. Uso de Cargadores de la Empresa",
      norma: "Priorizar carga en instalaciones de la empresa. Si se carga en ruta, usar solo cargadores de las redes autorizadas (con tarjeta de empresa).",
      porque: "Control de costes y acceso a tarifas corporativas."
    },
    {
      titulo: "3. Reporte de Incidencias",
      norma: "Cualquier problema técnico, aviso en el cuadro o incidencia de carga debe reportarse el mismo día (por app, email o Whatsapp).",
      porque: "Permite resolver problemas antes de que se agraven y afecten a otros conductores."
    },
    {
      titulo: "4. Carga Nocturna (si aplica)",
      norma: "Los vehículos que pernoctan en la empresa deben conectarse a los cargadores al finalizar la jornada.",
      porque: "Aprovecha tarifas eléctricas nocturnas más baratas y garantiza vehículos listos por la mañana."
    },
    {
      titulo: "5. Límite de Carga Rápida",
      norma: "Usar carga rápida solo cuando sea necesario (rutas largas, urgencias). Para uso diario, priorizar carga lenta.",
      porque: "La carga rápida frecuente puede acelerar la degradación de la batería a largo plazo."
    },
    {
      titulo: "6. Uso Personal del Vehículo",
      norma: "Definir claramente si se permite uso personal (fines de semana, desplazamientos casa-trabajo) y en qué condiciones.",
      porque: "Evita malentendidos y posibles conflictos. Si se permite, especificar responsabilidades sobre carga y limpieza."
    },
    {
      titulo: "7. Limpieza y Mantenimiento Básico",
      norma: "Mantener el vehículo limpio (interior) y reportar necesidades de mantenimiento (neumáticos, limpiaparabrisas, etc.).",
      porque: "Respeto por el siguiente usuario y detección temprana de problemas."
    }
  ];

  const comunicarNormas = [
    {
      titulo: "Co-diseña con los conductores",
      descripcion: "Presenta un borrador y pide feedback. Ajusta según sus comentarios. Las normas co-creadas se cumplen mejor."
    },
    {
      titulo: "Explica el \"por qué\"",
      descripcion: "No impongas reglas sin justificación. Cuando entienden la razón, las aceptan mejor."
    },
    {
      titulo: "Formato simple y visual",
      descripcion: "Crea un documento de 1-2 páginas con iconos y lenguaje claro. Evita textos legales densos."
    },
    {
      titulo: "Periodo de prueba",
      descripcion: "Establece las normas como \"versión 1.0\" y revísalas a los 3 meses según la experiencia real."
    },
    {
      titulo: "Consecuencias claras pero justas",
      descripcion: "Define qué pasa si no se cumplen, pero con enfoque educativo, no punitivo (primera vez: recordatorio, reincidencia: conversación, persistencia: medidas)."
    }
  ];

  const noIncluir = [
    "Microgestión de la carga: \"Debes cargar entre 20% y 80%\" → Deja que gestionen según necesidad",
    "Restricciones de velocidad arbitrarias: \"No superar 110 km/h\" → Confía en su criterio profesional",
    "Obligación de usar modo ECO: Puede ser incómodo en ciertas situaciones",
    "Reportes diarios de consumo: Genera carga administrativa innecesaria",
    "Prohibiciones absolutas sin excepciones: Siempre deja margen para situaciones especiales"
  ];

  return (
    <section className="mb-16">
      <h2 className="text-3xl font-bold text-gray-900 mb-6 flex items-center">
        <span className="w-10 h-10 flex items-center justify-center mr-3">
          <i className="ri-file-list-3-line text-[#14B8A6] text-2xl"></i>
        </span>
        Normas de Uso Sin Fricción
      </h2>

      <p className="text-lg text-gray-700 mb-6">
        Las <strong>normas claras</strong> son necesarias, pero demasiadas reglas generan rechazo. La clave es establecer lo esencial y dar autonomía en el resto.
      </p>

      <div className="bg-yellow-50 border-l-4 border-yellow-500 p-6 mb-8">
        <h4 className="font-bold text-gray-900 mb-2 flex items-center">
          <span className="w-6 h-6 flex items-center justify-center mr-2">
            <i className="ri-alert-line text-yellow-600"></i>
          </span>
          Principio Fundamental
        </h4>
        <p className="text-gray-700">
          <strong>Menos es más.</strong> Establece solo las normas imprescindibles para el funcionamiento operativo. Todo lo demás debe ser recomendación, no obligación.
        </p>
      </div>

      <h3 className="text-2xl font-bold text-gray-900 mb-4">Las 7 Normas Esenciales</h3>
      <div className="space-y-4 mb-8">
        {normas.map((norma, index) => (
          <div key={index} className="bg-white border-l-4 border-[#14B8A6] p-6 rounded-r-lg shadow-sm">
            <h4 className="text-lg font-bold text-gray-900 mb-2">{norma.titulo}</h4>
            <p className="text-gray-700 mb-2"><strong>Norma:</strong> {norma.norma}</p>
            <p className="text-gray-600 text-sm"><strong>Por qué:</strong> {norma.porque}</p>
          </div>
        ))}
      </div>

      <h3 className="text-2xl font-bold text-gray-900 mb-4">Cómo Comunicar las Normas</h3>
      <div className="bg-gray-50 rounded-lg p-6 mb-8">
        <div className="space-y-4">
          {comunicarNormas.map((item, index) => (
            <div key={index} className="flex items-start">
              <div className="w-10 h-10 bg-[#14B8A6] rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                <i className="ri-check-line text-white text-xl"></i>
              </div>
              <div className="ml-4">
                <h4 className="font-bold text-gray-900 mb-1">{item.titulo}</h4>
                <p className="text-gray-700">{item.descripcion}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      <h3 className="text-2xl font-bold text-gray-900 mb-4">Qué NO Incluir en las Normas</h3>
      <div className="bg-red-50 border border-red-200 rounded-lg p-6">
        <p className="text-gray-700 mb-3">Evita normas que generen fricción innecesaria:</p>
        <ul className="space-y-2 text-gray-700">
          {noIncluir.map((item, index) => (
            <li key={index} className="flex items-start">
              <i className="ri-close-circle-line text-red-500 mr-2 mt-1"></i>
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
