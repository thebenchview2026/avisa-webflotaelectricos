
'use client';

export default function FormacionMinima() {
  const modulos = [
    {
      modulo: "Conducción Eficiente",
      duracion: "2 horas",
      formato: "Práctico en ruta",
      contenido: "Regeneración, modo ECO, anticipación, impacto de velocidad y clima"
    },
    {
      modulo: "Gestión de Carga",
      duracion: "1 hora",
      formato: "Teórico + demo",
      contenido: "Tipos de carga, apps, planificación de rutas, qué hacer si no hay cargador"
    },
    {
      modulo: "Mantenimiento Básico",
      duracion: "30 min",
      formato: "Teórico",
      contenido: "Revisiones necesarias, líquidos, neumáticos, frenos, qué NO tocar"
    },
    {
      modulo: "Apps y Herramientas",
      duracion: "30 min",
      formato: "Práctico",
      contenido: "App del vehículo, Electromaps, ABRP, tarjetas de carga, soporte técnico"
    }
  ];

  const modulosDetalle = [
    {
      titulo: "1. Conducción Eficiente (2 horas prácticas)",
      objetivo: "Maximizar autonomía y reducir ansiedad por batería.",
      contenido: [
        "Cómo funciona la regeneración de energía al frenar",
        "Uso de modos de conducción: ECO, Normal, Sport",
        "Impacto de la velocidad: 120 km/h vs 100 km/h = 30% menos autonomía",
        "Efecto del clima: calefacción/AC pueden reducir 20-30% la autonomía",
        "Técnicas de anticipación para maximizar regeneración",
        "Precalentamiento de batería en invierno"
      ],
      metodo: "Ruta real de 50 km con instructor, comparando estilos de conducción y viendo el impacto en tiempo real en el consumo."
    },
    {
      titulo: "2. Gestión de Carga y Autonomía (1 hora)",
      objetivo: "Eliminar el miedo a quedarse sin batería.",
      contenido: [
        "Tipos de carga: lenta (7-11 kW), rápida (50 kW), ultrarrápida (150+ kW)",
        "Cuándo usar cada tipo: carga nocturna vs carga en ruta",
        "Apps esenciales: Electromaps, ABRP (A Better Route Planner), app del fabricante",
        "Cómo planificar rutas largas con paradas de carga",
        "Qué hacer si un cargador está ocupado o no funciona",
        "Tarjetas y apps de pago: cuáles usar, cómo activarlas",
        "Niveles de carga recomendados: 20-80% para uso diario"
      ],
      metodo: "Demostración en vivo de carga en diferentes tipos de cargadores + simulación de planificación de ruta larga."
    },
    {
      titulo: "3. Mantenimiento Básico (30 minutos)",
      objetivo: "Entender qué necesita (y qué NO necesita) un eléctrico.",
      contenido: [
        "Lo que SÍ necesita: revisiones anuales, líquido de frenos cada 2 años, neumáticos, limpiaparabrisas",
        "Lo que NO necesita: cambios de aceite, filtros de aire/combustible, embrague, escape",
        "Frenos: duran 2-3 veces más por la regeneración",
        "Batería: garantía de 8 años/160.000 km, no requiere mantenimiento",
        "Qué NO tocar: sistema de alto voltaje (cables naranjas), batería",
        "Cuándo llamar al servicio técnico: luces de aviso, ruidos extraños, pérdida de potencia"
      ],
      metodo: "Presentación con fotos y vídeos + sesión de preguntas."
    },
    {
      titulo: "4. Apps y Herramientas Digitales (30 minutos)",
      objetivo: "Dominar las herramientas que facilitan el día a día.",
      contenido: [
        "App del fabricante: estado de carga, preclimatización, localización, estadísticas",
        "Electromaps: encontrar cargadores, ver disponibilidad en tiempo real, opiniones",
        "ABRP: planificar rutas largas con paradas de carga óptimas",
        "Apps de pago: Iberdrola, Endesa, Repsol, Wenea (según tarjetas de empresa)",
        "Cómo reportar incidencias: a quién llamar, qué información dar",
        "Soporte técnico 24/7: número de teléfono, chat, email"
      ],
      metodo: "Instalación y configuración en vivo de las apps en los móviles de los conductores."
    }
  ];

  return (
    <section className="mb-16">
      <h2 className="text-3xl font-bold text-gray-900 mb-6 flex items-center">
        <span className="w-10 h-10 flex items-center justify-center mr-3">
          <i className="ri-graduation-cap-line text-[#14B8A6] text-2xl"></i>
        </span>
        Formación Mínima de Conductores
      </h2>

      <p className="text-lg text-gray-700 mb-6">
        Una <strong>formación efectiva</strong> no necesita ser larga, pero sí debe ser práctica y cubrir los aspectos esenciales. Aquí está el programa mínimo recomendado:
      </p>

      <div className="bg-white border border-gray-200 rounded-lg overflow-hidden mb-8">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-sm font-bold text-gray-900">Módulo</th>
                <th className="px-6 py-3 text-left text-sm font-bold text-gray-900">Duración</th>
                <th className="px-6 py-3 text-left text-sm font-bold text-gray-900">Formato</th>
                <th className="px-6 py-3 text-left text-sm font-bold text-gray-900">Contenido Clave</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {modulos.map((mod, index) => (
                <tr key={index}>
                  <td className="px-6 py-4 text-gray-900 font-medium">{mod.modulo}</td>
                  <td className="px-6 py-4 text-gray-700">{mod.duracion}</td>
                  <td className="px-6 py-4 text-gray-700">{mod.formato}</td>
                  <td className="px-6 py-4 text-gray-700">{mod.contenido}</td>
                </tr>
              ))}
              <tr className="bg-[#14B8A6]/10">
                <td className="px-6 py-4 text-gray-900 font-bold">TOTAL</td>
                <td className="px-6 py-4 text-gray-900 font-bold">4 horas</td>
                <td className="px-6 py-4 text-gray-700" colSpan={2}>Formación inicial completa</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      <h3 className="text-2xl font-bold text-gray-900 mb-4">Contenido Detallado por Módulo</h3>
      <div className="space-y-6 mb-8">
        {modulosDetalle.map((mod, index) => (
          <div key={index} className="bg-gray-50 rounded-lg p-6">
            <h4 className="text-xl font-bold text-gray-900 mb-3">{mod.titulo}</h4>
            <div className="space-y-3 text-gray-700">
              <p><strong>Objetivo:</strong> {mod.objetivo}</p>
              <p><strong>Contenido:</strong></p>
              <ul className="list-disc list-inside space-y-1 ml-4">
                {mod.contenido.map((item, idx) => (
                  <li key={idx}>{item}</li>
                ))}
              </ul>
              <p className="mt-3"><strong>Método:</strong> {mod.metodo}</p>
            </div>
          </div>
        ))}
      </div>

      <h3 className="text-2xl font-bold text-gray-900 mb-4">Formación Continua</h3>
      <div className="bg-white border border-gray-200 rounded-lg p-6 mb-8">
        <p className="text-gray-700 mb-4">Además de la formación inicial, programa <strong>sesiones de refuerzo</strong>:</p>
        <ul className="list-disc list-inside space-y-2 text-gray-700">
          <li><strong>Mes 1:</strong> Sesión de dudas y problemas encontrados (1 hora)</li>
          <li><strong>Mes 3:</strong> Técnicas avanzadas de conducción eficiente (1 hora)</li>
          <li><strong>Mes 6:</strong> Evaluación de resultados y mejores prácticas (1 hora)</li>
          <li><strong>Anual:</strong> Actualización sobre nuevas funcionalidades y tecnologías</li>
        </ul>
      </div>

      <div className="bg-[#14B8A6]/10 rounded-lg p-6">
        <h4 className="font-bold text-gray-900 mb-3 flex items-center">
          <span className="w-6 h-6 flex items-center justify-center mr-2">
            <i className="ri-star-line text-[#14B8A6]"></i>
          </span>
          Mejores Prácticas
        </h4>
        <ul className="space-y-2 text-gray-700">
          <li>✓ Formación en <strong>grupos pequeños</strong> (máximo 6 conductores) para mayor interacción</li>
          <li>✓ Prioriza lo <strong>práctico sobre lo teórico</strong>: más test drives, menos PowerPoints</li>
          <li>✓ Graba vídeos cortos (2-3 min) con tips que puedan consultar después</li>
          <li>✓ Crea una <strong>guía rápida en PDF</strong> con lo esencial (1-2 páginas)</li>
          <li>✓ Establece un <strong>canal de Whatsapp</strong> para dudas rápidas entre conductores</li>
        </ul>
      </div>
    </section>
  );
}
