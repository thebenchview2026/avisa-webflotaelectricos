
import Link from 'next/link';

export default function PostventaCTA() {
  return (
    <section className="py-20 bg-gradient-to-r from-[#ad023b] to-[#8d0230]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center text-white">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            ¿Necesitas ayuda con tu vehículo?
          </h2>
          <p className="text-xl text-white/90 mb-10 max-w-2xl mx-auto">
            Nuestro equipo de expertos está disponible para resolver cualquier duda o incidencia. Contacta con nosotros.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <a 
              href="tel:955034600"
              className="inline-flex items-center gap-2 bg-white text-[#ad023b] px-8 py-4 rounded-lg font-bold hover:bg-gray-100 transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-phone-line"></i>
              955 034 600
            </a>
            <Link 
              href="/concesionarios"
              className="inline-flex items-center gap-2 bg-transparent border-2 border-white text-white px-8 py-4 rounded-lg font-bold hover:bg-white/10 transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-map-pin-line"></i>
              Ver concesionarios
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
