
'use client';

import dynamic from 'next/dynamic';
import PostventaHero from './PostventaHero';
import ServicesGrid from './ServicesGrid';

const MaintenancePlans = dynamic(() => import('./MaintenancePlans'), {
  loading: () => <div className="h-96 bg-gray-50 animate-pulse" />
});

const TechnicianTeam = dynamic(() => import('./TechnicianTeam'), {
  loading: () => <div className="h-96 bg-gray-50 animate-pulse" />
});

const AppointmentForm = dynamic(() => import('./AppointmentForm'), {
  loading: () => <div className="h-96 bg-gray-50 animate-pulse" />
});

const PostventaFAQ = dynamic(() => import('./PostventaFAQ'), {
  loading: () => <div className="h-96 bg-gray-50 animate-pulse" />
});

const PostventaCTA = dynamic(() => import('./PostventaCTA'), {
  loading: () => <div className="h-48 bg-gray-50 animate-pulse" />
});

export default function PostventaPage() {
  return (
    <main className="pt-[120px]">
      <PostventaHero />
      <ServicesGrid />
      <MaintenancePlans />
      <TechnicianTeam />
      <AppointmentForm />
      <PostventaFAQ />
      <PostventaCTA />
    </main>
  );
}
