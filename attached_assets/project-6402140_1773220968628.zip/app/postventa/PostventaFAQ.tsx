
'use client';

import { useState } from 'react';

export default function PostventaFAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      question: '¿Cada cuánto tiempo debo hacer la revisión de mi vehículo eléctrico?',
      answer: 'Los vehículos eléctricos requieren menos mantenimiento que los de combustión. Recomendamos una revisión anual o cada 30.000 km, lo que ocurra primero. Sin embargo, es importante seguir las indicaciones específicas del fabricante para tu modelo.'
    },
    {
      question: '¿Qué incluye el diagnóstico de batería de alto voltaje?',
      answer: 'El diagnóstico incluye la comprobación del estado de salud de la batería (SOH), capacidad de carga, equilibrado de celdas, sistema de refrigeración y conectores. Te proporcionamos un informe detallado con el estado actual y recomendaciones.'
    },
    {
      question: '¿Puedo llevar mi vehículo a cualquier concesionario del grupo?',
      answer: 'Sí, puedes llevar tu vehículo a cualquiera de nuestros 9 concesionarios. Todos cuentan con técnicos certificados y equipamiento oficial para atender vehículos Volkswagen, Audi y Škoda.'
    },
    {
      question: '¿Ofrecéis vehículo de sustitución durante la reparación?',
      answer: 'Sí, disponemos de vehículos de cortesía eléctricos para intervenciones que requieran más de un día. Este servicio está incluido en el plan Premium y disponible bajo petición para otros servicios.'
    },
    {
      question: '¿Qué garantía tienen las reparaciones?',
      answer: 'Todas nuestras reparaciones tienen una garantía de 2 años en piezas y mano de obra. Utilizamos exclusivamente piezas originales del fabricante para mantener la garantía oficial de tu vehículo.'
    },
    {
      question: '¿Puedo instalar un punto de carga en mi garaje comunitario?',
      answer: 'Sí, te asesoramos en todo el proceso: estudio de viabilidad, gestión con la comunidad de propietarios, instalación homologada y tramitación de ayudas del Plan MOVES. Contacta con nosotros para un presupuesto sin compromiso.'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Preguntas frecuentes
          </h2>
          <p className="text-lg text-gray-600">
            Resolvemos tus dudas sobre el servicio postventa
          </p>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div 
              key={index}
              className="border border-gray-200 rounded-xl overflow-hidden"
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full flex items-center justify-between p-6 text-left hover:bg-gray-50 transition-colors cursor-pointer"
              >
                <span className="font-semibold text-gray-900 pr-4">{faq.question}</span>
                <i className={`ri-arrow-down-s-line text-xl text-gray-500 transition-transform flex-shrink-0 ${openIndex === index ? 'rotate-180' : ''}`}></i>
              </button>
              {openIndex === index && (
                <div className="px-6 pb-6">
                  <p className="text-gray-600 leading-relaxed">{faq.answer}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
