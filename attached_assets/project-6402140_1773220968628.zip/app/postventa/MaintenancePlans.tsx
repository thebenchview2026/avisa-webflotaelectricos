
export default function MaintenancePlans() {
  const plans = [
    {
      name: 'Revisión Básica',
      price: '89',
      description: 'Mantenimiento esencial para tu vehículo',
      features: [
        'Cambio de aceite y filtro',
        'Revisión de niveles',
        'Inspección visual de frenos',
        'Comprobación de luces',
        'Diagnóstico electrónico básico'
      ],
      highlighted: false
    },
    {
      name: 'Revisión Completa',
      price: '189',
      description: 'Mantenimiento integral recomendado',
      features: [
        'Todo lo de Revisión Básica',
        'Cambio de filtro de aire',
        'Cambio de filtro de habitáculo',
        'Revisión de suspensión',
        'Diagnóstico de batería de alto voltaje',
        'Actualización de software'
      ],
      highlighted: true
    },
    {
      name: 'Revisión Premium',
      price: '289',
      description: 'Servicio completo con extras',
      features: [
        'Todo lo de Revisión Completa',
        'Cambio de líquido de frenos',
        'Alineación y equilibrado',
        'Limpieza de inyectores',
        'Tratamiento antibacteriano A/C',
        'Lavado exterior e interior',
        'Vehículo de sustitución'
      ],
      highlighted: false
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Planes de mantenimiento
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Elige el plan que mejor se adapte a tus necesidades. Todos incluyen mano de obra y piezas originales.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {plans.map((plan, index) => (
            <div 
              key={index}
              className={`rounded-2xl p-8 ${
                plan.highlighted 
                  ? 'bg-gradient-to-b from-[#ad023b] to-[#8d0230] text-white shadow-2xl scale-105' 
                  : 'bg-gray-50 text-gray-900 shadow-lg'
              }`}
            >
              {plan.highlighted && (
                <div className="text-center mb-4">
                  <span className="bg-white/20 text-white text-xs font-bold px-3 py-1 rounded-full">
                    MÁS POPULAR
                  </span>
                </div>
              )}
              <h3 className="text-2xl font-bold mb-2 text-center">{plan.name}</h3>
              <p className={`text-center mb-6 ${plan.highlighted ? 'text-white/80' : 'text-gray-600'}`}>
                {plan.description}
              </p>
              <div className="text-center mb-8">
                <span className="text-5xl font-bold">{plan.price}€</span>
                <span className={`${plan.highlighted ? 'text-white/80' : 'text-gray-500'}`}> / revisión</span>
              </div>
              <ul className="space-y-4 mb-8">
                {plan.features.map((feature, idx) => (
                  <li key={idx} className="flex items-start gap-3">
                    <i className={`ri-check-line text-lg flex-shrink-0 ${plan.highlighted ? 'text-white' : 'text-[#ad023b]'}`}></i>
                    <span className={`text-sm ${plan.highlighted ? 'text-white/90' : 'text-gray-700'}`}>{feature}</span>
                  </li>
                ))}
              </ul>
              <a 
                href="#cita-postventa"
                className={`block text-center py-4 rounded-lg font-bold transition-colors cursor-pointer whitespace-nowrap ${
                  plan.highlighted 
                    ? 'bg-white text-[#ad023b] hover:bg-gray-100' 
                    : 'bg-[#ad023b] text-white hover:bg-[#8d0230]'
                }`}
              >
                Reservar cita
              </a>
            </div>
          ))}
        </div>

        <p className="text-center text-gray-500 text-sm mt-8">
          * Precios orientativos. El precio final puede variar según el modelo de vehículo. Consulta condiciones.
        </p>
      </div>
    </section>
  );
}
