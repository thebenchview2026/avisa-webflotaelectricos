
export default function ServicesGrid() {
  const services = [
    {
      icon: 'ri-tools-line',
      title: 'Mantenimiento especializado',
      description: 'Técnicos certificados en alta tensión y sistemas eléctricos. Diagnóstico avanzado con equipamiento específico.',
      features: [
        'Revisiones oficiales con garantía del fabricante',
        'Diagnóstico de baterías y sistemas de carga',
        'Actualización de software y sistemas'
      ]
    },
    {
      icon: 'ri-shield-check-line',
      title: 'Garantías extendidas',
      description: 'Protección completa para tu inversión. Garantías específicas para baterías y componentes eléctricos.',
      features: [
        'Garantía de batería hasta 8 años o 160.000 km',
        'Cobertura de componentes eléctricos',
        'Asistencia en carretera 24/7'
      ]
    },
    {
      icon: 'ri-battery-charging-line',
      title: 'Asesoramiento en carga',
      description: 'Te ayudamos a instalar tu punto de carga en casa o empresa. Gestión completa de subvenciones.',
      features: [
        'Instalación de wallbox en domicilio',
        'Gestión de ayudas para puntos de recarga',
        'Asesoramiento en tarifas eléctricas'
      ]
    },
    {
      icon: 'ri-car-line',
      title: 'Vehículo de sustitución',
      description: 'Mantén tu movilidad mientras tu vehículo está en el taller. Vehículos de cortesía eléctricos.',
      features: [
        'Vehículos de sustitución eléctricos',
        'Recogida y entrega a domicilio',
        'Cita previa online 24/7'
      ]
    },
    {
      icon: 'ri-file-list-3-line',
      title: 'Presupuestos sin compromiso',
      description: 'Transparencia total en nuestros servicios. Presupuestos detallados antes de cualquier intervención.',
      features: [
        'Presupuesto previo obligatorio',
        'Sin sorpresas en la factura',
        'Piezas originales garantizadas'
      ]
    },
    {
      icon: 'ri-time-line',
      title: 'Servicio express',
      description: 'Intervenciones rápidas para que no pierdas tiempo. Servicio de mantenimiento en el día.',
      features: [
        'Cambio de aceite en 30 minutos',
        'Revisión pre-ITV express',
        'Cambio de neumáticos sin cita'
      ]
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Nuestros servicios
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Ofrecemos un servicio integral para tu vehículo eléctrico o híbrido con los más altos estándares de calidad.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div 
              key={index}
              className="bg-white rounded-xl p-8 shadow-lg hover:shadow-xl transition-shadow"
            >
              <div className="w-14 h-14 flex items-center justify-center bg-[#ad023b]/10 rounded-lg mb-6">
                <i className={`${service.icon} text-2xl text-[#ad023b]`}></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">
                {service.title}
              </h3>
              <p className="text-gray-600 mb-6 leading-relaxed">
                {service.description}
              </p>
              <ul className="space-y-3">
                {service.features.map((feature, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-sm text-gray-700">
                    <i className="ri-check-line text-[#ad023b] text-base mt-0.5 flex-shrink-0"></i>
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
