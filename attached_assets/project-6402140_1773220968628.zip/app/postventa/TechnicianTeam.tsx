export default function TechnicianTeam() {
  const certifications = [
    {
      icon: 'ri-flashlight-line',
      title: 'Certificación Alta Tensión',
      description: 'Todos nuestros técnicos están certificados para trabajar con sistemas de alto voltaje de vehículos eléctricos.'
    },
    {
      icon: 'ri-award-line',
      title: 'Formación Continua',
      description: 'Actualización constante en las últimas tecnologías de Volkswagen, Audi y Škoda.'
    },
    {
      icon: 'ri-cpu-line',
      title: 'Equipamiento Oficial',
      description: 'Herramientas de diagnóstico oficiales y software actualizado de cada marca.'
    },
    {
      icon: 'ri-verified-badge-line',
      title: 'Garantía Oficial',
      description: 'Todas las intervenciones mantienen la garantía oficial del fabricante.'
    }
  ];

  return (
    <section className="py-20 bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              Técnicos especializados en movilidad eléctrica
            </h2>
            <p className="text-white/80 text-lg mb-8 leading-relaxed">
              Nuestro equipo cuenta con más de 50 técnicos certificados en vehículos eléctricos e híbridos. 
              Formación oficial de Volkswagen Group con las últimas tecnologías del sector.
            </p>
            <div className="grid sm:grid-cols-2 gap-6">
              {certifications.map((cert, index) => (
                <div key={index} className="flex items-start gap-4">
                  <div className="w-12 h-12 flex items-center justify-center bg-[#ad023b] rounded-lg flex-shrink-0">
                    <i className={`${cert.icon} text-xl text-white`}></i>
                  </div>
                  <div>
                    <h3 className="font-bold mb-1">{cert.title}</h3>
                    <p className="text-white/70 text-sm">{cert.description}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="relative">
            <img 
              src="https://readdy.ai/api/search-image?query=Professional%20automotive%20technician%20team%20in%20modern%20clean%20workshop%20wearing%20white%20uniforms%20working%20on%20electric%20vehicle%20battery%20system%20high%20tech%20diagnostic%20equipment%20premium%20car%20service%20center%20bright%20lighting&width=480&height=400&seq=technician-team-1&orientation=landscape&format=webp"
              alt="Equipo técnico especializado en vehículos eléctricos"
              className="rounded-2xl shadow-2xl w-full object-cover"
              loading="lazy"
              width={480}
              height={400}
            />
            <div className="absolute -bottom-6 -left-6 bg-[#ad023b] rounded-xl p-6 shadow-xl">
              <div className="text-4xl font-bold">+50</div>
              <div className="text-white/90">Técnicos certificados</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}