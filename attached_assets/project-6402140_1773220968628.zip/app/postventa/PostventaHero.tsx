
export default function PostventaHero() {
  return (
    <section className="relative min-h-[500px] flex items-center">
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{
          backgroundImage: `url('https://readdy.ai/api/search-image?query=Professional%20automotive%20service%20center%20with%20modern%20electric%20vehicle%20being%20serviced%20by%20technicians%20in%20clean%20white%20uniforms%20high%20tech%20diagnostic%20equipment%20bright%20clean%20workshop%20environment%20premium%20car%20dealership%20service%20area&width=1440&height=600&seq=postventa-hero-1&orientation=landscape&format=webp')`
        }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/60 to-transparent"></div>
      </div>
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 w-full">
        <div className="max-w-2xl">
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Servicio Postventa Especializado
          </h1>
          <p className="text-xl text-white/90 mb-8 leading-relaxed">
            Talleres oficiales con técnicos certificados en vehículos eléctricos e híbridos. Tu tranquilidad es nuestra prioridad.
          </p>
          <div className="flex flex-wrap gap-4">
            <a 
              href="#cita-postventa"
              className="inline-flex items-center gap-2 bg-[#ad023b] text-white px-8 py-4 rounded-lg font-bold hover:bg-[#8d0230] transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-calendar-check-line"></i>
              Reservar cita
            </a>
            <a 
              href="tel:+34955034600"
              className="inline-flex items-center gap-2 bg-white text-gray-900 px-8 py-4 rounded-lg font-bold hover:bg-gray-100 transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-phone-line"></i>
              955 034 600
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
