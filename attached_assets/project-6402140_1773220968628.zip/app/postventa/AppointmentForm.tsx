'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function AppointmentForm() {
  const router = useRouter();
  const [formData, setFormData] = useState({
    nombre: '',
    email: '',
    telefono: '',
    matricula: '',
    marca: '',
    modelo: '',
    servicio: '',
    concesionario: '',
    fecha: '',
    hora: '',
    comentarios: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [charCount, setCharCount] = useState(0);
  const [acceptTerms, setAcceptTerms] = useState(false);
  const [acceptMarketing, setAcceptMarketing] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    
    if (name === 'comentarios') {
      if (value.length <= 500) {
        setFormData({ ...formData, [name]: value });
        setCharCount(value.length);
      }
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (formData.comentarios.length > 500 || !acceptTerms) {
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      const formBody = new URLSearchParams(formData as Record<string, string>);
      formBody.append('acepta_terminos', acceptTerms ? 'Sí' : 'No');
      formBody.append('acepta_marketing', acceptMarketing ? 'Sí' : 'No');
      
      const response = await fetch('https://readdy.ai/api/form/d68qlivmvg9ih2c79mv0', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: formBody.toString()
      });
      
      if (response.ok) {
        const params = new URLSearchParams({
          nombre: formData.nombre,
          servicio: formData.servicio,
          concesionario: formData.concesionario,
          fecha: formData.fecha
        });
        router.push(`/confirmacion-cita?${params.toString()}`);
      } else {
        setSubmitStatus('error');
      }
    } catch {
      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="cita-postventa" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12">
          <div>
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              Reserva tu cita online
            </h2>
            <p className="text-lg text-gray-600 mb-8 leading-relaxed">
              Solicita tu cita de forma rápida y sencilla. Nos pondremos en contacto contigo para confirmar la disponibilidad.
            </p>
            
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 flex items-center justify-center bg-[#ad023b]/10 rounded-lg flex-shrink-0">
                  <i className="ri-calendar-check-line text-xl text-[#ad023b]"></i>
                </div>
                <div>
                  <h3 className="font-bold text-gray-900 mb-1">Cita previa online</h3>
                  <p className="text-gray-600 text-sm">Reserva tu cita 24/7 desde cualquier dispositivo.</p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 flex items-center justify-center bg-[#ad023b]/10 rounded-lg flex-shrink-0">
                  <i className="ri-phone-line text-xl text-[#ad023b]"></i>
                </div>
                <div>
                  <h3 className="font-bold text-gray-900 mb-1">Confirmación telefónica</h3>
                  <p className="text-gray-600 text-sm">Te llamamos para confirmar fecha y hora.</p>
                </div>
              </div>
              
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 flex items-center justify-center bg-[#ad023b]/10 rounded-lg flex-shrink-0">
                  <i className="ri-mail-send-line text-xl text-[#ad023b]"></i>
                </div>
                <div>
                  <h3 className="font-bold text-gray-900 mb-1">Recordatorio por email</h3>
                  <p className="text-gray-600 text-sm">Recibirás un recordatorio antes de tu cita.</p>
                </div>
              </div>
            </div>

            <div className="mt-10 p-6 bg-white rounded-xl shadow-lg">
              <h3 className="font-bold text-gray-900 mb-4">Horario de talleres</h3>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Lunes - Viernes</span>
                  <span className="font-medium text-gray-900">08:00 - 20:00</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Sábados</span>
                  <span className="font-medium text-gray-900">09:00 - 14:00</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Domingos</span>
                  <span className="font-medium text-gray-900">Cerrado</span>
                </div>
              </div>
            </div>

            <div className="mt-6 p-6 bg-white rounded-xl shadow-lg">
              <h3 className="font-bold text-gray-900 mb-4">Contacto directo</h3>
              <div className="space-y-3">
                <a 
                  href="tel:+34955034600"
                  className="flex items-center gap-3 text-gray-700 hover:text-[#ad023b] transition-colors cursor-pointer"
                >
                  <div className="w-10 h-10 flex items-center justify-center bg-[#ad023b]/10 rounded-lg">
                    <i className="ri-phone-line text-[#ad023b]"></i>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">Teléfono</div>
                    <div className="font-medium">955 034 600</div>
                  </div>
                </a>
                <a 
                  href="mailto:info@grupoavisa.com"
                  className="flex items-center gap-3 text-gray-700 hover:text-[#ad023b] transition-colors cursor-pointer"
                >
                  <div className="w-10 h-10 flex items-center justify-center bg-[#ad023b]/10 rounded-lg">
                    <i className="ri-mail-line text-[#ad023b]"></i>
                  </div>
                  <div>
                    <div className="text-xs text-gray-500">Email</div>
                    <div className="font-medium">info@grupoavisa.com</div>
                  </div>
                </a>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-xl p-8">
            {submitStatus === 'success' ? (
              <div className="text-center py-12">
                <div className="w-20 h-20 flex items-center justify-center bg-green-100 rounded-full mx-auto mb-6">
                  <i className="ri-check-line text-4xl text-green-600"></i>
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">¡Solicitud enviada!</h3>
                <p className="text-gray-600 mb-6">
                  Hemos recibido tu solicitud de cita. Te contactaremos en breve para confirmar la disponibilidad.
                </p>
                <button 
                  onClick={() => setSubmitStatus('idle')}
                  className="text-[#ad023b] font-medium hover:underline cursor-pointer"
                >
                  Solicitar otra cita
                </button>
              </div>
            ) : (
              <>
                <div className="flex items-start gap-4 mb-6 p-4 bg-[#ad023b]/5 rounded-xl border border-[#ad023b]/10">
                  <img 
                    src="https://static.readdy.ai/image/ecd9e0a88a19846633f9ef23a8543c57/7da821f8687606f5711af9936393378a.jpeg" 
                    alt="Ana - Asesora de vehículos eléctricos"
                    className="w-16 h-16 rounded-full object-cover flex-shrink-0"
                  />
                  <div>
                    <p className="text-sm text-gray-700 leading-relaxed">
                      <span className="font-semibold text-gray-900">La persona que te va a atender es Ana</span>, lleva más de 10 años como profesional de flotas en Avisa y de forma rápida tendrás un asesoramiento directo de alta calidad.
                    </p>
                  </div>
                </div>

                <form id="form-cita-postventa" data-readdy-form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid sm:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Nombre completo *</label>
                      <input 
                        type="text"
                        name="nombre"
                        value={formData.nombre}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#ad023b] focus:border-transparent text-sm"
                        placeholder="Tu nombre"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Email *</label>
                      <input 
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#ad023b] focus:border-transparent text-sm"
                        placeholder="tu@email.com"
                      />
                    </div>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Teléfono *</label>
                      <input 
                        type="tel"
                        name="telefono"
                        value={formData.telefono}
                        onChange={handleChange}
                        required
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#ad023b] focus:border-transparent text-sm"
                        placeholder="600 000 000"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Matrícula</label>
                      <input 
                        type="text"
                        name="matricula"
                        value={formData.matricula}
                        onChange={handleChange}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#ad023b] focus:border-transparent text-sm"
                        placeholder="0000 ABC"
                      />
                    </div>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Marca *</label>
                      <div className="relative">
                        <select 
                          name="marca"
                          value={formData.marca}
                          onChange={handleChange}
                          required
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#ad023b] focus:border-transparent text-sm appearance-none cursor-pointer pr-10"
                        >
                          <option value="">Selecciona marca</option>
                          <option value="Volkswagen">Volkswagen</option>
                          <option value="Audi">Audi</option>
                          <option value="Škoda">Škoda</option>
                        </select>
                        <i className="ri-arrow-down-s-line absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 pointer-events-none"></i>
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Modelo</label>
                      <input 
                        type="text"
                        name="modelo"
                        value={formData.modelo}
                        onChange={handleChange}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#ad023b] focus:border-transparent text-sm"
                        placeholder="Ej: ID.4, e-tron, Enyaq..."
                      />
                    </div>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Tipo de servicio *</label>
                      <div className="relative">
                        <select 
                          name="servicio"
                          value={formData.servicio}
                          onChange={handleChange}
                          required
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#ad023b] focus:border-transparent text-sm appearance-none cursor-pointer pr-10"
                        >
                          <option value="">Selecciona servicio</option>
                          <option value="Revisión básica">Revisión básica</option>
                          <option value="Revisión completa">Revisión completa</option>
                          <option value="Revisión premium">Revisión premium</option>
                          <option value="Diagnóstico de batería">Diagnóstico de batería</option>
                          <option value="Cambio de neumáticos">Cambio de neumáticos</option>
                          <option value="Pre-ITV">Pre-ITV</option>
                          <option value="Reparación">Reparación</option>
                          <option value="Otro">Otro</option>
                        </select>
                        <i className="ri-arrow-down-s-line absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 pointer-events-none"></i>
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Concesionario *</label>
                      <div className="relative">
                        <select 
                          name="concesionario"
                          value={formData.concesionario}
                          onChange={handleChange}
                          required
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#ad023b] focus:border-transparent text-sm appearance-none cursor-pointer pr-10"
                        >
                          <option value="">Selecciona concesionario</option>
                          <option value="Avisa Volkswagen Sevilla">Avisa Volkswagen Sevilla</option>
                          <option value="Avisa Audi Sevilla">Avisa Audi Sevilla</option>
                          <option value="Cartuja Motor Sevilla">Cartuja Motor Sevilla</option>
                          <option value="Cartuja Motor Dos Hermanas">Cartuja Motor Dos Hermanas</option>
                          <option value="Cartuja Motor Huelva">Cartuja Motor Huelva</option>
                          <option value="Avisa Škoda Badajoz">Avisa Škoda Badajoz</option>
                          <option value="Avisa Škoda Cáceres">Avisa Škoda Cáceres</option>
                          <option value="Avisa Škoda Fuente de Cantos">Avisa Škoda Fuente de Cantos</option>
                          <option value="Avisa Škoda Córdoba">Avisa Škoda Córdoba</option>
                        </select>
                        <i className="ri-arrow-down-s-line absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 pointer-events-none"></i>
                      </div>
                    </div>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Fecha preferida</label>
                      <input 
                        type="date"
                        name="fecha"
                        value={formData.fecha}
                        onChange={handleChange}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#ad023b] focus:border-transparent text-sm cursor-pointer"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Hora preferida</label>
                      <div className="relative">
                        <select 
                          name="hora"
                          value={formData.hora}
                          onChange={handleChange}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#ad023b] focus:border-transparent text-sm appearance-none cursor-pointer pr-10"
                        >
                          <option value="">Selecciona hora</option>
                          <option value="08:00">08:00</option>
                          <option value="09:00">09:00</option>
                          <option value="10:00">10:00</option>
                          <option value="11:00">11:00</option>
                          <option value="12:00">12:00</option>
                          <option value="13:00">13:00</option>
                          <option value="16:00">16:00</option>
                          <option value="17:00">17:00</option>
                          <option value="18:00">18:00</option>
                          <option value="19:00">19:00</option>
                        </select>
                        <i className="ri-arrow-down-s-line absolute right-3 top-1/2 -translate-y-1/2 text-gray-500 pointer-events-none"></i>
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">Comentarios adicionales</label>
                    <textarea 
                      name="comentarios"
                      value={formData.comentarios}
                      onChange={handleChange}
                      rows={3}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#ad023b] focus:border-transparent text-sm resize-none"
                      placeholder="Describe brevemente el motivo de tu visita..."
                    ></textarea>
                    <div className="flex justify-between items-center mt-1">
                      <span className={`text-xs ${charCount > 500 ? 'text-red-600' : 'text-gray-500'}`}>
                        {charCount}/500 caracteres
                      </span>
                      {charCount > 500 && (
                        <span className="text-xs text-red-600">Has superado el límite</span>
                      )}
                    </div>
                  </div>

                  {submitStatus === 'error' && (
                    <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                      <p className="text-red-600 text-sm">Ha ocurrido un error. Por favor, inténtalo de nuevo.</p>
                    </div>
                  )}

                  <div className="space-y-3">
                    <label className="flex items-start gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={acceptTerms}
                        onChange={(e) => setAcceptTerms(e.target.checked)}
                        className="mt-1 w-4 h-4 text-[#ad023b] border-gray-300 rounded focus:ring-[#ad023b] cursor-pointer"
                        required
                      />
                      <span className="text-sm text-gray-600">
                        He leído y acepto <a href="/terminos" className="text-[#ad023b] underline hover:text-[#8d0230]">los términos y condiciones de la política de privacidad</a>.
                      </span>
                    </label>
                    
                    <label className="flex items-start gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={acceptMarketing}
                        onChange={(e) => setAcceptMarketing(e.target.checked)}
                        className="mt-1 w-4 h-4 text-[#ad023b] border-gray-300 rounded focus:ring-[#ad023b] cursor-pointer"
                      />
                      <span className="text-sm text-gray-600">
                        Doy mi consentimiento para el tratamiento de mis datos personales con fines de marketing y comerciales (Opcional)
                      </span>
                    </label>
                  </div>

                  <button 
                    type="submit"
                    disabled={isSubmitting || charCount > 500 || !acceptTerms}
                    className="w-full bg-[#ad023b] text-white py-4 rounded-lg font-bold hover:bg-[#8d0230] transition-colors cursor-pointer whitespace-nowrap disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {isSubmitting ? 'Enviando...' : 'Solicitar cita'}
                  </button>

                  <p className="text-xs text-gray-500 text-center">
                    Al enviar este formulario aceptas nuestra política de privacidad.
                  </p>
                </form>
              </>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
