export default function NotFound() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-white px-4">
      <div className="text-center">
        <div className="mb-8">
          <i className="ri-error-warning-line text-8xl text-[#ad023b]"></i>
        </div>
        <h1 className="text-6xl font-bold text-gray-900 mb-4">404</h1>
        <h2 className="text-2xl font-semibold text-gray-700 mb-4">
          Página no encontrada
        </h2>
        <p className="text-gray-600 mb-8 max-w-md mx-auto">
          Lo sentimos, la página que buscas no existe o ha sido movida.
        </p>
        <a
          href="/"
          className="inline-block bg-[#ad023b] hover:bg-[#8d0230] text-white px-8 py-3 rounded-lg font-semibold transition-colors cursor-pointer"
        >
          Volver al inicio
        </a>
      </div>
    </div>
  );
}
