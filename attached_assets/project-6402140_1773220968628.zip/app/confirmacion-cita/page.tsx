
import { Suspense } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import ConfirmacionCitaContent from './ConfirmacionCitaContent';

export default function ConfirmacionCitaPage() {
  return (
    <>
      <Header />
      <Suspense fallback={
        <div className="min-h-screen flex items-center justify-center">
          <div className="animate-spin w-8 h-8 border-4 border-[#ad023b] border-t-transparent rounded-full"></div>
        </div>
      }>
        <ConfirmacionCitaContent />
      </Suspense>
      <Footer />
    </>
  );
}
