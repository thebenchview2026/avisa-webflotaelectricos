
'use client';

import { useState } from 'react';
import Link from 'next/link';

const brands = [
  {
    id: 'volkswagen',
    name: 'Volkswagen',
    logo: 'https://readdy.ai/api/search-image?query=Volkswagen%20logo%20simple%20clean%20vector%20style%20on%20white%20background%20minimalist%20automotive%20brand%20identity&width=80&height=60&seq=vw-logo-h1&orientation=landscape&format=webp',
    models: [
      {
        id: 'golf-gte',
        slug: 'volkswagen-golf-gte',
        name: 'Golf GTE',
        type: 'Híbrido Enchufable',
        price: '379€/mes',
        pvp: '40.900€',
        badge: 'Compacto deportivo',
        image: 'https://readdy.ai/api/search-image?query=Volkswagen%20Golf%20GTE%20plug-in%20hybrid%20in%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20compact%20hatchback&width=480&height=320&seq=vw-golf-gte-1&orientation=landscape&format=webp',
        specs: {
          autonomiaElectrica: '62 km',
          potencia: '245 CV',
          bateria: '13 kWh',
          tiempoCarga: '3h 40min',
          aceleracion: '6.7 s (0-100)',
          consumo: '1.3 l/100km'
        }
      },
      {
        id: 'tiguan-ehybrid',
        slug: 'volkswagen-tiguan-ehybrid',
        name: 'Tiguan eHybrid',
        type: 'Híbrido Enchufable',
        price: '479€/mes',
        pvp: '51.800€',
        badge: 'SUV familiar',
        image: 'https://readdy.ai/api/search-image?query=Volkswagen%20Tiguan%20eHybrid%20plug-in%20hybrid%20SUV%20in%20gray%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20family%20crossover&width=480&height=320&seq=vw-tiguan-ehybrid-1&orientation=landscape&format=webp',
        specs: {
          autonomiaElectrica: '50 km',
          potencia: '245 CV',
          bateria: '13 kWh',
          tiempoCarga: '3h 50min',
          aceleracion: '7.5 s (0-100)',
          consumo: '1.6 l/100km'
        }
      },
      {
        id: 'touareg-ehybrid',
        slug: 'volkswagen-touareg-ehybrid',
        name: 'Touareg eHybrid',
        type: 'Híbrido Enchufable',
        price: '749€/mes',
        pvp: '80.900€',
        badge: 'Premium SUV',
        image: 'https://readdy.ai/api/search-image?query=Volkswagen%20Touareg%20eHybrid%20plug-in%20hybrid%20luxury%20SUV%20in%20black%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20flagship%20crossover&width=480&height=320&seq=vw-touareg-ehybrid-1&orientation=landscape&format=webp',
        specs: {
          autonomiaElectrica: '47 km',
          potencia: '462 CV',
          bateria: '14.3 kWh',
          tiempoCarga: '4h 30min',
          aceleracion: '5.7 s (0-100)',
          consumo: '2.7 l/100km'
        }
      }
    ]
  },
  {
    id: 'audi',
    name: 'Audi',
    logo: 'https://readdy.ai/api/search-image?query=Audi%20logo%20four%20rings%20simple%20clean%20vector%20style%20on%20white%20background%20minimalist%20automotive%20brand%20identity&width=80&height=60&seq=audi-logo-h1&orientation=landscape&format=webp',
    models: [
      {
        id: 'a3-tfsi',
        slug: 'audi-a3-tfsi-e',
        name: 'A3 Sportback TFSI e',
        type: 'Híbrido Enchufable',
        price: '429€/mes',
        pvp: '46.400€',
        badge: 'Compacto premium',
        image: 'https://readdy.ai/api/search-image?query=Audi%20A3%20Sportback%20TFSI%20e%20plug-in%20hybrid%20in%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20premium%20compact%20hatchback&width=480&height=320&seq=audi-a3-tfsi-1&orientation=landscape&format=webp',
        specs: {
          autonomiaElectrica: '78 km',
          potencia: '204 CV',
          bateria: '13 kWh',
          tiempoCarga: '3h 40min',
          aceleracion: '7.6 s (0-100)',
          consumo: '1.2 l/100km'
        }
      },
      {
        id: 'q3-tfsi',
        slug: 'audi-q3-tfsi-e',
        name: 'Q3 TFSI e',
        type: 'Híbrido Enchufable',
        price: '499€/mes',
        pvp: '53.900€',
        badge: 'SUV compacto',
        image: 'https://readdy.ai/api/search-image?query=Audi%20Q3%20TFSI%20e%20plug-in%20hybrid%20SUV%20in%20silver%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20compact%20crossover&width=480&height=320&seq=audi-q3-tfsi-1&orientation=landscape&format=webp',
        specs: {
          autonomiaElectrica: '61 km',
          potencia: '245 CV',
          bateria: '13 kWh',
          tiempoCarga: '3h 45min',
          aceleracion: '7.3 s (0-100)',
          consumo: '1.4 l/100km'
        }
      },
      {
        id: 'q5-tfsi',
        slug: 'audi-q5-tfsi-e',
        name: 'Q5 TFSI e quattro',
        type: 'Híbrido Enchufable',
        price: '649€/mes',
        pvp: '70.100€',
        badge: 'SUV versátil',
        image: 'https://readdy.ai/api/search-image?query=Audi%20Q5%20TFSI%20e%20quattro%20plug-in%20hybrid%20SUV%20in%20dark%20blue%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20premium%20crossover&width=480&height=320&seq=audi-q5-tfsi-1&orientation=landscape&format=webp',
        specs: {
          autonomiaElectrica: '62 km',
          potencia: '367 CV',
          bateria: '17.9 kWh',
          tiempoCarga: '5h 30min',
          aceleracion: '5.3 s (0-100)',
          consumo: '1.9 l/100km'
        }
      }
    ]
  },
  {
    id: 'seat',
    name: 'SEAT',
    logo: 'https://readdy.ai/api/search-image?query=SEAT%20logo%20simple%20clean%20vector%20style%20on%20white%20background%20minimalist%20automotive%20brand%20identity%20red%20color&width=80&height=60&seq=seat-logo-h1&orientation=landscape&format=webp',
    models: [
      {
        id: 'leon-ehybrid',
        slug: 'seat-leon-ehybrid',
        name: 'León e-HYBRID',
        type: 'Híbrido Enchufable',
        price: '349€/mes',
        pvp: '37.700€',
        badge: 'Mejor precio',
        image: 'https://readdy.ai/api/search-image?query=SEAT%20Leon%20e-HYBRID%20plug-in%20hybrid%20in%20red%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20compact%20sporty%20hatchback&width=480&height=320&seq=seat-leon-ehybrid-1&orientation=landscape&format=webp',
        specs: {
          autonomiaElectrica: '63 km',
          potencia: '204 CV',
          bateria: '13 kWh',
          tiempoCarga: '3h 40min',
          aceleracion: '7.5 s (0-100)',
          consumo: '1.2 l/100km'
        }
      },
      {
        id: 'leon-sportstourer',
        slug: 'seat-leon-sportstourer-ehybrid',
        name: 'León Sportstourer e-HYBRID',
        type: 'Híbrido Enchufable',
        price: '369€/mes',
        pvp: '39.900€',
        badge: 'Familiar',
        image: 'https://readdy.ai/api/search-image?query=SEAT%20Leon%20Sportstourer%20e-HYBRID%20plug-in%20hybrid%20wagon%20in%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20family%20estate%20car&width=480&height=320&seq=seat-leon-st-1&orientation=landscape&format=webp',
        specs: {
          autonomiaElectrica: '64 km',
          potencia: '204 CV',
          bateria: '13 kWh',
          tiempoCarga: '3h 40min',
          aceleracion: '7.8 s (0-100)',
          consumo: '1.3 l/100km'
        }
      },
      {
        id: 'tarraco-ehybrid',
        slug: 'seat-tarraco-ehybrid',
        name: 'Tarraco e-HYBRID',
        type: 'Híbrido Enchufable',
        price: '479€/mes',
        pvp: '51.700€',
        badge: '7 plazas',
        image: 'https://readdy.ai/api/search-image?query=SEAT%20Tarraco%20e-HYBRID%20plug-in%20hybrid%20large%20SUV%20in%20gray%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20seven%20seater%20crossover&width=480&height=320&seq=seat-tarraco-1&orientation=landscape&format=webp',
        specs: {
          autonomiaElectrica: '49 km',
          potencia: '245 CV',
          bateria: '13 kWh',
          tiempoCarga: '3h 50min',
          aceleracion: '7.7 s (0-100)',
          consumo: '1.7 l/100km'
        }
      }
    ]
  },
  {
    id: 'cupra',
    name: 'CUPRA',
    logo: 'https://readdy.ai/api/search-image?query=CUPRA%20logo%20simple%20clean%20vector%20style%20on%20white%20background%20minimalist%20automotive%20brand%20identity%20copper%20bronze%20color&width=80&height=60&seq=cupra-logo-h1&orientation=landscape&format=webp',
    models: [
      {
        id: 'leon-ehybrid',
        slug: 'cupra-leon-ehybrid',
        name: 'León e-HYBRID',
        type: 'Híbrido Enchufable',
        price: '399€/mes',
        pvp: '43.100€',
        badge: 'Deportivo',
        image: 'https://readdy.ai/api/search-image?query=CUPRA%20Leon%20e-HYBRID%20plug-in%20hybrid%20in%20copper%20bronze%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20performance%20hatchback&width=480&height=320&seq=cupra-leon-1&orientation=landscape&format=webp',
        specs: {
          autonomiaElectrica: '63 km',
          potencia: '245 CV',
          bateria: '13 kWh',
          tiempoCarga: '3h 40min',
          aceleracion: '6.7 s (0-100)',
          consumo: '1.3 l/100km'
        }
      },
      {
        id: 'formentor-ehybrid',
        slug: 'cupra-formentor-ehybrid',
        name: 'Formentor e-HYBRID',
        type: 'Híbrido Enchufable',
        price: '479€/mes',
        pvp: '51.700€',
        badge: 'SUV Coupé',
        image: 'https://readdy.ai/api/search-image?query=CUPRA%20Formentor%20e-HYBRID%20plug-in%20hybrid%20coupe%20SUV%20in%20dark%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20crossover&width=480&height=320&seq=cupra-formentor-1&orientation=landscape&format=webp',
        specs: {
          autonomiaElectrica: '55 km',
          potencia: '245 CV',
          bateria: '12.8 kWh',
          tiempoCarga: '3h 40min',
          aceleracion: '7.0 s (0-100)',
          consumo: '1.4 l/100km'
        }
      },
      {
        id: 'formentor-vz',
        slug: 'cupra-formentor-vz-ehybrid',
        name: 'Formentor VZ e-HYBRID',
        type: 'Híbrido Enchufable',
        price: '549€/mes',
        pvp: '59.300€',
        badge: 'Máxima potencia',
        image: 'https://readdy.ai/api/search-image?query=CUPRA%20Formentor%20VZ%20e-HYBRID%20plug-in%20hybrid%20performance%20SUV%20in%20matte%20gray%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20high%20performance%20crossover&width=480&height=320&seq=cupra-formentor-vz-1&orientation=landscape&format=webp',
        specs: {
          autonomiaElectrica: '58 km',
          potencia: '245 CV',
          bateria: '12.8 kWh',
          tiempoCarga: '3h 40min',
          aceleracion: '7.0 s (0-100)',
          consumo: '1.5 l/100km'
        }
      }
    ]
  },
  {
    id: 'skoda',
    name: 'Skoda',
    logo: 'https://readdy.ai/api/search-image?query=Skoda%20logo%20simple%20clean%20vector%20style%20on%20white%20background%20minimalist%20automotive%20brand%20identity%20green%20arrow&width=80&height=60&seq=skoda-logo-h1&orientation=landscape&format=webp',
    models: [
      {
        id: 'octavia-iv',
        slug: 'skoda-octavia-iv',
        name: 'Octavia iV',
        type: 'Híbrido Enchufable',
        price: '359€/mes',
        pvp: '38.800€',
        badge: 'Berlina eficiente',
        image: 'https://readdy.ai/api/search-image?query=Skoda%20Octavia%20iV%20plug-in%20hybrid%20sedan%20in%20silver%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20practical%20family%20car&width=480&height=320&seq=skoda-octavia-iv-1&orientation=landscape&format=webp',
        specs: {
          autonomiaElectrica: '62 km',
          potencia: '204 CV',
          bateria: '13 kWh',
          tiempoCarga: '3h 40min',
          aceleracion: '7.7 s (0-100)',
          consumo: '1.2 l/100km'
        }
      },
      {
        id: 'octavia-combi-iv',
        slug: 'skoda-octavia-combi-iv',
        name: 'Octavia Combi iV',
        type: 'Híbrido Enchufable',
        price: '379€/mes',
        pvp: '40.900€',
        badge: 'Familiar espacioso',
        image: 'https://readdy.ai/api/search-image?query=Skoda%20Octavia%20Combi%20iV%20plug-in%20hybrid%20wagon%20in%20green%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20spacious%20estate%20car&width=480&height=320&seq=skoda-octavia-combi-1&orientation=landscape&format=webp',
        specs: {
          autonomiaElectrica: '63 km',
          potencia: '204 CV',
          bateria: '13 kWh',
          tiempoCarga: '3h 40min',
          aceleracion: '7.8 s (0-100)',
          consumo: '1.3 l/100km'
        }
      },
      {
        id: 'superb-iv',
        slug: 'skoda-superb-iv',
        name: 'Superb iV',
        type: 'Híbrido Enchufable',
        price: '499€/mes',
        pvp: '53.900€',
        badge: 'Berlina premium',
        image: 'https://readdy.ai/api/search-image?query=Skoda%20Superb%20iV%20plug-in%20hybrid%20executive%20sedan%20in%20black%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20luxury%20business%20car&width=480&height=320&seq=skoda-superb-iv-1&orientation=landscape&format=webp',
        specs: {
          autonomiaElectrica: '55 km',
          potencia: '218 CV',
          bateria: '13 kWh',
          tiempoCarga: '3h 50min',
          aceleracion: '7.7 s (0-100)',
          consumo: '1.5 l/100km'
        }
      }
    ]
  }
];

export default function BrandModelsSection() {
  const [activeBrand, setActiveBrand] = useState('volkswagen');
  const [expandedModel, setExpandedModel] = useState<string | null>(null);

  const currentBrand = brands.find(b => b.id === activeBrand);

  return (
    <section id="modelos" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="inline-block px-4 py-2 bg-[#ad023b]/10 text-[#ad023b] text-sm font-bold rounded-full mb-4">
            Catálogo completo
          </div>
          <h2 className="font-['Playfair_Display'] text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Modelos híbridos enchufables por marca
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Descubre nuestra selección de vehículos híbridos enchufables. Elige una marca para explorar todos los modelos con sus especificaciones técnicas completas.
          </p>
        </div>

        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {brands.map((brand) => (
            <button
              key={brand.id}
              onClick={() => {
                setActiveBrand(brand.id);
                setExpandedModel(null);
              }}
              className={`px-6 py-3 rounded-xl font-bold text-sm transition-all cursor-pointer whitespace-nowrap ${
                activeBrand === brand.id
                  ? 'bg-[#ad023b] text-white shadow-lg'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              {brand.name}
            </button>
          ))}
        </div>

        {currentBrand && (
          <div className="space-y-6">
            <div className="flex items-center gap-4 mb-8">
              <div className="h-px flex-1 bg-slate-200"></div>
              <h3 className="text-xl font-bold text-gray-900">{currentBrand.name}</h3>
              <div className="h-px flex-1 bg-slate-200"></div>
            </div>

            <div className="grid md:grid-cols-3 gap-6" data-product-shop>
              {currentBrand.models.map((model) => (
                <div
                  key={model.id}
                  className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 border border-gray-100 flex flex-col"
                >
                  <div className="relative">
                    <div className="w-full h-52 bg-slate-100">
                      <img
                        src={model.image}
                        alt={`${currentBrand.name} ${model.name}`}
                        className="w-full h-full object-cover object-top"
                        loading="lazy"
                        width={480}
                        height={320}
                      />
                    </div>
                    <div className="absolute top-3 right-3 bg-[#ad023b] text-white px-3 py-1.5 rounded-full text-xs font-bold shadow-lg">
                      {model.badge}
                    </div>
                    <div className="absolute top-3 left-3 bg-blue-500 text-white px-3 py-1.5 rounded-full text-xs font-bold shadow-lg flex items-center gap-1">
                      <i className="ri-plug-line"></i>
                      {model.type}
                    </div>
                  </div>

                  <div className="p-5 flex flex-col flex-grow">
                    <div className="mb-4">
                      <div className="text-xs text-gray-500 mb-1 uppercase tracking-wide">
                        {currentBrand.name}
                      </div>
                      <h4 className="text-xl font-bold text-gray-900 mb-2">
                        {model.name}
                      </h4>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="bg-slate-50 rounded-lg p-3 text-center">
                        <div className="text-xs text-gray-500 mb-1">Autonomía EV</div>
                        <div className="font-bold text-gray-900">{model.specs.autonomiaElectrica}</div>
                      </div>
                      <div className="bg-slate-50 rounded-lg p-3 text-center">
                        <div className="text-xs text-gray-500 mb-1">Potencia</div>
                        <div className="font-bold text-gray-900">{model.specs.potencia}</div>
                      </div>
                    </div>

                    <button
                      onClick={() => setExpandedModel(expandedModel === model.id ? null : model.id)}
                      className="text-sm text-[#ad023b] font-medium flex items-center gap-1 mb-4 cursor-pointer hover:underline"
                    >
                      {expandedModel === model.id ? 'Ocultar ficha técnica' : 'Ver ficha técnica completa'}
                      <i className={`ri-arrow-${expandedModel === model.id ? 'up' : 'down'}-s-line`}></i>
                    </button>

                    {expandedModel === model.id && (
                      <div className="bg-slate-50 rounded-lg p-4 mb-4 space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-600">Batería</span>
                          <span className="font-medium text-gray-900">{model.specs.bateria}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Tiempo de carga</span>
                          <span className="font-medium text-gray-900">{model.specs.tiempoCarga}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">0-100 km/h</span>
                          <span className="font-medium text-gray-900">{model.specs.aceleracion}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Consumo mixto</span>
                          <span className="font-medium text-gray-900">{model.specs.consumo}</span>
                        </div>
                      </div>
                    )}

                    <div className="flex items-end justify-between mb-5 mt-auto">
                      <div>
                        <div className="text-2xl font-bold text-gray-900">{model.price}</div>
                        <div className="text-xs text-gray-500">desde / 48 meses</div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-medium text-gray-900">{model.pvp}</div>
                        <div className="text-xs text-gray-500">PVP</div>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <Link
                        href={`/vehiculos/hibridos/${model.slug}`}
                        className="flex-1 bg-[#ad023b] text-white text-center py-3 rounded-lg text-sm font-bold hover:bg-[#8a0230] transition-colors cursor-pointer whitespace-nowrap"
                      >
                        Ver ficha completa
                      </Link>
                      <Link
                        href={`/vehiculos/hibridos/${model.slug}#configurador`}
                        className="w-12 h-12 flex items-center justify-center bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors cursor-pointer"
                        title="Configurar cuota"
                      >
                        <i className="ri-settings-3-line text-xl"></i>
                      </Link>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="mt-12 bg-amber-50 border border-amber-200 rounded-lg p-6">
          <div className="flex items-start gap-4">
            <div className="w-6 h-6 flex items-center justify-center flex-shrink-0">
              <i className="ri-information-line text-xl text-amber-600"></i>
            </div>
            <div>
              <h4 className="font-bold text-slate-900 mb-2">Promociones sujetas a disponibilidad</h4>
              <p className="text-slate-700 text-sm leading-relaxed">
                Las cuotas mostradas son orientativas e incluyen IVA. Pueden variar según financiación, entrada y condiciones específicas. Plan MOVES sujeto a aprobación y disponibilidad de fondos. Consulta condiciones en tu concesionario Grupo Avisa.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
