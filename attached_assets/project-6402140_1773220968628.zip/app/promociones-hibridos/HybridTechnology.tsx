
'use client';

export default function HybridTechnology() {
  const technologies = [
    {
      icon: 'ri-battery-charge-line',
      title: 'Doble motorización',
      description: 'Combina un motor eléctrico con uno de combustión, permitiendo conducción 100% eléctrica en ciudad y autonomía extendida en carretera.'
    },
    {
      icon: 'ri-plug-line',
      title: 'Carga enchufable',
      description: 'Recarga la batería en casa o en el trabajo. Carga completa en 3-4 horas con cargador doméstico o 1,5 horas en punto de carga rápida.'
    },
    {
      icon: 'ri-leaf-line',
      title: 'Etiqueta ECO',
      description: 'Acceso a zonas de bajas emisiones, descuentos en peajes y aparcamiento, y ventajas fiscales en impuesto de matriculación.'
    },
    {
      icon: 'ri-dashboard-3-line',
      title: 'Gestión inteligente',
      description: 'El sistema selecciona automáticamente el modo más eficiente según las condiciones de conducción y el nivel de batería.'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-['Playfair_Display'] text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Tecnología híbrida enchufable
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Los vehículos híbridos enchufables (PHEV) combinan lo mejor de la movilidad eléctrica con la versatilidad de un motor de combustión. La solución perfecta para quienes buscan eficiencia sin renunciar a la autonomía.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {technologies.map((tech, index) => (
            <div key={index} className="bg-slate-50 rounded-xl p-6 hover:shadow-lg transition-shadow">
              <div className="w-14 h-14 flex items-center justify-center bg-green-600 text-white rounded-xl mb-4">
                <i className={`${tech.icon} text-2xl`}></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">{tech.title}</h3>
              <p className="text-gray-600 text-sm leading-relaxed">{tech.description}</p>
            </div>
          ))}
        </div>

        <div className="bg-gradient-to-br from-green-900 to-green-800 rounded-2xl overflow-hidden">
          <div className="grid lg:grid-cols-2 gap-0">
            <div className="p-10 lg:p-12 flex flex-col justify-center">
              <h3 className="font-['Playfair_Display'] text-2xl md:text-3xl font-bold text-white mb-6">
                ¿Cómo funciona un híbrido enchufable?
              </h3>
              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 flex items-center justify-center bg-green-500 text-white rounded-full flex-shrink-0 font-bold text-sm">1</div>
                  <div>
                    <p className="font-semibold text-white">Modo eléctrico puro</p>
                    <p className="text-white/70 text-sm">Circula hasta 75 km usando solo el motor eléctrico, ideal para ciudad.</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 flex items-center justify-center bg-green-500 text-white rounded-full flex-shrink-0 font-bold text-sm">2</div>
                  <div>
                    <p className="font-semibold text-white">Modo híbrido inteligente</p>
                    <p className="text-white/70 text-sm">El sistema combina ambos motores para máxima eficiencia en carretera.</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 flex items-center justify-center bg-green-500 text-white rounded-full flex-shrink-0 font-bold text-sm">3</div>
                  <div>
                    <p className="font-semibold text-white">Regeneración de energía</p>
                    <p className="text-white/70 text-sm">Recupera energía al frenar y desacelerar, recargando la batería.</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 flex items-center justify-center bg-green-500 text-white rounded-full flex-shrink-0 font-bold text-sm">4</div>
                  <div>
                    <p className="font-semibold text-white">Carga externa</p>
                    <p className="text-white/70 text-sm">Conecta a la red eléctrica para recargar completamente la batería.</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="relative min-h-[400px]">
              <img
                src="https://readdy.ai/api/search-image?query=detailed%20cutaway%20technical%20illustration%20of%20plug-in%20hybrid%20vehicle%20powertrain%20showing%20battery%20pack%20electric%20motor%20and%20combustion%20engine%2C%20clean%20modern%20infographic%20style%20with%20green%20accent%20lighting%20on%20dark%20background%2C%20professional%20automotive%20engineering%20visualization&width=800&height=600&seq=phev-tech-cutaway-1&orientation=landscape&format=webp"
                alt="Tecnología híbrido enchufable"
                className="absolute inset-0 w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
