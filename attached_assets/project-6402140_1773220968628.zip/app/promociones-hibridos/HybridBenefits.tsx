
'use client';

export default function HybridBenefits() {
  const benefits = [
    {
      icon: 'ri-money-euro-circle-line',
      title: 'Ahorro en combustible',
      description: 'Reduce hasta un 70% el gasto en combustible en uso urbano y periurbano gracias al modo eléctrico.'
    },
    {
      icon: 'ri-shield-check-line',
      title: 'Sin ansiedad de autonomía',
      description: 'El motor de combustión garantiza autonomía ilimitada para viajes largos sin preocupaciones.'
    },
    {
      icon: 'ri-government-line',
      title: 'Ventajas fiscales',
      description: 'Descuentos en impuesto de matriculación, circulación y beneficios en zonas de bajas emisiones.'
    },
    {
      icon: 'ri-parking-box-line',
      title: 'Aparcamiento gratuito',
      description: 'Estacionamiento gratuito o con descuento en zonas reguladas de las principales ciudades.'
    },
    {
      icon: 'ri-home-4-line',
      title: 'Carga en casa',
      description: 'Recarga cómodamente durante la noche en tu garaje con un simple enchufe doméstico.'
    },
    {
      icon: 'ri-gift-line',
      title: 'Ayudas Plan MOVES',
      description: 'Hasta 5.000€ de subvención directa gestionada íntegramente por Grupo Avisa.'
    }
  ];

  return (
    <section className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-['Playfair_Display'] text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Ventajas de los híbridos enchufables
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Descubre por qué cada vez más conductores eligen un híbrido enchufable como su próximo vehículo
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {benefits.map((benefit, index) => (
            <div key={index} className="bg-white rounded-xl p-6 shadow-sm hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 flex items-center justify-center bg-green-100 text-green-600 rounded-xl mb-4">
                <i className={`${benefit.icon} text-2xl`}></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">{benefit.title}</h3>
              <p className="text-gray-600 text-sm leading-relaxed">{benefit.description}</p>
            </div>
          ))}
        </div>

        <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
          <div className="p-8 border-b border-gray-100">
            <h3 className="font-['Playfair_Display'] text-2xl font-bold text-gray-900 text-center">
              Comparativa: Híbrido enchufable vs Combustión
            </h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-slate-50">
                <tr>
                  <th className="px-6 py-4 text-left text-sm font-bold text-gray-900">Concepto</th>
                  <th className="px-6 py-4 text-center text-sm font-bold text-green-600">Híbrido Enchufable</th>
                  <th className="px-6 py-4 text-center text-sm font-bold text-gray-500">Combustión</th>
                  <th className="px-6 py-4 text-center text-sm font-bold text-gray-900">Ahorro anual</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                <tr>
                  <td className="px-6 py-4 text-sm text-gray-900 font-medium">Combustible (15.000 km/año)</td>
                  <td className="px-6 py-4 text-center text-sm text-green-600 font-semibold">450€</td>
                  <td className="px-6 py-4 text-center text-sm text-gray-500">1.500€</td>
                  <td className="px-6 py-4 text-center text-sm text-green-600 font-bold">1.050€</td>
                </tr>
                <tr className="bg-slate-50/50">
                  <td className="px-6 py-4 text-sm text-gray-900 font-medium">Impuesto de circulación</td>
                  <td className="px-6 py-4 text-center text-sm text-green-600 font-semibold">75% descuento</td>
                  <td className="px-6 py-4 text-center text-sm text-gray-500">100%</td>
                  <td className="px-6 py-4 text-center text-sm text-green-600 font-bold">~100€</td>
                </tr>
                <tr>
                  <td className="px-6 py-4 text-sm text-gray-900 font-medium">Mantenimiento</td>
                  <td className="px-6 py-4 text-center text-sm text-green-600 font-semibold">300€/año</td>
                  <td className="px-6 py-4 text-center text-sm text-gray-500">500€/año</td>
                  <td className="px-6 py-4 text-center text-sm text-green-600 font-bold">200€</td>
                </tr>
                <tr className="bg-slate-50/50">
                  <td className="px-6 py-4 text-sm text-gray-900 font-medium">Aparcamiento regulado</td>
                  <td className="px-6 py-4 text-center text-sm text-green-600 font-semibold">Gratuito/Descuento</td>
                  <td className="px-6 py-4 text-center text-sm text-gray-500">~600€/año</td>
                  <td className="px-6 py-4 text-center text-sm text-green-600 font-bold">~500€</td>
                </tr>
                <tr>
                  <td className="px-6 py-4 text-sm text-gray-900 font-medium">Peajes urbanos</td>
                  <td className="px-6 py-4 text-center text-sm text-green-600 font-semibold">Exento</td>
                  <td className="px-6 py-4 text-center text-sm text-gray-500">Variable</td>
                  <td className="px-6 py-4 text-center text-sm text-green-600 font-bold">~200€</td>
                </tr>
              </tbody>
              <tfoot className="bg-green-50">
                <tr>
                  <td className="px-6 py-4 text-sm font-bold text-gray-900">AHORRO TOTAL ANUAL</td>
                  <td className="px-6 py-4"></td>
                  <td className="px-6 py-4"></td>
                  <td className="px-6 py-4 text-center text-lg font-bold text-green-600">~2.050€</td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
}
