
import dynamic from 'next/dynamic';
import PromoHibridosHero from './PromoHibridosHero';
import HybridTechnology from './HybridTechnology';

const HybridBenefits = dynamic(() => import('./HybridBenefits'), {
  loading: () => <div className="h-96 bg-gray-50 animate-pulse" />
});

const BrandModelsSection = dynamic(() => import('./BrandModelsSection'), {
  loading: () => <div className="h-96 bg-gray-50 animate-pulse" />
});

const HybridCTA = dynamic(() => import('./HybridCTA'), {
  loading: () => <div className="h-48 bg-gray-50 animate-pulse" />
});

export default function PromocionesHibridosPage() {
  return (
    <main className="min-h-screen bg-white pt-[120px]">
      <PromoHibridosHero />
      <HybridTechnology />
      <HybridBenefits />
      <BrandModelsSection />
      <HybridCTA />
    </main>
  );
}
