import Link from 'next/link';

export default function FAQContact() {
  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-gradient-to-r from-[#ad023b] to-[#8d0230] rounded-3xl p-12 text-center relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2"></div>
          <div className="absolute bottom-0 left-0 w-48 h-48 bg-white/10 rounded-full translate-y-1/2 -translate-x-1/2"></div>
          
          <div className="relative">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              ¿No encuentras lo que buscas?
            </h2>
            <p className="text-xl text-white/90 max-w-2xl mx-auto mb-8">
              Nuestro equipo de expertos en movilidad eléctrica está disponible para resolver cualquier duda
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
              <Link
                href="/concesionarios"
                className="inline-flex items-center justify-center gap-2 bg-white text-[#ad023b] px-8 py-4 rounded-full font-bold hover:bg-gray-100 transition-colors cursor-pointer whitespace-nowrap"
              >
                <i className="ri-map-pin-line text-xl"></i>
                Visitar concesionario
              </Link>
              <a
                href="tel:+34955034600"
                className="inline-flex items-center justify-center gap-2 bg-white/20 text-white px-8 py-4 rounded-full font-bold hover:bg-white/30 transition-colors cursor-pointer whitespace-nowrap"
              >
                <i className="ri-phone-line text-xl"></i>
                Llámame
              </a>
              <a
                href="https://wa.me/34955034600"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 bg-[#25D366] text-white px-8 py-4 rounded-full font-bold hover:bg-[#20BD5A] transition-colors cursor-pointer whitespace-nowrap"
              >
                <i className="ri-whatsapp-line text-xl"></i>
                Escríbeme
              </a>
            </div>

            <div className="flex items-center justify-center gap-2 text-white/80">
              <i className="ri-mail-line text-xl"></i>
              <a href="mailto:info@grupoavisa.com" className="hover:text-white transition-colors cursor-pointer">
                info@grupoavisa.com
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
