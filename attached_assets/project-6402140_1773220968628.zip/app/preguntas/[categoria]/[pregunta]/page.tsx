
import QuestionDetailPage from './QuestionDetailPage';

export async function generateStaticParams() {
  return [
    { categoria: 'autonomia', pregunta: 'cuantos-kilometros-coche-electrico' },
    { categoria: 'autonomia', pregunta: 'autonomia-invierno' },
    { categoria: 'autonomia', pregunta: 'autonomia-real-vs-homologada' },
    { categoria: 'carga', pregunta: 'tiempo-carga-coche-electrico' },
    { categoria: 'carga', pregunta: 'punto-carga-garaje-comunitario' },
    { categoria: 'carga', pregunta: 'tipos-conectores-carga' },
    { categoria: 'carga', pregunta: 'cargar-coche-electrico-lluvia' },
    { categoria: 'costes', pregunta: 'cuanto-cuesta-cargar-coche-electrico' },
    { categoria: 'costes', pregunta: 'mantenimiento-coche-electrico' },
    { categoria: 'costes', pregunta: 'seguro-coche-electrico' },
    { categoria: 'ayudas', pregunta: 'ayudas-comprar-coche-electrico' },
    { categoria: 'ayudas', pregunta: 'plan-moves-grupo-avisa' },
    { categoria: 'ayudas', pregunta: 'combinar-ayudas-plan-moves' },
    { categoria: 'ayudas', pregunta: 'requisitos-plan-moves' },
    { categoria: 'uso-diario', pregunta: 'coche-electrico-viajes-largos' },
    { categoria: 'uso-diario', pregunta: 'remolcar-coche-electrico' },
    { categoria: 'uso-diario', pregunta: 'coche-electrico-familia' },
    { categoria: 'mantenimiento', pregunta: 'revision-coche-electrico' },
    { categoria: 'mantenimiento', pregunta: 'duracion-bateria-coche-electrico' },
    { categoria: 'mantenimiento', pregunta: 'garantia-bateria-electrico' },
  ];
}

export default function Page({ params }: { params: { categoria: string; pregunta: string } }) {
  return <QuestionDetailPage categoria={params.categoria} pregunta={params.pregunta} />;
}
