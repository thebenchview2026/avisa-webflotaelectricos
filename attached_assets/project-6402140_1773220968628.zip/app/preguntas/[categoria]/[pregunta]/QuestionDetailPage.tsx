'use client';

import { useState } from 'react';
import Link from 'next/link';

const allQuestions: Record<string, { 
  q: string; 
  answer: string; 
  videoId: string;
  category: string;
  categoryName: string;
  relatedQuestions: { id: string; categoria: string; q: string }[];
}> = {
  'cuantos-kilometros-coche-electrico': {
    q: '¿Cuántos kilómetros puedo recorrer con un coche eléctrico?',
    answer: `Los vehículos eléctricos actuales ofrecen entre 300 y 600 km de autonomía real, dependiendo del modelo y las condiciones de uso.

**Ejemplos de autonomía por modelo:**
- **Tesla Model 3 Long Range**: hasta 580 km
- **Volkswagen ID.4 Pro**: hasta 520 km
- **Audi Q4 e-tron**: hasta 520 km
- **Škoda Enyaq iV 80**: hasta 510 km
- **Volkswagen ID.3 Pro S**: hasta 550 km

**Factores que afectan la autonomía:**
1. **Estilo de conducción**: Una conducción eficiente puede aumentar la autonomía hasta un 20%
2. **Climatología**: El frío extremo puede reducir la autonomía entre un 10-30%
3. **Velocidad**: A velocidades de autopista (120+ km/h) el consumo aumenta significativamente
4. **Uso de climatización**: El aire acondicionado y la calefacción consumen energía adicional
5. **Carga del vehículo**: Más peso implica mayor consumo

**Consejo práctico**: Para el uso diario (trabajo, compras, ocio), la mayoría de usuarios recorren menos de 50 km al día, por lo que cualquier eléctrico actual cubre sobradamente estas necesidades con una sola carga semanal.`,
    videoId: 'dQw4w9WgXcQ',
    category: 'autonomia',
    categoryName: 'Autonomía',
    relatedQuestions: [
      { id: 'autonomia-invierno', categoria: 'autonomia', q: '¿La autonomía disminuye en invierno?' },
      { id: 'autonomia-real-vs-homologada', categoria: 'autonomia', q: '¿Qué diferencia hay entre autonomía real y homologada?' },
      { id: 'coche-electrico-viajes-largos', categoria: 'uso-diario', q: '¿Es práctico un coche eléctrico para viajes largos?' },
    ]
  },
  'autonomia-invierno': {
    q: '¿La autonomía disminuye en invierno?',
    answer: `Sí, en condiciones de frío extremo la autonomía puede reducirse entre un 10-30%. Esto se debe principalmente a dos factores:

**1. Comportamiento de la batería**
Las baterías de iones de litio funcionan de forma menos eficiente a bajas temperaturas. Las reacciones químicas que generan electricidad se ralentizan con el frío.

**2. Uso de calefacción**
A diferencia de los coches de combustión que aprovechan el calor residual del motor, los eléctricos deben generar calor activamente, lo que consume energía de la batería.

**Soluciones de los fabricantes:**
- **Precondicionamiento**: Calentar el coche mientras está enchufado, sin gastar batería
- **Bombas de calor**: Sistemas más eficientes que las resistencias tradicionales (disponibles en VW ID.3/ID.4, Audi Q4 e-tron, Škoda Enyaq)
- **Gestión térmica activa**: Mantiene la batería en temperatura óptima

**Consejos para maximizar autonomía en invierno:**
1. Precalienta el coche mientras está conectado al cargador
2. Usa los asientos y volante calefactables en lugar de la calefacción general
3. Aparca en garaje siempre que sea posible
4. Planifica rutas con cargadores si vas a hacer viajes largos`,
    videoId: 'dQw4w9WgXcQ',
    category: 'autonomia',
    categoryName: 'Autonomía',
    relatedQuestions: [
      { id: 'cuantos-kilometros-coche-electrico', categoria: 'autonomia', q: '¿Cuántos kilómetros puedo recorrer con un coche eléctrico?' },
      { id: 'duracion-bateria-coche-electrico', categoria: 'mantenimiento', q: '¿Cuánto dura la batería de un coche eléctrico?' },
    ]
  },
  'autonomia-real-vs-homologada': {
    q: '¿Qué diferencia hay entre autonomía real y homologada?',
    answer: `La autonomía homologada se mide en condiciones de laboratorio según el ciclo WLTP (Worldwide Harmonised Light Vehicle Test Procedure), mientras que la autonomía real depende de las condiciones de uso.

**Ciclo WLTP:**
- Pruebas en laboratorio con temperatura controlada (23°C)
- Velocidades medias moderadas
- Sin uso de climatización
- Neumáticos y presión específicos

**En la práctica:**
La autonomía real suele ser un 10-20% inferior a la homologada, dependiendo de:
- Conducción en autopista vs ciudad
- Uso de aire acondicionado o calefacción
- Estilo de conducción
- Condiciones meteorológicas

**Ejemplo práctico:**
Un Volkswagen ID.4 con 520 km de WLTP puede ofrecer:
- 450-480 km en uso mixto real
- 350-400 km en autopista a 120 km/h
- 500+ km en ciudad con conducción eficiente

**Consejo**: Calcula tu autonomía real restando un 15% a la cifra WLTP para tener una estimación conservadora.`,
    videoId: 'dQw4w9WgXcQ',
    category: 'autonomia',
    categoryName: 'Autonomía',
    relatedQuestions: [
      { id: 'cuantos-kilometros-coche-electrico', categoria: 'autonomia', q: '¿Cuántos kilómetros puedo recorrer con un coche eléctrico?' },
      { id: 'coche-electrico-viajes-largos', categoria: 'uso-diario', q: '¿Es práctico un coche eléctrico para viajes largos?' },
    ]
  },
  'autonomia-conduccion-deportiva': {
    q: '¿Cómo afecta la conducción deportiva a la autonomía?',
    answer: `La conducción deportiva puede reducir significativamente la autonomía de un coche eléctrico, pero también ofrece una experiencia de conducción única.

**Impacto en la autonomía:**
- **Aceleraciones fuertes**: Pueden reducir la autonomía un 20-40%
- **Velocidades altas sostenidas**: A 150 km/h el consumo puede duplicarse
- **Modo Sport activado**: Respuesta más agresiva = mayor consumo

**Por qué ocurre:**
1. El par instantáneo del motor eléctrico invita a acelerar fuerte
2. Mayor resistencia aerodinámica a altas velocidades
3. La frenada regenerativa no compensa las aceleraciones bruscas

**Comparativa de consumo:**
| Estilo | Consumo medio | Autonomía ID.4 |
|---|---|---|
| Eco | 15 kWh/100km | 510 km |
| Normal | 18 kWh/100km | 425 km |
| Deportivo | 24 kWh/100km | 320 km |

**Ventajas de la conducción deportiva eléctrica:**
- Par instantáneo desde 0 rpm
- Aceleración lineal y predecible
- Sin cambios de marcha (respuesta inmediata)
- Silencio incluso a alta velocidad

**Consejo**: Disfruta de la conducción deportiva ocasionalmente. Para el día a día, el modo Eco o Normal maximiza la autonomía sin sacrificar el placer de conducir.`,
    videoId: 'dQw4w9WgXcQ',
    category: 'autonomia',
    categoryName: 'Autonomía',
    relatedQuestions: [
      { id: 'cuantos-kilometros-coche-electrico', categoria: 'autonomia', q: '¿Cuántos kilómetros puedo recorrer con un coche eléctrico?' },
      { id: 'frenada-regenerativa', categoria: 'autonomia', q: '¿Qué es la frenada regenerativa?' },
    ]
  },
  'frenada-regenerativa': {
    q: '¿Qué es la frenada regenerativa?',
    answer: `La frenada regenerativa es un sistema que recupera energía al frenar o desacelerar, recargando parcialmente la batería y aumentando la autonomía.

**¿Cómo funciona?**
Cuando levantas el pie del acelerador o frenas suavemente, el motor eléctrico actúa como generador, convirtiendo la energía cinética del vehículo en electricidad que se almacena en la batería.

**Beneficios:**
- **Mayor autonomía**: Recupera entre 10-30% de energía en ciudad
- **Menor desgaste de frenos**: Los frenos mecánicos se usan menos
- **Conducción con un pedal**: En muchos modelos puedes conducir casi sin tocar el freno

**Niveles de regeneración:**
La mayoría de coches eléctricos permiten ajustar la intensidad:
- **Nivel bajo (D)**: Sensación similar a un coche automático
- **Nivel alto (B)**: Frenada más intensa al soltar el acelerador
- **Adaptativo**: Se ajusta según el tráfico y la pendiente

**Modelos con conducción de un pedal:**
- Volkswagen ID.3/ID.4/ID.5 (opcional o de serie según versión)
- Audi Q4 e-tron (de serie)
- Škoda Enyaq (opcional)
- Nissan Leaf (e-Pedal)
- Tesla (todos los modelos)

**Consejo práctico**: En ciudad, usa el nivel alto de regeneración. En autopista, el nivel bajo es más cómodo y eficiente.`,
    videoId: 'dQw4w9WgXcQ',
    category: 'autonomia',
    categoryName: 'Autonomía',
    relatedQuestions: [
      { id: 'autonomia-conduccion-deportiva', categoria: 'autonomia', q: '¿Cómo afecta la conducción deportiva a la autonomía?' },
      { id: 'mantenimiento-coche-electrico', categoria: 'costes', q: '¿Qué mantenimiento necesita un coche eléctrico?' },
    ]
  },
  'autonomia-con-aire-acondicionado': {
    q: '¿Cuánto reduce el aire acondicionado la autonomía?',
    answer: `El uso del aire acondicionado tiene un impacto moderado en la autonomía, menor de lo que muchos creen.

**Impacto real:**
- **Aire acondicionado**: Reduce la autonomía un 5-15%
- **Calefacción**: Reduce la autonomía un 15-30%

**¿Por qué la calefacción consume más?**
El aire acondicionado usa un compresor eficiente, mientras que la calefacción tradicional usa resistencias eléctricas que consumen más energía.

**Solución: Bombas de calor**
Los modelos modernos incluyen bombas de calor que reducen el consumo de climatización hasta un 50%:
- VW ID.3/ID.4/ID.5 (opcional o de serie según versión)
- Audi Q4 e-tron (de serie)
- Škoda Enyaq (opcional)

**Consejos para minimizar el impacto:**
1. **Precondicionamiento**: Climatiza el coche mientras está enchufado
2. **Asientos calefactables**: Más eficientes que la calefacción general
3. **Volante calefactable**: Confort con mínimo consumo
4. **Recirculación de aire**: Mantiene la temperatura con menos energía

**Ejemplo práctico:**
Un VW ID.4 con 450 km de autonomía real:
- Sin climatización: 450 km
- Con A/C en verano: 400-420 km
- Con calefacción en invierno: 350-380 km
- Con bomba de calor en invierno: 400-420 km`,
    videoId: 'dQw4w9WgXcQ',
    category: 'autonomia',
    categoryName: 'Autonomía',
    relatedQuestions: [
      { id: 'autonomia-invierno', categoria: 'autonomia', q: '¿La autonomía disminuye en invierno?' },
      { id: 'cuantos-kilometros-coche-electrico', categoria: 'autonomia', q: '¿Cuántos kilómetros puedo recorrer con un coche eléctrico?' },
    ]
  },
  'tiempo-carga-coche-electrico': {
    q: '¿Cuánto tiempo tarda en cargar un coche eléctrico?',
    answer: `El tiempo de carga depende del tipo de cargador y la capacidad de la batería:

**Tipos de carga:**

**1. Carga doméstica (Wallbox 7-11 kW)**
- Tiempo: 6-8 horas para carga completa
- Ideal para: Cargar por la noche mientras duermes
- Coste instalación: 800-1.500€ (con ayudas MOVES puede ser gratuito)

**2. Carga en destino (11-22 kW)**
- Tiempo: 3-5 horas
- Ubicación: Centros comerciales, hoteles, parkings
- Ideal para: Mientras trabajas o haces compras

**3. Carga rápida DC (50 kW)**
- Tiempo: 30-60 minutos al 80%
- Ubicación: Estaciones de servicio, electrolineras
- Ideal para: Viajes largos

**4. Carga ultrarrápida (150-350 kW)**
- Tiempo: 15-30 minutos al 80%
- Ubicación: Corredores de autopista
- Ideal para: Paradas rápidas en viajes

**¿Por qué solo hasta el 80%?**
La carga se ralentiza a partir del 80% para proteger la batería. Del 80% al 100% puede tardar tanto como del 10% al 80%.

**Dato importante**: El 90% de las cargas se realizan en casa por la noche. La carga rápida es solo para viajes ocasionales.`,
    videoId: 'dQw4w9WgXcQ',
    category: 'carga',
    categoryName: 'Carga',
    relatedQuestions: [
      { id: 'punto-carga-garaje-comunitario', categoria: 'carga', q: '¿Puedo instalar un punto de carga en mi garaje comunitario?' },
      { id: 'tipos-conectores-carga', categoria: 'carga', q: '¿Qué tipos de conectores de carga existen?' },
      { id: 'cuanto-cuesta-cargar-coche-electrico', categoria: 'costes', q: '¿Cuánto cuesta cargar un coche eléctrico?' },
    ]
  },
  'punto-carga-garaje-comunitario': {
    q: '¿Puedo instalar un punto de carga en mi garaje comunitario?',
    answer: `Sí, la ley garantiza el derecho a instalar puntos de recarga en garajes comunitarios. El Real Decreto-ley 29/2021 simplificó enormemente el proceso.

**Proceso de instalación:**

**1. Notificación a la comunidad**
- Solo necesitas comunicarlo por escrito al presidente o administrador
- NO requiere aprobación de la junta de propietarios
- La comunidad tiene 2 meses para proponer alternativas

**2. Requisitos técnicos**
- Instalación realizada por electricista autorizado
- Boletín eléctrico de la instalación
- Contador individual para tu plaza

**3. Opciones de instalación**
- **Individual**: Punto de carga solo para tu plaza
- **Preinstalación comunitaria**: La comunidad instala la infraestructura base y cada vecino su punto

**Costes aproximados:**
- Wallbox + instalación: 1.000-2.000€
- Con ayuda Plan MOVES: Puede ser gratuito (hasta 70% subvencionado)

**Grupo Avisa te ayuda:**
- Estudio de viabilidad gratuito
- Gestión de permisos y comunicaciones
- Instalación homologada
- Tramitación de ayudas MOVES

Contacta con nosotros para un presupuesto sin compromiso.`,
    videoId: 'dQw4w9WgXcQ',
    category: 'carga',
    categoryName: 'Carga',
    relatedQuestions: [
      { id: 'tiempo-carga-coche-electrico', categoria: 'carga', q: '¿Cuánto tiempo tarda en cargar un coche eléctrico?' },
      { id: 'ayudas-comprar-coche-electrico', categoria: 'ayudas', q: '¿Qué ayudas existen para comprar un coche eléctrico?' },
    ]
  },
  'tipos-conectores-carga': {
    q: '¿Qué tipos de conectores de carga existen?',
    answer: `En Europa se utilizan principalmente dos tipos de conectores, dependiendo del tipo de carga:

**Carga en corriente alterna (AC) - Carga lenta/semi-rápida:**

**Tipo 2 (Mennekes)**
- Estándar europeo para carga AC
- Potencia: hasta 22 kW (trifásica) o 7,4 kW (monofásica)
- Uso: Wallbox domésticos, puntos de carga en destino
- Todos los coches eléctricos en Europa lo incluyen

**Carga en corriente continua (DC) - Carga rápida:**

**CCS Combo 2**
- Combina el Tipo 2 con pines adicionales para DC
- Potencia: 50-350 kW
- Uso: Electrolineras, estaciones de carga rápida
- Estándar en todos los VW, Audi, Škoda y la mayoría de marcas

**CHAdeMO**
- Estándar japonés, cada vez menos común en Europa
- Usado principalmente por Nissan Leaf y algunos Mitsubishi
- En desuso progresivo

**Tesla (NACS)**
- Conector propietario de Tesla
- En Europa, los Tesla usan CCS Combo 2

**Consejo práctico**: Si compras un Volkswagen, Audi o Škoda, solo necesitas preocuparte del Tipo 2 (para casa) y CCS (para viajes). Ambos vienen de serie.`,
    videoId: 'dQw4w9WgXcQ',
    category: 'carga',
    categoryName: 'Carga',
    relatedQuestions: [
      { id: 'tiempo-carga-coche-electrico', categoria: 'carga', q: '¿Cuánto tiempo tarda en cargar un coche eléctrico?' },
      { id: 'cargar-coche-electrico-lluvia', categoria: 'carga', q: '¿Es seguro cargar el coche eléctrico con lluvia?' },
    ]
  },
  'cargar-coche-electrico-lluvia': {
    q: '¿Es seguro cargar el coche eléctrico con lluvia?',
    answer: `Sí, es completamente seguro. Los conectores y sistemas de carga están diseñados con múltiples protecciones para garantizar la seguridad en cualquier condición meteorológica.

**Sistemas de seguridad:**

**1. Conectores sellados**
- Clasificación IP (Ingress Protection) alta
- Protección contra agua y polvo
- Contactos protegidos hasta que se establece la conexión

**2. Comunicación inteligente**
- El coche y el cargador "hablan" antes de iniciar la carga
- Solo fluye corriente cuando la conexión es segura
- Detección automática de fallos

**3. Protecciones eléctricas**
- Diferencial de alta sensibilidad
- Detección de fugas a tierra
- Corte automático ante cualquier anomalía

**4. Diseño del conector**
- Los pines de corriente están en el interior
- El agua no puede alcanzar las partes activas
- Materiales resistentes a la corrosión

**Dato curioso**: Los coches eléctricos son incluso más seguros que los de combustión en inundaciones, ya que no tienen toma de aire que pueda inundar el motor.

**Recomendación**: Aunque es seguro, evita manipular el conector con las manos mojadas por comodidad, no por seguridad.`,
    videoId: 'dQw4w9WgXcQ',
    category: 'carga',
    categoryName: 'Carga',
    relatedQuestions: [
      { id: 'tipos-conectores-carga', categoria: 'carga', q: '¿Qué tipos de conectores de carga existen?' },
      { id: 'punto-carga-garaje-comunitario', categoria: 'carga', q: '¿Puedo instalar un punto de carga en mi garaje comunitario?' },
    ]
  },
  'cargar-enchufe-normal': {
    q: '¿Puedo cargar mi coche eléctrico en un enchufe normal?',
    answer: `Técnicamente sí, pero no es recomendable como solución permanente.

**Carga en enchufe doméstico (Schuko):**
- **Potencia**: 2,3 kW (10A) máximo
- **Tiempo de carga**: 20-30 horas para carga completa
- **Uso recomendado**: Solo emergencias

**¿Por qué no es ideal?**
1. **Muy lento**: Una noche de 8 horas solo recupera 80-100 km
2. **Riesgo de sobrecalentamiento**: Los enchufes domésticos no están diseñados para uso intensivo prolongado
3. **Sin protecciones específicas**: Falta comunicación coche-cargador

**La solución: Wallbox**
Un cargador de pared (Wallbox) ofrece:
- **Potencia**: 7,4 kW (monofásico) o 11-22 kW (trifásico)
- **Tiempo de carga**: 4-8 horas para carga completa
- **Seguridad**: Protecciones específicas para vehículos eléctricos
- **Comodidad**: Programación de carga, control por app

**Coste de instalación:**
- Wallbox + instalación: 1.000-2.000€
- Con ayuda Plan MOVES: Hasta 70% subvencionado (puede ser gratuito)

**Consejo**: Si acabas de comprar un eléctrico, instala un Wallbox cuanto antes. La diferencia en comodidad y seguridad es enorme.`,
    videoId: 'dQw4w9WgXcQ',
    category: 'carga',
    categoryName: 'Carga',
    relatedQuestions: [
      { id: 'tiempo-carga-coche-electrico', categoria: 'carga', q: '¿Cuánto tiempo tarda en cargar un coche eléctrico?' },
      { id: 'punto-carga-garaje-comunitario', categoria: 'carga', q: '¿Puedo instalar un punto de carga en mi garaje comunitario?' },
    ]
  },
  'red-cargadores-espana': {
    q: '¿Hay suficientes cargadores públicos en España?',
    answer: `La red de carga pública en España ha crecido exponencialmente y sigue expandiéndose rápidamente.

**Situación actual:**
- **+20.000 puntos de carga públicos** en España
- **+3.000 cargadores rápidos** (50 kW o más)
- **+500 cargadores ultrarrápidos** (150 kW o más)

**Principales redes:**
| Red | Puntos | Tipo |
|---|---|---|
| Iberdrola | 3.500+ | Mixta |
| Endesa X | 2.000+ | Mixta |
| Repsol | 1.500+ | Rápida |
| Ionity | 100+ | Ultrarrápida |
| Tesla Supercharger | 80+ | Ultrarrápida |

**Cobertura en autopistas:**
- Cargadores rápidos cada 50-100 km en las principales rutas
- Corredores mediterráneo, cantábrico y central bien cubiertos
- Andalucía: Excelente cobertura en A-4, A-92, A-7

**Apps imprescindibles:**
- **Electromaps**: La más completa en España
- **A Better Route Planner**: Planificador de rutas
- **Plugshare**: Red global de cargadores

**Realidad práctica:**
El 90% de las cargas se hacen en casa. Los cargadores públicos son para:
- Viajes largos ocasionales
- Quienes no tienen garaje propio
- Recargas de oportunidad (centros comerciales, etc.)

**Futuro:**
España debe instalar 100.000 puntos de carga para 2030 según el PNIEC. La inversión está garantizada.`,
    videoId: 'dQw4w9WgXcQ',
    category: 'carga',
    categoryName: 'Carga',
    relatedQuestions: [
      { id: 'coche-electrico-viajes-largos', categoria: 'uso-diario', q: '¿Es práctico un coche eléctrico para viajes largos?' },
      { id: 'tiempo-carga-coche-electrico', categoria: 'carga', q: '¿Cuánto tiempo tarda en cargar un coche eléctrico?' },
    ]
  },
  'cargar-coche-electrico-noche': {
    q: '¿Es mejor cargar el coche eléctrico por la noche?',
    answer: `Sí, la carga nocturna es la opción más económica y también beneficia a la red eléctrica.

**Ventajas de la carga nocturna:**

**1. Ahorro económico**
- Tarifas con discriminación horaria: 50-70% más baratas en horario valle
- Horario valle: 00:00-08:00 (laborables) y todo el fin de semana
- Coste típico: 0,08-0,12€/kWh vs 0,20-0,30€/kWh en punta

**2. Mejor para la batería**
- Carga lenta = menos estrés térmico
- Temperatura ambiente más fresca
- Mayor durabilidad a largo plazo

**3. Beneficio para la red**
- Aprovecha excedentes de energía eólica (más viento por la noche)
- Reduce la demanda en horas punta
- Contribuye a la estabilidad del sistema

**Cómo programar la carga:**
- **Desde el coche**: Menú de configuración de carga
- **Desde la app**: VW WeConnect, myAudi, MyŠkoda
- **Desde el Wallbox**: Muchos permiten programación

**Ejemplo de ahorro:**
| Horario | Precio/kWh | Coste 100 km |
|---|---|---|
| Punta (18-22h) | 0,28€ | 5,04€ |
| Valle (00-08h) | 0,10€ | 1,80€ |
| **Ahorro** | - | **64%** |

**Consejo**: Contrata una tarifa con discriminación horaria (2.0TD) y programa el coche para cargar a partir de medianoche.`,
    videoId: 'dQw4w9WgXcQ',
    category: 'carga',
    categoryName: 'Carga',
    relatedQuestions: [
      { id: 'cuanto-cuesta-cargar-coche-electrico', categoria: 'costes', q: '¿Cuánto cuesta cargar un coche eléctrico?' },
      { id: 'tiempo-carga-coche-electrico', categoria: 'carga', q: '¿Cuánto tiempo tarda en cargar un coche eléctrico?' },
    ]
  },
  'cuanto-cuesta-cargar-coche-electrico': {
    q: '¿Cuánto cuesta cargar un coche eléctrico?',
    answer: `El coste de cargar un coche eléctrico es significativamente menor que repostar gasolina o diésel:

**Carga en casa (la más económica):**
- Tarifa normal: 2-3€ por cada 100 km
- Tarifa nocturna (valle): 1-1,5€ por cada 100 km
- Coste mensual típico (1.000 km): 20-30€

**Carga pública:**
- Carga lenta/semi-rápida: 3-5€ por cada 100 km
- Carga rápida (50 kW): 6-8€ por cada 100 km
- Carga ultrarrápida (150+ kW): 8-12€ por cada 100 km

**Comparativa con combustión:**
| | Eléctrico | Gasolina | Diésel |
|---|---|---|---|
| Coste/100 km | 2-3€ | 10-12€ | 8-10€ |
| Coste mensual (1.000 km) | 20-30€ | 100-120€ | 80-100€ |
| Ahorro anual | - | 800-1.000€ | 600-800€ |

**Consejos para ahorrar:**
1. Contrata una tarifa con discriminación horaria
2. Carga por la noche (22:00-08:00)
3. Aprovecha cargadores gratuitos en centros comerciales
4. Usa apps como Electromaps para encontrar los mejores precios

**Ejemplo real**: Un VW ID.4 con batería de 77 kWh cargado en casa con tarifa nocturna (0,10€/kWh) cuesta unos 7,70€ para 450 km de autonomía.`,
    videoId: 'dQw4w9WgXcQ',
    category: 'costes',
    categoryName: 'Costes',
    relatedQuestions: [
      { id: 'mantenimiento-coche-electrico', categoria: 'costes', q: '¿Qué mantenimiento necesita un coche eléctrico?' },
      { id: 'tiempo-carga-coche-electrico', categoria: 'carga', q: '¿Cuánto tiempo tarda en cargar un coche eléctrico?' },
    ]
  },
  'mantenimiento-coche-electrico': {
    q: '¿Qué mantenimiento necesita un coche eléctrico?',
    answer: `El mantenimiento de un coche eléctrico es mucho más sencillo y económico que el de un vehículo de combustión:

**Lo que NO necesita un eléctrico:**
- ❌ Cambios de aceite
- ❌ Filtro de combustible
- ❌ Bujías
- ❌ Correa de distribución
- ❌ Embrague
- ❌ Tubo de escape/catalizador

**Mantenimiento necesario:**

**Cada año o 30.000 km:**
- Revisión general de sistemas
- Comprobación de frenos
- Líquido limpiaparabrisas
- Filtro de habitáculo

**Cada 2 años o 60.000 km:**
- Líquido de frenos
- Revisión del sistema de refrigeración de batería

**Cada 4-5 años:**
- Líquido refrigerante de batería
- Neumáticos (duran menos por el mayor peso y par)

**Comparativa de costes anuales:**
| Concepto | Eléctrico | Combustión |
|---|---|---|
| Revisión anual | 100-150€ | 200-400€ |
| Frenos | Duran 2x más | Normal |
| Ahorro anual | 200-400€ | - |

**Curiosidad**: Los frenos de un eléctrico duran mucho más porque la frenada regenerativa hace la mayor parte del trabajo.`,
    videoId: 'dQw4w9WgXcQ',
    category: 'costes',
    categoryName: 'Costes',
    relatedQuestions: [
      { id: 'cuanto-cuesta-cargar-coche-electrico', categoria: 'costes', q: '¿Cuánto cuesta cargar un coche eléctrico?' },
      { id: 'revision-coche-electrico', categoria: 'mantenimiento', q: '¿Cada cuánto tiempo debo revisar mi coche eléctrico?' },
    ]
  },
  'seguro-coche-electrico': {
    q: '¿Es más caro el seguro de un coche eléctrico?',
    answer: `No necesariamente. Aunque el valor del vehículo puede ser mayor, hay factores que compensan:

**Factores que pueden encarecer:**
- Mayor valor del vehículo
- Coste de reparación de batería (en caso de accidente grave)
- Menor disponibilidad de talleres especializados

**Factores que pueden abaratar:**
- Perfil del conductor (suelen ser conductores más prudentes)
- Menor siniestralidad estadística
- Bonificaciones por vehículo ecológico
- Menor riesgo de incendio

**Comparativa real:**
Un seguro a todo riesgo para un VW ID.4 puede costar entre 500-800€/año, similar a un Tiguan de combustión equivalente.

**Consejos para ahorrar:**
1. Compara entre varias aseguradoras
2. Pregunta por descuentos para vehículos eléctricos
3. Considera franquicias más altas
4. Agrupa seguros (hogar + coche)

**Coberturas recomendadas:**
- Todo riesgo con franquicia
- Asistencia en carretera 24h
- Vehículo de sustitución
- Cobertura específica para batería

**En Grupo Avisa** colaboramos con aseguradoras que ofrecen condiciones especiales para vehículos eléctricos. Pregúntanos al adquirir tu vehículo.`,
    videoId: 'dQw4w9WgXcQ',
    category: 'costes',
    categoryName: 'Costes',
    relatedQuestions: [
      { id: 'mantenimiento-coche-electrico', categoria: 'costes', q: '¿Qué mantenimiento necesita un coche eléctrico?' },
      { id: 'garantia-bateria-electrico', categoria: 'mantenimiento', q: '¿Qué garantía tiene la batería de un vehículo eléctrico?' },
    ]
  },
  'precio-coche-electrico-vs-combustion': {
    q: '¿Por qué los coches eléctricos son más caros?',
    answer: `Los coches eléctricos tienen un precio de compra superior, pero el coste total de propiedad puede ser menor.

**¿Por qué son más caros inicialmente?**

**1. Batería**
- Representa el 30-40% del coste del vehículo
- Tecnología avanzada de iones de litio
- Precios bajando un 10-15% anual

**2. Tecnología**
- Motores eléctricos de alta eficiencia
- Electrónica de potencia sofisticada
- Sistemas de gestión térmica

**3. Economías de escala**
- Menor volumen de producción (por ahora)
- Cadenas de suministro en desarrollo

**Evolución de precios:**
| Año | Coste batería/kWh | Precio medio EV |
|---|---|---|
| 2015 | 350€ | 45.000€ |
| 2020 | 150€ | 38.000€ |
| 2024 | 100€ | 32.000€ |
| 2027 (est.) | 70€ | 28.000€ |

**Coste total de propiedad (5 años, 15.000 km/año):**
| Concepto | Eléctrico | Gasolina |
|---|---|---|
| Precio compra | 35.000€ | 28.000€ |
| Ayudas MOVES | -7.000€ | 0€ |
| Combustible/Carga | 2.250€ | 9.000€ |
| Mantenimiento | 750€ | 2.500€ |
| Impuestos | 500€ | 1.500€ |
| **TOTAL** | **31.500€** | **41.000€** |

**Conclusión**: Aunque el precio inicial es mayor, con las ayudas y el ahorro en uso, el eléctrico sale más económico a medio plazo.`,
    videoId: 'dQw4w9WgXcQ',
    category: 'costes',
    categoryName: 'Costes',
    relatedQuestions: [
      { id: 'ayudas-comprar-coche-electrico', categoria: 'ayudas', q: '¿Qué ayudas existen para comprar un coche eléctrico?' },
      { id: 'impuestos-coche-electrico', categoria: 'costes', q: '¿Qué impuestos paga un coche eléctrico?' },
    ]
  },
  'impuestos-coche-electrico': {
    q: '¿Qué impuestos paga un coche eléctrico?',
    answer: `Los coches eléctricos disfrutan de importantes ventajas fiscales en España.

**Impuesto de matriculación:**
- **Eléctricos**: EXENTOS (0%)
- Combustión: 4,75% - 14,75% según emisiones

**Impuesto de circulación (IVTM):**
- Bonificación de hasta el **75%** en la mayoría de municipios
- Ejemplo: Un VW ID.4 puede pagar 30-50€/año vs 150-200€ de un SUV diésel

**IVA:**
- Tipo general del 21% (igual que combustión)
- Se aplica sobre el precio ya reducido por ayudas

**Impuesto de sociedades (empresas):**
- Amortización acelerada para vehículos eléctricos
- Deducción del 100% del IVA si uso profesional

**Beneficios adicionales:**
- **Peajes**: Descuentos en algunas autopistas
- **Parking**: Gratuito o reducido en muchas ciudades
- **Zonas de bajas emisiones**: Acceso sin restricciones
- **Etiqueta CERO**: Ventajas en toda España

**Ejemplo de ahorro fiscal anual:**
| Concepto | Eléctrico | Diésel |
|---|---|---|
| Circulación | 40€ | 160€ |
| Parking zona azul | 0€ | 500€ |
| Peajes (estimado) | 200€ | 250€ |
| **Total anual** | **240€** | **910€** |

**Ahorro**: 670€/año solo en impuestos y tasas.`,
    videoId: 'dQw4w9WgXcQ',
    category: 'costes',
    categoryName: 'Costes',
    relatedQuestions: [
      { id: 'precio-coche-electrico-vs-combustion', categoria: 'costes', q: '¿Por qué los coches eléctricos son más caros?' },
      { id: 'ayudas-comprar-coche-electrico', categoria: 'ayudas', q: '¿Qué ayudas existen para comprar un coche eléctrico?' },
    ]
  },
  'valor-residual-coche-electrico': {
    q: '¿Cómo es el valor residual de un coche eléctrico?',
    answer: `El valor residual de los coches eléctricos ha mejorado significativamente y ya es comparable al de los vehículos de combustión.

**Factores que afectan al valor residual:**

**Positivos:**
- Alta demanda de eléctricos de segunda mano
- Baterías que mantienen buena capacidad
- Menor desgaste mecánico
- Prohibiciones futuras de combustión

**Negativos:**
- Evolución tecnológica rápida
- Nuevos modelos con más autonomía
- Bajada de precios de los nuevos

**Valor residual estimado (3 años, 45.000 km):**
| Modelo | Precio nuevo | Valor 3 años | % Retención |
|---|---|---|---|
| VW ID.4 | 45.000€ | 29.000€ | 64% |
| Audi Q4 e-tron | 52.000€ | 35.000€ | 67% |
| Tesla Model 3 | 42.000€ | 28.000€ | 67% |
| VW Golf (gasolina) | 32.000€ | 19.000€ | 59% |

**Tendencia:**
- Los eléctricos premium retienen mejor el valor
- Modelos con buena autonomía (400+ km) son más demandados
- La garantía de batería transferible aumenta el valor

**Consejos para maximizar el valor:**
1. Mantén el historial de cargas y mantenimiento
2. Cuida la batería (evita cargas al 100% constantes)
3. Realiza las revisiones oficiales
4. Conserva toda la documentación

**En Grupo Avisa** ofrecemos tasaciones justas para vehículos eléctricos usados y programas de recompra garantizada.`,
    videoId: 'dQw4w9WgXcQ',
    category: 'costes',
    categoryName: 'Costes',
    relatedQuestions: [
      { id: 'duracion-bateria-coche-electrico', categoria: 'mantenimiento', q: '¿Cuánto dura la batería de un coche eléctrico?' },
      { id: 'precio-coche-electrico-vs-combustion', categoria: 'costes', q: '¿Por qué los coches eléctricos son más caros?' },
    ]
  },
  'ayudas-comprar-coche-electrico': {
    q: '¿Qué ayudas existen para comprar un coche eléctrico?',
    answer: `Existen múltiples ayudas que pueden reducir significativamente el precio de tu vehículo eléctrico:

**Plan MOVES III (Nacional):**

| Tipo de vehículo | Sin achatarramiento | Con achatarramiento |
|---|---|---|
| Eléctrico (BEV) | 4.500€ | 7.000€ |
| Híbrido enchufable (PHEV) | 2.500€ | 5.000€ |
| Punto de recarga | Hasta 70% (máx. 1.500€) | - |

**Ayudas autonómicas (Andalucía):**
- Hasta 2.000€ adicionales según municipio
- Acumulables con Plan MOVES

**Beneficios fiscales:**
- **Impuesto de circulación**: Hasta 75% de bonificación
- **Impuesto de matriculación**: Exento (0%)
- **IVA**: Tipo general (21%), pero sobre precio ya reducido

**Otros beneficios:**
- Acceso a zonas de bajas emisiones
- Aparcamiento gratuito o reducido en muchas ciudades
- Peajes reducidos en algunas autopistas
- Carril VAO sin restricciones

**Ejemplo práctico:**
Un VW ID.4 de 45.000€ puede quedarse en:
- Precio base: 45.000€
- Plan MOVES (con achatarramiento): -7.000€
- Ayuda autonómica: -2.000€
- **Precio final: 36.000€**

Además, ahorrarás unos 1.500€/año en combustible y mantenimiento.`,
    videoId: 'dQw4w9WgXcQ',
    category: 'ayudas',
    categoryName: 'Ayudas y subvenciones',
    relatedQuestions: [
      { id: 'plan-moves-grupo-avisa', categoria: 'ayudas', q: '¿Grupo Avisa gestiona las ayudas del Plan MOVES?' },
      { id: 'combinar-ayudas-plan-moves', categoria: 'ayudas', q: '¿Puedo combinar el Plan MOVES con otras ayudas?' },
    ]
  },
  'plan-moves-grupo-avisa': {
    q: '¿Grupo Avisa gestiona las ayudas del Plan MOVES?',
    answer: `Sí, en Grupo Avisa nos encargamos de toda la tramitación del Plan MOVES sin ningún coste adicional para ti.

**Nuestro servicio incluye:**

**1. Asesoramiento personalizado**
- Análisis de tu situación particular
- Cálculo de la ayuda máxima a la que puedes optar
- Recomendación del mejor momento para comprar

**2. Gestión documental completa**
- Recopilación de toda la documentación necesaria
- Cumplimentación de formularios
- Presentación telemática de la solicitud
- Seguimiento del expediente

**3. Adelanto de la ayuda**
- No tienes que esperar 3-6 meses a que se apruebe
- Descontamos el importe de la ayuda directamente del precio
- Tú disfrutas del descuento desde el primer día

**4. Gestión del achatarramiento**
- Tramitamos la baja definitiva de tu vehículo antiguo
- Nos encargamos de la documentación
- Certificado de destrucción incluido

**Resultados:**
- +500 clientes beneficiados
- 3,2 millones € en ayudas gestionadas
- 100% de solicitudes aprobadas
- Valoración media: 4,9/5

**¿Por qué es gratuito?**
Porque queremos facilitar al máximo la transición a la movilidad eléctrica. Es parte de nuestro compromiso con la sostenibilidad.`,
    videoId: 'dQw4w9WgXcQ',
    category: 'ayudas',
    categoryName: 'Ayudas y subvenciones',
    relatedQuestions: [
      { id: 'ayudas-comprar-coche-electrico', categoria: 'ayudas', q: '¿Qué ayudas existen para comprar un coche eléctrico?' },
      { id: 'combinar-ayudas-plan-moves', categoria: 'ayudas', q: '¿Puedo combinar el Plan MOVES con otras ayudas?' },
    ]
  },
  'combinar-ayudas-plan-moves': {
    q: '¿Puedo combinar el Plan MOVES con otras ayudas?',
    answer: `Sí, puedes acumular diferentes ayudas para maximizar el descuento en tu vehículo eléctrico:

**Ayudas acumulables:**

**1. Plan MOVES III + Ayudas autonómicas**
- Totalmente compatibles
- En Andalucía: hasta 2.000€ adicionales
- En otras comunidades: varía según programa

**2. Plan MOVES III + Ayudas municipales**
- Algunos ayuntamientos ofrecen ayudas propias
- Consulta en tu localidad

**3. Plan MOVES III + Descuentos de marca**
- Las ofertas del fabricante son compatibles
- Financiación especial, descuentos por stock, etc.

**Ejemplo máximo en Andalucía:**
| Concepto | Importe |
|---|---|
| Plan MOVES III (con achatarramiento) | 7.000€ |
| Ayuda Junta de Andalucía | 1.500€ |
| Ayuda municipal (según ciudad) | 500€ |
| **Total ayudas** | **9.000€** |

**Limitaciones:**
- El total de ayudas no puede superar el 40% del precio del vehículo (particulares)
- Para empresas, el límite es del 35%
- Vehículos de más de 45.000€ (sin IVA) no son elegibles

**Importante**: En Grupo Avisa te informamos de todas las ayudas disponibles en tu zona y te ayudamos a solicitarlas todas.`,
    videoId: 'dQw4w9WgXcQ',
    category: 'ayudas',
    categoryName: 'Ayudas y subvenciones',
    relatedQuestions: [
      { id: 'ayudas-comprar-coche-electrico', categoria: 'ayudas', q: '¿Qué ayudas existen para comprar un coche eléctrico?' },
      { id: 'requisitos-plan-moves', categoria: 'ayudas', q: '¿Cuáles son los requisitos del Plan MOVES?' },
    ]
  },
  'requisitos-plan-moves': {
    q: '¿Cuáles son los requisitos del Plan MOVES?',
    answer: `Para acceder a las ayudas del Plan MOVES III debes cumplir los siguientes requisitos:

**Requisitos del beneficiario:**
- Ser persona física, autónomo, empresa o entidad
- Residir en España
- Estar al corriente de obligaciones tributarias y con la Seguridad Social
- No estar en situación de crisis empresarial (para empresas)

**Requisitos del vehículo:**
- Vehículo nuevo (no matriculado previamente)
- Precio máximo: 45.000€ (sin IVA) para turismos
- Para furgonetas: 53.000€ (sin IVA)

**Para vehículos eléctricos (BEV):**
- Autonomía mínima: 30 km (WLTP)
- Categorías: M1, N1, L (motos y cuadriciclos)

**Para híbridos enchufables (PHEV):**
- Autonomía eléctrica mínima: 40 km (WLTP)
- Emisiones máximas: 50 g CO2/km

**Para obtener la ayuda máxima (achatarramiento):**
- Dar de baja un vehículo de más de 7 años
- El vehículo debe estar a tu nombre desde hace al menos 12 meses
- Debe tener ITV en vigor o caducada hace menos de 2 años

**Documentación necesaria:**
1. DNI/NIE del solicitante
2. Certificado de empadronamiento
3. Factura del vehículo nuevo
4. Permiso de circulación del vehículo a achatarrar (si aplica)
5. Ficha técnica del vehículo a achatarrar (si aplica)

**Compromiso de mantenimiento:**
- Mantener el vehículo al menos 2 años (particulares)
- 3 años para empresas y autónomos`,
    videoId: 'dQw4w9WgXcQ',
    category: 'ayudas',
    categoryName: 'Ayudas y subvenciones',
    relatedQuestions: [
      { id: 'ayudas-comprar-coche-electrico', categoria: 'ayudas', q: '¿Qué ayudas existen para comprar un coche eléctrico?' },
      { id: 'plan-moves-grupo-avisa', categoria: 'ayudas', q: '¿Grupo Avisa gestiona las ayudas del Plan MOVES?' },
    ]
  },
  'ayudas-autonomos-empresas': {
    q: '¿Hay ayudas específicas para autónomos y empresas?',
    answer: `Sí, los autónomos y empresas pueden acceder a las mismas ayudas del Plan MOVES, con algunas particularidades.

**Plan MOVES III para empresas:**

| Tipo de vehículo | Sin achatarramiento | Con achatarramiento |
|---|---|---|
| Eléctrico (BEV) | 4.500€ | 7.000€ |
| Híbrido enchufable (PHEV) | 2.500€ | 5.000€ |
| Furgoneta eléctrica | 7.000€ | 9.000€ |

**Ventajas adicionales para empresas:**

**1. Fiscales**
- Deducción del 100% del IVA (si uso profesional)
- Amortización acelerada del vehículo
- Gasto deducible en IRPF/Sociedades

**2. Múltiples vehículos**
- Sin límite de vehículos por empresa
- Gestión centralizada de ayudas
- Descuentos por volumen en algunos fabricantes

**3. Puntos de carga**
- Hasta el **70%** del coste de instalación
- Deducible como inversión empresarial

**Requisitos específicos:**
- Estar al corriente con Hacienda y Seguridad Social
- No estar en situación de crisis empresarial
- Mantener el vehículo 3 años (vs 2 años particulares)
- Límite de ayudas: 35% del precio (vs 40% particulares)

**Ejemplo para autónomo:**
Furgoneta eléctrica de 40.000€:
- Ayuda MOVES (con achatarramiento): -9.000€
- Deducción IVA: -6.940€ (recuperable)
- **Coste real: 24.060€**

**En Grupo Avisa** asesoramos a empresas y autónomos sobre la mejor estrategia para pasarse al vehículo eléctrico.`,
    videoId: 'dQw4w9WgXcQ',
    category: 'ayudas',
    categoryName: 'Ayudas y subvenciones',
    relatedQuestions: [
      { id: 'ayudas-comprar-coche-electrico', categoria: 'ayudas', q: '¿Qué ayudas existen para comprar un coche eléctrico?' },
      { id: 'requisitos-plan-moves', categoria: 'ayudas', q: '¿Cuáles son los requisitos del Plan MOVES?' },
    ]
  },
  'ayudas-punto-recarga': {
    q: '¿Hay ayudas para instalar un punto de recarga?',
    answer: `Sí, el Plan MOVES III incluye ayudas específicas para la instalación de puntos de recarga.

**Ayudas disponibles:**

**Para particulares:**
- Hasta el **70%** del coste de instalación
- Máximo **1.300€** por punto de recarga
- Vinculado a la compra de vehículo eléctrico

**Para comunidades de propietarios:**
- Hasta el **70%** del coste
- Máximo **1.500€** por punto
- Incluye preinstalación comunitaria

**Para empresas:**
- Hasta el **70%** del coste
- Máximo **1.500€** por punto
- Sin límite de puntos por empresa

**¿Qué incluye la ayuda?**
- Wallbox o punto de recarga
- Instalación eléctrica completa
- Protecciones y cableado
- Contador individual (si aplica)
- Boletín eléctrico

**Costes típicos:**
| Concepto | Coste | Con ayuda 70% |
|---|---|---|
| Wallbox 7,4 kW | 600€ | 180€ |
| Instalación básica | 400€ | 120€ |
| Instalación compleja | 800€ | 240€ |
| **Total típico** | **1.000-1.400€** | **300-420€** |

**Proceso con Grupo Avisa:**
1. Estudio de viabilidad gratuito
2. Presupuesto cerrado
3. Instalación por técnicos certificados
4. Tramitación de la ayuda incluida

**Importante**: La ayuda para punto de recarga está vinculada a la compra del vehículo. Tramitamos ambas juntas.`,
    videoId: 'dQw4w9WgXcQ',
    category: 'ayudas',
    categoryName: 'Ayudas y subvenciones',
    relatedQuestions: [
      { id: 'cuanto-cuesta-cargar-coche-electrico', categoria: 'costes', q: '¿Cuánto cuesta cargar un coche eléctrico?' },
      { id: 'punto-carga-garaje-comunitario', categoria: 'carga', q: '¿Puedo instalar un punto de carga en mi garaje comunitario?' },
    ]
  },
  'cuando-acaban-ayudas-moves': {
    q: '¿Hasta cuándo están disponibles las ayudas MOVES?',
    answer: `El Plan MOVES III tiene fecha de finalización, pero se espera continuidad con nuevos programas.

**Situación actual:**

**Plan MOVES III:**
- Vigente hasta agotar fondos o nueva convocatoria
- Fondos adicionales aprobados en 2023
- Cada comunidad autónoma gestiona su presupuesto

**Estado por comunidades (orientativo):**
| Comunidad | Estado | Observaciones |
|---|---|---|
| Andalucía | Activo | Fondos disponibles |
| Madrid | Activo | Alta demanda |
| Cataluña | Activo | Fondos limitados |
| Valencia | Activo | Buena disponibilidad |

**¿Qué pasará después?**
- Se espera Plan MOVES IV o similar
- La UE exige incentivos hasta 2035
- España debe cumplir objetivos de electrificación

**Recomendación:**
No esperes demasiado. Las ayudas actuales son muy generosas y podrían reducirse en futuras convocatorias.

**Ventajas de actuar ahora:**
1. Ayudas máximas garantizadas
2. Mayor disponibilidad de vehículos
3. Precios competitivos
4. Tramitación más rápida

**En Grupo Avisa:**
- Te informamos del estado actual de las ayudas
- Reservamos tu vehículo mientras tramitamos
- Garantizamos la ayuda aunque cambien las condiciones

**Consejo**: Si estás pensando en comprar un eléctrico, este es el mejor momento. Contacta con nosotros para asegurar tu ayuda.`,
    videoId: 'dQw4w9WgXcQ',
    category: 'ayudas',
    categoryName: 'Ayudas y subvenciones',
    relatedQuestions: [
      { id: 'plan-moves-grupo-avisa', categoria: 'ayudas', q: '¿Grupo Avisa gestiona las ayudas del Plan MOVES?' },
      { id: 'requisitos-plan-moves', categoria: 'ayudas', q: '¿Cuáles son los requisitos del Plan MOVES?' },
    ]
  },
  'coche-electrico-viajes-largos': {
    q: '¿Es práctico un coche eléctrico para viajes largos?',
    answer: `Sí, los viajes largos con un coche eléctrico son perfectamente viables gracias a la extensa red de cargadores rápidos.

**Red de carga en España:**
- +15.000 puntos de carga públicos
- Cargadores rápidos cada 50-100 km en autopistas principales
- Redes como Ionity, Iberdrola, Repsol, Endesa X

**Planificación del viaje:**

**Ejemplo: Sevilla - Madrid (530 km)**
- Autonomía VW ID.4: ~450 km reales en autopista
- Parada recomendada: 1 carga de 20-25 min
- Tiempo total: similar a combustión (parada para café)

**Apps útiles:**
- **Electromaps**: Mapa de cargadores en España
- **A Better Route Planner**: Planificador de rutas
- **Plugshare**: Red global de cargadores

**Consejos para viajes largos:**
1. Planifica las paradas con antelación
2. Carga hasta el 80% (es más rápido)
3. Aprovecha las paradas para descansar
4. Precalienta la batería antes de llegar al cargador

**Ventajas vs combustión:**
- Más silencioso y relajado
- Menor fatiga del conductor
- Paradas más cortas pero más frecuentes (mejor para la salud)
- Coste del viaje: 50-70% menor

**Realidad**: La mayoría de conductores hacen 1-2 viajes largos al año. El 95% del tiempo, el coche se usa para trayectos cortos donde el eléctrico es imbatible.`,
    videoId: 'dQw4w9WgXcQ',
    category: 'uso-diario',
    categoryName: 'Uso diario',
    relatedQuestions: [
      { id: 'cuantos-kilometros-coche-electrico', categoria: 'autonomia', q: '¿Cuántos kilómetros puedo recorrer con un coche eléctrico?' },
      { id: 'tiempo-carga-coche-electrico', categoria: 'carga', q: '¿Cuánto tiempo tarda en cargar un coche eléctrico?' },
    ]
  },
  'remolcar-coche-electrico': {
    q: '¿Puedo remolcar con un coche eléctrico?',
    answer: `Sí, muchos modelos eléctricos pueden remolcar, y el par motor instantáneo los hace especialmente capaces para esta tarea.

**Capacidad de remolque por modelo:**

| Modelo | Capacidad máx. | Tipo |
|---|---|---|
| Tesla Model X | 2.250 kg | SUV |
| Audi e-tron | 1.800 kg | SUV |
| Mercedes EQC | 1.800 kg | SUV |
| VW ID.4 | 1.200 kg | SUV |
| Škoda Enyaq | 1.200 kg | SUV |
| VW ID.Buzz | 1.000 kg | Furgoneta |

**Ventajas del eléctrico para remolcar:**
- **Par instantáneo**: Arranque suave sin tirones
- **Control de tracción**: Mejor gestión en pendientes
- **Frenada regenerativa**: Ayuda a controlar el remolque en bajadas

**Consideraciones importantes:**
- La autonomía se reduce un 30-50% remolcando
- Planifica más paradas de carga
- Usa el modo de conducción adecuado
- Respeta los límites de peso

**Consejo práctico**: Si remolcas habitualmente (caravana, barco, remolque de caballos), elige un modelo con mayor capacidad de remolque y batería grande.

**En Grupo Avisa** te asesoramos sobre el modelo más adecuado para tus necesidades de remolque.`,
    videoId: 'dQw4w9WgXcQ',
    category: 'uso-diario',
    categoryName: 'Uso diario',
    relatedQuestions: [
      { id: 'coche-electrico-viajes-largos', categoria: 'uso-diario', q: '¿Es práctico un coche eléctrico para viajes largos?' },
      { id: 'ayudas-comprar-coche-electrico', categoria: 'ayudas', q: '¿Qué ayudas existen para comprar un coche eléctrico?' },
    ]
  },
  'coche-electrico-ciudad': {
    q: '¿Es el coche eléctrico ideal para ciudad?',
    answer: `Sí, el entorno urbano es donde el coche eléctrico muestra todas sus ventajas.

**¿Por qué es perfecto para ciudad?**

**1. Eficiencia máxima**
- En ciudad, el eléctrico consume menos que en autopista
- La frenada regenerativa recupera energía en cada semáforo
- Consumo típico: 12-15 kWh/100 km (vs 18-20 en autopista)

**2. Cero emisiones locales**
- No contamina donde más importa: zonas densamente pobladas
- Contribuye a mejorar la calidad del aire
- Sin ruido ni vibraciones

**3. Ventajas de circulación**
- Acceso libre a zonas de bajas emisiones (ZBE)
- Etiqueta CERO: sin restricciones por contaminación
- Carril VAO en muchas ciudades

**4. Ahorro en parking**
- Gratuito o bonificado en zona azul/verde
- Parkings con cargadores gratuitos
- Plazas reservadas en algunos centros comerciales

**5. Comodidad**
- Silencio total en atascos
- Climatización sin motor encendido
- Respuesta inmediata en arrancadas

**Modelos ideales para ciudad:**
| Modelo | Autonomía | Tamaño |
|---|---|---|
| VW ID.3 | 420-550 km | Compacto |
| SEAT Mó | 260 km | Urbano |
| Fiat 500e | 320 km | Urbano |
| Mini Electric | 230 km | Compacto |

**Dato**: El 80% de los desplazamientos urbanos son de menos de 30 km. Cualquier eléctrico actual cubre una semana de uso urbano con una sola carga.`,
    videoId: 'dQw4w9WgXcQ',
    category: 'uso-diario',
    categoryName: 'Uso diario',
    relatedQuestions: [
      { id: 'cuantos-kilometros-coche-electrico', categoria: 'autonomia', q: '¿Cuántos kilómetros puedo recorrer con un coche eléctrico?' },
      { id: 'impuestos-coche-electrico', categoria: 'costes', q: '¿Qué impuestos paga un coche eléctrico?' },
    ]
  },
  'coche-electrico-sin-garaje': {
    q: '¿Puedo tener un coche eléctrico sin garaje propio?',
    answer: `Sí, aunque tener garaje facilita las cosas, cada vez más personas usan coches eléctricos sin punto de carga en casa.

**Opciones de carga sin garaje:**

**1. Carga en el trabajo**
- Muchas empresas instalan cargadores para empleados
- 8 horas de carga = batería completa
- Pregunta en tu empresa por esta posibilidad

**2. Carga en destino**
- Centros comerciales (muchos gratuitos)
- Supermercados (Mercadona, Lidl, Carrefour...)
- Gimnasios, cines, restaurantes
- Hoteles y parkings públicos

**3. Carga pública en la calle**
- Red creciente de postes en vía pública
- Algunas ciudades ofrecen carga nocturna económica
- Apps como Electromaps muestran todos los puntos

**4. Carga rápida ocasional**
- Electrolineras en gasolineras
- 30 minutos = 80% de batería
- Ideal para recargas semanales

**Estrategia recomendada:**
1. Identifica cargadores cerca de tu casa/trabajo
2. Planifica cargas durante actividades habituales
3. Usa carga rápida 1-2 veces por semana si es necesario

**Coste estimado (sin garaje):**
- Carga pública semi-rápida: 40-60€/mes (1.000 km)
- Sigue siendo más barato que gasolina (100-120€/mes)

**Futuro:**
- Las ciudades están obligadas a instalar más puntos públicos
- Nuevas normativas exigen cargadores en parkings
- La situación mejora cada año

**Consejo**: Antes de comprar, mapea los cargadores de tu zona. En Grupo Avisa te ayudamos a evaluar tu situación.`,
    videoId: 'dQw4w9WgXcQ',
    category: 'uso-diario',
    categoryName: 'Uso diario',
    relatedQuestions: [
      { id: 'red-cargadores-espana', categoria: 'carga', q: '¿Hay suficientes cargadores públicos en España?' },
      { id: 'cuanto-cuesta-cargar-coche-electrico', categoria: 'costes', q: '¿Cuánto cuesta cargar un coche eléctrico?' },
    ]
  },
  'conducir-coche-electrico-diferencias': {
    q: '¿Es diferente conducir un coche eléctrico?',
    answer: `La conducción es muy similar, pero con algunas diferencias que la mayoría considera mejoras.

**Diferencias principales:**

**1. Aceleración**
- Par instantáneo desde 0 rpm
- Respuesta inmediata al pisar el acelerador
- Sensación de "empuje" constante y lineal

**2. Frenada regenerativa**
- Al soltar el acelerador, el coche frena suavemente
- Puedes conducir casi sin tocar el freno
- Se acostumbra en 1-2 días

**3. Silencio**
- Sin ruido de motor
- Solo se oye el rodamiento y el viento
- Conversaciones más fáciles, música mejor

**4. Cambio de marchas**
- No existe: transmisión directa
- Sin tirones ni interrupciones
- Conducción más relajada

**5. Centro de gravedad**
- Más bajo (batería en el suelo)
- Mejor estabilidad en curvas
- Sensación de seguridad

**Adaptación necesaria:**
| Aspecto | Tiempo de adaptación |
|---|---|
| Aceleración | Inmediato (¡y adictivo!) |
| Frenada regenerativa | 1-2 días |
| Gestión de autonomía | 1-2 semanas |
| Planificación de cargas | 1 mes |

**Lo que dicen los usuarios:**
- "No volvería a un coche de combustión"
- "Es como conducir el futuro"
- "Mucho más relajado y divertido"

**Consejo**: Prueba un eléctrico antes de decidir. En Grupo Avisa ofrecemos pruebas de conducción sin compromiso.`,
    videoId: 'dQw4w9WgXcQ',
    category: 'uso-diario',
    categoryName: 'Uso diario',
    relatedQuestions: [
      { id: 'frenada-regenerativa', categoria: 'autonomia', q: '¿Qué es la frenada regenerativa?' },
      { id: 'coche-electrico-ciudad', categoria: 'uso-diario', q: '¿Es el coche eléctrico ideal para ciudad?' },
    ]
  },
  'revision-coche-electrico': {
    q: '¿Cada cuánto tiempo debo revisar mi coche eléctrico?',
    answer: `Los vehículos eléctricos requieren menos mantenimiento, pero es importante seguir un calendario de revisiones:

**Calendario de mantenimiento recomendado:**

**Cada año o 30.000 km:**
- Inspección visual general
- Comprobación de frenos
- Revisión de neumáticos
- Filtro de habitáculo
- Líquido limpiaparabrisas
- Actualización de software

**Cada 2 años o 60.000 km:**
- Líquido de frenos
- Diagnóstico de batería de alto voltaje
- Revisión del sistema de refrigeración

**Cada 4 años o 120.000 km:**
- Líquido refrigerante de batería
- Revisión completa del sistema eléctrico

**Comparativa con combustión:**
| Intervención | Eléctrico | Combustión |
|---|---|---|
| Cambio aceite | No necesario | Cada 15.000 km |
| Filtro combustible | No existe | Cada 60.000 km |
| Bujías | No existen | Cada 60.000 km |
| Correa distribución | No existe | Cada 120.000 km |
| Embrague | No existe | Según desgaste |

**Coste medio anual:**
- Eléctrico: 100-150€
- Combustión: 300-500€

**En Grupo Avisa** disponemos de técnicos certificados y equipamiento oficial para el mantenimiento de vehículos eléctricos Volkswagen, Audi y Škoda.`,
    videoId: 'dQw4w9WgXcQ',
    category: 'mantenimiento',
    categoryName: 'Mantenimiento',
    relatedQuestions: [
      { id: 'mantenimiento-coche-electrico', categoria: 'costes', q: '¿Qué mantenimiento necesita un coche eléctrico?' },
      { id: 'duracion-bateria-coche-electrico', categoria: 'mantenimiento', q: '¿Cuánto dura la batería de un coche eléctrico?' },
    ]
  },
  'duracion-bateria-coche-electrico': {
    q: '¿Cuánto dura la batería de un coche eléctrico?',
    answer: `Las baterías modernas de los coches eléctricos están diseñadas para durar toda la vida útil del vehículo:

**Vida útil esperada:**
- **Años**: 15-20 años de uso normal
- **Kilómetros**: 300.000-500.000 km
- **Ciclos de carga**: 1.500-2.000 ciclos completos

**Degradación de la batería:**
La capacidad de la batería disminuye gradualmente con el tiempo:
- Tras 8 años: ~90% de capacidad original
- Tras 15 años: ~80% de capacidad original

**Ejemplo práctico:**
Un VW ID.4 con 520 km de autonomía nuevo, tras 10 años podría tener ~450 km. Sigue siendo más que suficiente para el uso diario.

**Factores que afectan la duración:**
1. **Temperatura**: Evitar exposición prolongada a calor extremo
2. **Carga rápida**: Usar con moderación (no afecta si es ocasional)
3. **Nivel de carga**: Mantener entre 20-80% para uso diario
4. **Carga completa**: Solo cuando sea necesario para viajes

**Buenas prácticas:**
- Carga nocturna lenta en casa (la mejor para la batería)
- No dejar el coche al sol con batería al 100%
- Usar precondicionamiento antes de cargar en frío

**Segunda vida:**
Cuando la batería ya no es óptima para el coche (~70% capacidad), puede usarse para almacenamiento estacionario de energía solar.`,
    videoId: 'dQw4w9WgXcQ',
    category: 'mantenimiento',
    categoryName: 'Mantenimiento',
    relatedQuestions: [
      { id: 'garantia-bateria-electrico', categoria: 'mantenimiento', q: '¿Qué garantía tiene la batería de un vehículo eléctrico?' },
      { id: 'revision-coche-electrico', categoria: 'mantenimiento', q: '¿Cada cuánto tiempo debo revisar mi coche eléctrico?' },
    ]
  },
  'garantia-bateria-electrico': {
    q: '¿Qué garantía tiene la batería de un vehículo eléctrico?',
    answer: `Los fabricantes ofrecen garantías extensas para las baterías de alto voltaje, demostrando su confianza en la tecnología:

**Garantías por marca:**

| Marca | Años | Kilómetros | Capacidad mín. |
|---|---|---|---|
| Volkswagen | 8 años | 160.000 km | 70% |
| Audi | 8 años | 160.000 km | 70% |
| Škoda | 8 años | 160.000 km | 70% |
| Tesla | 8 años | 192.000 km | 70% |
| Hyundai/Kia | 8 años | 160.000 km | 70% |

**¿Qué cubre la garantía?**
- Defectos de fabricación
- Degradación excesiva (por debajo del % garantizado)
- Fallos del sistema de gestión de batería (BMS)
- Problemas de celdas individuales

**¿Qué NO cubre?**
- Daños por accidente
- Uso indebido (modificaciones no autorizadas)
- Degradación normal dentro de los parámetros

**Importante:**
La garantía de la batería es independiente de la garantía general del vehículo (normalmente 2-3 años).

**Tranquilidad adicional:**
- Los datos reales muestran que la mayoría de baterías superan ampliamente los mínimos garantizados
- Casos de sustitución de batería por degradación son extremadamente raros

**En Grupo Avisa** realizamos diagnósticos de batería certificados que te informan del estado de salud (SOH) de tu batería en cualquier momento.`,
    videoId: 'dQw4w9WgXcQ',
    category: 'mantenimiento',
    categoryName: 'Mantenimiento',
    relatedQuestions: [
      { id: 'duracion-bateria-coche-electrico', categoria: 'mantenimiento', q: '¿Cuánto dura la batería de un coche eléctrico?' },
      { id: 'seguro-coche-electrico', categoria: 'costes', q: '¿Es más caro el seguro de un coche eléctrico?' },
    ]
  },
  'neumaticos-coche-electrico': {
    q: '¿Los coches eléctricos necesitan neumáticos especiales?',
    answer: `No es obligatorio, pero existen neumáticos optimizados para vehículos eléctricos que ofrecen ventajas significativas.

**¿Por qué neumáticos específicos?**

**1. Mayor peso del vehículo**
- Las baterías añaden 300-500 kg
- Neumáticos reforzados soportan mejor la carga
- Menor desgaste y mayor durabilidad

**2. Par instantáneo**
- La aceleración brusca desgasta más los neumáticos
- Compuestos especiales resisten mejor el par
- Mejor tracción en arrancadas

**3. Eficiencia energética**
- Menor resistencia a la rodadura
- Pueden aumentar la autonomía un 5-10%
- Compuestos de baja fricción

**4. Reducción de ruido**
- Sin motor, el ruido de rodadura se nota más
- Neumáticos EV tienen espuma insonorizante
- Experiencia de conducción más silenciosa

**Marcas con gamas EV:**
| Marca | Modelo EV | Características |
|---|---|---|
| Michelin | e.Primacy | Máxima eficiencia |
| Continental | EcoContact 6 | Equilibrado |
| Bridgestone | Turanza Eco | Bajo ruido |
| Goodyear | ElectricDrive | Alta durabilidad |

**¿Puedo usar neumáticos normales?**
Sí, pero:
- Se desgastarán más rápido
- Pueden reducir ligeramente la autonomía
- Más ruido de rodadura

**Consejo**: Al cambiar neumáticos, considera los específicos para EV. La inversión se recupera en durabilidad y autonomía.`,
    videoId: 'dQw4w9WgXcQ',
    category: 'mantenimiento',
    categoryName: 'Mantenimiento',
    relatedQuestions: [
      { id: 'revision-coche-electrico', categoria: 'mantenimiento', q: '¿Cada cuánto tiempo debo revisar mi coche eléctrico?' },
      { id: 'mantenimiento-coche-electrico', categoria: 'costes', q: '¿Qué mantenimiento necesita un coche eléctrico?' },
    ]
  },
  'frenos-coche-electrico': {
    q: '¿Cuánto duran los frenos de un coche eléctrico?',
    answer: `Los frenos de un coche eléctrico duran significativamente más que los de un vehículo de combustión, gracias a la frenada regenerativa.

**¿Por qué duran más?**

La frenada regenerativa hace el 70-90% del trabajo de frenado en conducción normal:
- Al soltar el acelerador, el motor actúa como generador
- Esto frena el coche y recarga la batería
- Los frenos mecánicos solo se usan para frenadas fuertes

**Duración estimada:**
| Componente | Eléctrico | Combustión |
|---|---|---|
| Pastillas delanteras | 100.000+ km | 40.000-60.000 km |
| Pastillas traseras | 150.000+ km | 60.000-80.000 km |
| Discos | 150.000+ km | 80.000-100.000 km |

**Ahorro aproximado:**
- Cambio de pastillas: 150-250€ (cada 100.000 km vs 50.000 km)
- Ahorro en 200.000 km: 300-500€

**Consideración importante:**
Por el poco uso, los frenos pueden oxidarse superficialmente. Recomendaciones:
- Usar los frenos mecánicos ocasionalmente
- Revisión visual en cada mantenimiento
- En zonas húmedas, frenar suavemente al inicio de cada viaje

**Modos de conducción:**
- **Modo D (bajo regenerativo)**: Más uso de frenos mecánicos
- **Modo B (alto regenerativo)**: Mínimo uso de frenos mecánicos

**Consejo**: Usa el modo B en ciudad para maximizar la regeneración y la vida de los frenos.`,
    videoId: 'dQw4w9WgXcQ',
    category: 'mantenimiento',
    categoryName: 'Mantenimiento',
    relatedQuestions: [
      { id: 'frenada-regenerativa', categoria: 'autonomia', q: '¿Qué es la frenada regenerativa?' },
      { id: 'revision-coche-electrico', categoria: 'mantenimiento', q: '¿Cada cuánto tiempo debo revisar mi coche eléctrico?' },
    ]
  },
  'actualizaciones-software-coche-electrico': {
    q: '¿Los coches eléctricos reciben actualizaciones de software?',
    answer: `Sí, los coches eléctricos modernos reciben actualizaciones de software que pueden mejorar el vehículo con el tiempo.

**Tipos de actualizaciones:**

**1. Over-the-Air (OTA)**
- Se descargan automáticamente vía WiFi/datos
- Se instalan mientras el coche está aparcado
- No requieren visita al taller

**2. En taller**
- Actualizaciones más complejas
- Requieren equipamiento de diagnóstico
- Incluidas en revisiones periódicas

**¿Qué pueden mejorar?**

**Rendimiento:**
- Optimización de la gestión de batería
- Mejora de la autonomía
- Ajustes en la frenada regenerativa

**Funcionalidades:**
- Nuevas características del sistema de infoentretenimiento
- Mejoras en la navegación
- Nuevos modos de conducción

**Seguridad:**
- Actualizaciones de sistemas ADAS
- Corrección de vulnerabilidades
- Mejoras en asistentes de conducción

**Ejemplos reales:**
| Marca | Mejora | Resultado |
|---|---|---|
| Tesla | Optimización batería | +5% autonomía |
| VW ID. | Nuevo planificador rutas | Mejor experiencia |
| Audi | Carga más rápida | -10 min en carga DC |

**Modelos con OTA:**
- Volkswagen ID.3/ID.4/ID.5
- Audi Q4 e-tron
- Škoda Enyaq
- Tesla (todos)
- BMW iX/i4

**Ventaja**: Tu coche puede mejorar después de comprarlo, algo imposible en vehículos tradicionales.`,
    videoId: 'dQw4w9WgXcQ',
    category: 'mantenimiento',
    categoryName: 'Mantenimiento',
    relatedQuestions: [
      { id: 'garantia-bateria-electrico', categoria: 'mantenimiento', q: '¿Qué garantía tiene la batería de un vehículo eléctrico?' },
      { id: 'revision-coche-electrico', categoria: 'mantenimiento', q: '¿Cada cuánto tiempo debo revisar mi coche eléctrico?' },
    ]
  },
};

export default function QuestionDetailPage({ categoria, pregunta }: { categoria: string; pregunta: string }) {
  const [copied, setCopied] = useState(false);
  const questionData = allQuestions[pregunta];

  if (!questionData) {
    return (
      <main className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Pregunta no encontrada</h1>
          <Link href="/preguntas" className="text-[#ad023b] hover:underline cursor-pointer">
            Volver a preguntas frecuentes
          </Link>
        </div>
      </main>
    );
  }

  const handleCopyLink = () => {
    navigator.clipboard.writeText(`https://uuqagc.readdy.co/preguntas/${categoria}/${pregunta}`);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <main className="min-h-screen bg-gray-50">
      <section className="bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 pt-32 pb-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex items-center gap-2 text-sm text-gray-400 mb-6 flex-wrap">
            <Link href="/" className="hover:text-white transition-colors cursor-pointer">Inicio</Link>
            <i className="ri-arrow-right-s-line"></i>
            <Link href="/preguntas" className="hover:text-white transition-colors cursor-pointer">Preguntas frecuentes</Link>
            <i className="ri-arrow-right-s-line"></i>
            <Link href={`/preguntas/${categoria}`} className="hover:text-white transition-colors cursor-pointer">{questionData.categoryName}</Link>
            <i className="ri-arrow-right-s-line"></i>
            <span className="text-white truncate max-w-[200px]">Pregunta</span>
          </nav>
          
          <h1 className="text-2xl md:text-3xl font-bold text-white leading-tight">
            {questionData.q}
          </h1>
          
          <div className="flex items-center gap-4 mt-6">
            <button
              onClick={handleCopyLink}
              className="flex items-center gap-2 bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-full text-sm transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className={copied ? 'ri-check-line' : 'ri-link'}></i>
              {copied ? 'Enlace copiado' : 'Copiar enlace'}
            </button>
            <a
              href={`https://wa.me/34955034600?text=Tengo una duda sobre: ${questionData.q}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 bg-[#25D366] hover:bg-[#20BD5A] text-white px-4 py-2 rounded-full text-sm transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-whatsapp-line"></i>
              Escríbeme
            </a>
          </div>
        </div>
      </section>

      <section className="py-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-2xl shadow-lg overflow-hidden mb-8">
            <div className="aspect-video bg-gray-900 relative">
              <iframe
                src={`https://www.youtube.com/embed/${questionData.videoId}`}
                title={questionData.q}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="absolute inset-0 w-full h-full"
              ></iframe>
            </div>
          </div>

          <div className="bg-white rounded-2xl shadow-lg p-8 mb-8">
            <div className="prose prose-lg max-w-none">
              {questionData.answer.split('\n\n').map((paragraph, index) => {
                if (paragraph.startsWith('**') && paragraph.endsWith('**')) {
                  return (
                    <h3 key={index} className="text-xl font-bold text-gray-900 mt-6 mb-3">
                      {paragraph.replace(/\*\*/g, '')}
                    </h3>
                  );
                }
                if (paragraph.startsWith('|')) {
                  const rows = paragraph.split('\n').filter(row => row.trim());
                  const headers = rows[0].split('|').filter(cell => cell.trim());
                  const dataRows = rows.slice(2);
                  
                  return (
                    <div key={index} className="overflow-x-auto my-6">
                      <table className="min-w-full border border-gray-200 rounded-lg overflow-hidden">
                        <thead className="bg-gray-50">
                          <tr>
                            {headers.map((header, i) => (
                              <th key={i} className="px-4 py-3 text-left text-sm font-semibold text-gray-900 border-b">
                                {header.trim()}
                              </th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {dataRows.map((row, rowIndex) => {
                            const cells = row.split('|').filter(cell => cell.trim());
                            return (
                              <tr key={rowIndex} className={rowIndex % 2 === 0 ? 'bg-white' : 'bg-gray-50'}>
                                {cells.map((cell, cellIndex) => (
                                  <td key={cellIndex} className="px-4 py-3 text-sm text-gray-700 border-b">
                                    {cell.trim()}
                                  </td>
                                ))}
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  );
                }
                if (paragraph.startsWith('- ')) {
                  const items = paragraph.split('\n').filter(item => item.trim());
                  return (
                    <ul key={index} className="space-y-2 my-4">
                      {items.map((item, i) => (
                        <li key={i} className="flex items-start gap-2 text-gray-700">
                          <i className="ri-checkbox-circle-fill text-green-500 mt-1 flex-shrink-0"></i>
                          <span dangerouslySetInnerHTML={{ __html: item.replace(/^- /, '').replace(/\*\*/g, '') }} />
                        </li>
                      ))}
                    </ul>
                  );
                }
                if (paragraph.match(/^\d+\.\s/)) {
                  const items = paragraph.split('\n').filter(item => item.trim());
                  return (
                    <ol key={index} className="list-decimal list-inside space-y-2 my-4">
                      {items.map((item, i) => (
                        <li key={i} className="text-gray-700">
                          {item.replace(/^\d+\.\s/, '').replace(/\*\*/g, '')}
                        </li>
                      ))}
                    </ol>
                  );
                }
                return (
                  <p key={index} className="text-gray-700 leading-relaxed my-4" dangerouslySetInnerHTML={{ __html: paragraph.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') }} />
                );
              })}
            </div>
          </div>

          {questionData.relatedQuestions.length > 0 && (
            <div className="bg-white rounded-2xl shadow-lg p-8">
              <h3 className="text-xl font-bold text-gray-900 mb-6">Preguntas relacionadas</h3>
              <div className="space-y-3">
                {questionData.relatedQuestions.map((related) => (
                  <Link
                    key={related.id}
                    href={`/preguntas/${related.categoria}/${related.id}`}
                    className="flex items-center gap-3 p-4 bg-gray-50 hover:bg-gray-100 rounded-xl transition-colors cursor-pointer group"
                  >
                    <div className="w-10 h-10 flex items-center justify-center bg-[#ad023b]/10 rounded-full flex-shrink-0">
                      <i className="ri-question-line text-[#ad023b]"></i>
                    </div>
                    <span className="text-gray-900 group-hover:text-[#ad023b] transition-colors flex-1">
                      {related.q}
                    </span>
                    <i className="ri-arrow-right-line text-gray-400 group-hover:text-[#ad023b] group-hover:translate-x-1 transition-all"></i>
                  </Link>
                ))}
              </div>
            </div>
          )}

          <div className="mt-8 flex justify-center">
            <Link
              href={`/preguntas/${categoria}`}
              className="inline-flex items-center gap-2 text-[#ad023b] font-medium hover:underline cursor-pointer"
            >
              <i className="ri-arrow-left-line"></i>
              Volver a {questionData.categoryName}
            </Link>
          </div>
        </div>
      </section>
    </main>
  );
}
