
import CategoryFAQPage from './CategoryFAQPage';

export async function generateStaticParams() {
  return [
    { categoria: 'autonomia' },
    { categoria: 'carga' },
    { categoria: 'costes' },
    { categoria: 'ayudas' },
    { categoria: 'uso-diario' },
    { categoria: 'mantenimiento' },
  ];
}

export default function Page({ params }: { params: { categoria: string } }) {
  return <CategoryFAQPage categoria={params.categoria} />;
}
