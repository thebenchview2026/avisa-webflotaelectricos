'use client';

import Link from 'next/link';

const faqData: Record<string, { name: string; icon: string; questions: { id: string; q: string; preview: string }[] }> = {
  'autonomia': {
    name: 'Autonomía',
    icon: 'ri-battery-2-charge-line',
    questions: [
      { id: 'cuantos-kilometros-coche-electrico', q: '¿Cuántos kilómetros puedo recorrer con un coche eléctrico?', preview: 'Los vehículos eléctricos actuales ofrecen entre 300 y 600 km de autonomía real...' },
      { id: 'autonomia-invierno', q: '¿La autonomía disminuye en invierno?', preview: 'Sí, en condiciones de frío extremo la autonomía puede reducirse entre un 10-30%...' },
      { id: 'autonomia-real-vs-homologada', q: '¿Qué diferencia hay entre autonomía real y homologada?', preview: 'La autonomía homologada se mide en condiciones de laboratorio según el ciclo WLTP...' },
    ]
  },
  'carga': {
    name: 'Carga',
    icon: 'ri-charging-pile-2-line',
    questions: [
      { id: 'tiempo-carga-coche-electrico', q: '¿Cuánto tiempo tarda en cargar un coche eléctrico?', preview: 'Depende del tipo de carga: en casa con wallbox tarda 6-8 horas...' },
      { id: 'punto-carga-garaje-comunitario', q: '¿Puedo instalar un punto de carga en mi garaje comunitario?', preview: 'Sí, la ley garantiza el derecho a instalar puntos de recarga...' },
      { id: 'tipos-conectores-carga', q: '¿Qué tipos de conectores de carga existen?', preview: 'Los principales conectores son Tipo 2 (Mennekes) para carga lenta y CCS Combo...' },
      { id: 'cargar-coche-electrico-lluvia', q: '¿Es seguro cargar el coche eléctrico con lluvia?', preview: 'Sí, es completamente seguro. Los conectores y sistemas de carga están diseñados...' },
    ]
  },
  'costes': {
    name: 'Costes',
    icon: 'ri-money-euro-circle-line',
    questions: [
      { id: 'cuanto-cuesta-cargar-coche-electrico', q: '¿Cuánto cuesta cargar un coche eléctrico?', preview: 'Cargar en casa cuesta aproximadamente 2-3€ por cada 100 km...' },
      { id: 'mantenimiento-coche-electrico', q: '¿Qué mantenimiento necesita un coche eléctrico?', preview: 'El mantenimiento es mucho más económico: no hay cambios de aceite...' },
      { id: 'seguro-coche-electrico', q: '¿Es más caro el seguro de un coche eléctrico?', preview: 'No necesariamente. Aunque el valor del vehículo puede ser mayor...' },
    ]
  },
  'ayudas': {
    name: 'Ayudas y subvenciones',
    icon: 'ri-hand-coin-line',
    questions: [
      { id: 'ayudas-comprar-coche-electrico', q: '¿Qué ayudas existen para comprar un coche eléctrico?', preview: 'El Plan MOVES III ofrece hasta 7.000€ para vehículos eléctricos...' },
      { id: 'plan-moves-grupo-avisa', q: '¿Grupo Avisa gestiona las ayudas del Plan MOVES?', preview: 'Sí, nos encargamos de toda la tramitación sin coste adicional...' },
      { id: 'combinar-ayudas-plan-moves', q: '¿Puedo combinar el Plan MOVES con otras ayudas?', preview: 'Sí, puedes acumular la ayuda del Plan MOVES con subvenciones autonómicas...' },
      { id: 'requisitos-plan-moves', q: '¿Cuáles son los requisitos del Plan MOVES?', preview: 'Los principales requisitos son: ser persona física o jurídica, adquirir un vehículo nuevo...' },
    ]
  },
  'uso-diario': {
    name: 'Uso diario',
    icon: 'ri-steering-2-line',
    questions: [
      { id: 'coche-electrico-viajes-largos', q: '¿Es práctico un coche eléctrico para viajes largos?', preview: 'Sí, la red de cargadores rápidos en autopistas está muy desarrollada...' },
      { id: 'remolcar-coche-electrico', q: '¿Puedo remolcar con un coche eléctrico?', preview: 'Muchos modelos eléctricos pueden remolcar. Por ejemplo, el Tesla Model X...' },
      { id: 'coche-electrico-familia', q: '¿Es un coche eléctrico adecuado para una familia?', preview: 'Absolutamente. Existen numerosos modelos familiares con amplio espacio...' },
    ]
  },
  'mantenimiento': {
    name: 'Mantenimiento',
    icon: 'ri-tools-line',
    questions: [
      { id: 'revision-coche-electrico', q: '¿Cada cuánto tiempo debo revisar mi coche eléctrico?', preview: 'Los vehículos eléctricos requieren menos mantenimiento. Recomendamos una revisión anual...' },
      { id: 'duracion-bateria-coche-electrico', q: '¿Cuánto dura la batería de un coche eléctrico?', preview: 'Las baterías modernas están diseñadas para durar entre 15-20 años o más de 500.000 km...' },
      { id: 'garantia-bateria-electrico', q: '¿Qué garantía tiene la batería de un vehículo eléctrico?', preview: 'La mayoría de fabricantes ofrecen 8 años o 160.000 km de garantía...' },
    ]
  },
};

export default function CategoryFAQPage({ categoria }: { categoria: string }) {
  const categoryData = faqData[categoria] || faqData['autonomia'];

  return (
    <main className="min-h-screen bg-gray-50">
      <section className="bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 pt-32 pb-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex items-center gap-2 text-sm text-gray-400 mb-6">
            <Link href="/" className="hover:text-white transition-colors cursor-pointer">Inicio</Link>
            <i className="ri-arrow-right-s-line"></i>
            <Link href="/preguntas" className="hover:text-white transition-colors cursor-pointer">Preguntas frecuentes</Link>
            <i className="ri-arrow-right-s-line"></i>
            <span className="text-white">{categoryData.name}</span>
          </nav>
          
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 flex items-center justify-center bg-[#ad023b]/20 rounded-2xl">
              <i className={`${categoryData.icon} text-3xl text-[#ad023b]`}></i>
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-white">
                {categoryData.name}
              </h1>
              <p className="text-gray-400 mt-1">{categoryData.questions.length} preguntas en esta categoría</p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="space-y-4">
            {categoryData.questions.map((question, index) => (
              <Link
                key={question.id}
                href={`/preguntas/${categoria}/${question.id}`}
                className="block bg-white rounded-xl border border-gray-200 p-6 hover:border-[#ad023b]/30 hover:shadow-lg transition-all cursor-pointer group"
              >
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 flex items-center justify-center bg-gray-100 rounded-full flex-shrink-0 text-gray-500 font-bold">
                    {index + 1}
                  </div>
                  <div className="flex-1">
                    <h2 className="text-lg font-semibold text-gray-900 group-hover:text-[#ad023b] transition-colors mb-2">
                      {question.q}
                    </h2>
                    <p className="text-gray-600 text-sm line-clamp-2">{question.preview}</p>
                    <div className="flex items-center gap-4 mt-3">
                      <span className="text-sm text-[#ad023b] flex items-center gap-1">
                        <i className="ri-play-circle-line"></i>
                        Ver video
                      </span>
                      <span className="text-sm text-gray-500 flex items-center gap-1">
                        <i className="ri-arrow-right-line group-hover:translate-x-1 transition-transform"></i>
                        Leer más
                      </span>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>

          <div className="mt-12 flex justify-center">
            <Link
              href="/preguntas"
              className="inline-flex items-center gap-2 text-[#ad023b] font-medium hover:underline cursor-pointer"
            >
              <i className="ri-arrow-left-line"></i>
              Ver todas las categorías
            </Link>
          </div>
        </div>
      </section>
    </main>
  );
}
