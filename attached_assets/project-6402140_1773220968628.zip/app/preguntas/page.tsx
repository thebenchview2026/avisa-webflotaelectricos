
import dynamic from 'next/dynamic';
import FAQHero from './FAQHero';
import FAQCategories from './FAQCategories';

const FAQContact = dynamic(() => import('./FAQContact'), {
  loading: () => <div className="h-48 bg-gray-50 animate-pulse" />
});

export default function PreguntasPage() {
  return (
    <main>
      <FAQHero />
      <FAQCategories />
      <FAQContact />
    </main>
  );
}
