
'use client';

import { useState } from 'react';
import Link from 'next/link';

const faqData = [
  {
    id: 'autonomia',
    name: 'Autonomía',
    icon: 'ri-battery-2-charge-line',
    questions: [
      { id: 'cuantos-kilometros-coche-electrico', q: '¿Cuántos kilómetros puedo recorrer con un coche eléctrico?' },
      { id: 'autonomia-invierno', q: '¿La autonomía disminuye en invierno?' },
      { id: 'autonomia-real-vs-homologada', q: '¿Qué diferencia hay entre autonomía real y homologada?' },
    ]
  },
  {
    id: 'carga',
    name: 'Carga',
    icon: 'ri-charging-pile-2-line',
    questions: [
      { id: 'tiempo-carga-coche-electrico', q: '¿Cuánto tiempo tarda en cargar un coche eléctrico?' },
      { id: 'punto-carga-garaje-comunitario', q: '¿Puedo instalar un punto de carga en mi garaje comunitario?' },
      { id: 'tipos-conectores-carga', q: '¿Qué tipos de conectores de carga existen?' },
      { id: 'cargar-coche-electrico-lluvia', q: '¿Es seguro cargar el coche eléctrico con lluvia?' },
    ]
  },
  {
    id: 'costes',
    name: 'Costes',
    icon: 'ri-money-euro-circle-line',
    questions: [
      { id: 'cuanto-cuesta-cargar-coche-electrico', q: '¿Cuánto cuesta cargar un coche eléctrico?' },
      { id: 'mantenimiento-coche-electrico', q: '¿Qué mantenimiento necesita un coche eléctrico?' },
      { id: 'seguro-coche-electrico', q: '¿Es más caro el seguro de un coche eléctrico?' },
    ]
  },
  {
    id: 'ayudas',
    name: 'Ayudas y subvenciones',
    icon: 'ri-hand-coin-line',
    questions: [
      { id: 'ayudas-comprar-coche-electrico', q: '¿Qué ayudas existen para comprar un coche eléctrico?' },
      { id: 'plan-moves-grupo-avisa', q: '¿Grupo Avisa gestiona las ayudas del Plan MOVES?' },
      { id: 'combinar-ayudas-plan-moves', q: '¿Puedo combinar el Plan MOVES con otras ayudas?' },
      { id: 'requisitos-plan-moves', q: '¿Cuáles son los requisitos del Plan MOVES?' },
    ]
  },
  {
    id: 'uso-diario',
    name: 'Uso diario',
    icon: 'ri-steering-2-line',
    questions: [
      { id: 'coche-electrico-viajes-largos', q: '¿Es práctico un coche eléctrico para viajes largos?' },
      { id: 'remolcar-coche-electrico', q: '¿Puedo remolcar con un coche eléctrico?' },
      { id: 'coche-electrico-familia', q: '¿Es un coche eléctrico adecuado para una familia?' },
    ]
  },
  {
    id: 'mantenimiento',
    name: 'Mantenimiento',
    icon: 'ri-tools-line',
    questions: [
      { id: 'revision-coche-electrico', q: '¿Cada cuánto tiempo debo revisar mi coche eléctrico?' },
      { id: 'duracion-bateria-coche-electrico', q: '¿Cuánto dura la batería de un coche eléctrico?' },
      { id: 'garantia-bateria-electrico', q: '¿Qué garantía tiene la batería de un vehículo eléctrico?' },
    ]
  },
];

export default function FAQCategories() {
  const [activeCategory, setActiveCategory] = useState('autonomia');

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Explora por categoría
          </h2>
          <p className="text-lg text-gray-600">
            Selecciona una categoría para ver todas las preguntas relacionadas
          </p>
        </div>

        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {faqData.map((category) => (
            <button
              key={category.id}
              onClick={() => setActiveCategory(category.id)}
              className={`flex items-center gap-2 px-5 py-3 rounded-full font-medium transition-all cursor-pointer whitespace-nowrap ${
                activeCategory === category.id
                  ? 'bg-[#ad023b] text-white shadow-lg shadow-[#ad023b]/30'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              <i className={`${category.icon} text-lg`}></i>
              {category.name}
            </button>
          ))}
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {faqData
            .filter((cat) => cat.id === activeCategory)
            .map((category) =>
              category.questions.map((question) => (
                <Link
                  key={question.id}
                  href={`/preguntas/${category.id}/${question.id}`}
                  className="group bg-gray-50 hover:bg-white border border-gray-200 hover:border-[#ad023b]/30 rounded-xl p-6 transition-all hover:shadow-lg cursor-pointer"
                >
                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 flex items-center justify-center bg-[#ad023b]/10 rounded-full flex-shrink-0 group-hover:bg-[#ad023b]/20 transition-colors">
                      <i className="ri-question-line text-[#ad023b] text-lg"></i>
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900 group-hover:text-[#ad023b] transition-colors mb-2">
                        {question.q}
                      </h3>
                      <span className="text-sm text-[#ad023b] flex items-center gap-1">
                        Ver respuesta
                        <i className="ri-arrow-right-line group-hover:translate-x-1 transition-transform"></i>
                      </span>
                    </div>
                  </div>
                </Link>
              ))
            )}
        </div>

        <div className="mt-16 grid md:grid-cols-3 gap-8">
          <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-2xl p-8 text-center">
            <div className="w-16 h-16 flex items-center justify-center bg-blue-500 rounded-full mx-auto mb-4">
              <i className="ri-play-circle-line text-3xl text-white"></i>
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">Videos explicativos</h3>
            <p className="text-gray-600 mb-4">Cada pregunta incluye un video tutorial para entenderlo mejor</p>
          </div>
          
          <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-2xl p-8 text-center">
            <div className="w-16 h-16 flex items-center justify-center bg-green-500 rounded-full mx-auto mb-4">
              <i className="ri-share-line text-3xl text-white"></i>
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">Comparte fácilmente</h3>
            <p className="text-gray-600 mb-4">Cada pregunta tiene su propia URL para compartir</p>
          </div>
          
          <div className="bg-gradient-to-br from-purple-50 to-purple-100 rounded-2xl p-8 text-center">
            <div className="w-16 h-16 flex items-center justify-center bg-purple-500 rounded-full mx-auto mb-4">
              <i className="ri-customer-service-2-line text-3xl text-white"></i>
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">Soporte experto</h3>
            <p className="text-gray-600 mb-4">¿No encuentras tu respuesta? Contacta con nuestros expertos</p>
          </div>
        </div>
      </div>
    </section>
  );
}
