'use client';

import { useState } from 'react';
import Link from 'next/link';

const categories = [
  { id: 'autonomia', name: 'Autonomía', icon: 'ri-battery-2-charge-line' },
  { id: 'carga', name: 'Carga', icon: 'ri-charging-pile-2-line' },
  { id: 'costes', name: 'Costes', icon: 'ri-money-euro-circle-line' },
  { id: 'ayudas', name: 'Ayudas', icon: 'ri-hand-coin-line' },
  { id: 'uso-diario', name: 'Uso diario', icon: 'ri-steering-2-line' },
  { id: 'mantenimiento', name: 'Mantenimiento', icon: 'ri-tools-line' },
];

export default function FAQHero() {
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <section className="relative bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 pt-32 pb-20 overflow-hidden">
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-20 left-10 w-72 h-72 bg-[#ad023b] rounded-full blur-3xl"></div>
        <div className="absolute bottom-10 right-20 w-96 h-96 bg-blue-500 rounded-full blur-3xl"></div>
      </div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <nav className="flex items-center justify-center gap-2 text-sm text-gray-400 mb-6">
            <Link href="/" className="hover:text-white transition-colors cursor-pointer">Inicio</Link>
            <i className="ri-arrow-right-s-line"></i>
            <span className="text-white">Preguntas frecuentes</span>
          </nav>
          
          <h1 className="text-4xl md:text-5xl font-bold text-white mb-6">
            Centro de ayuda
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto mb-10">
            Encuentra respuestas a todas tus dudas sobre vehículos eléctricos e híbridos enchufables
          </p>
          
          <div className="max-w-2xl mx-auto relative">
            <div className="relative">
              <i className="ri-search-line absolute left-5 top-1/2 -translate-y-1/2 text-gray-400 text-xl"></i>
              <input
                type="text"
                placeholder="Buscar preguntas..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-14 pr-6 py-4 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 text-white placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-[#ad023b] focus:border-transparent text-lg"
              />
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4 mt-12">
          {categories.map((category) => (
            <Link
              key={category.id}
              href={`/preguntas/${category.id}`}
              className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-4 text-center hover:bg-white/20 transition-all cursor-pointer group"
            >
              <div className="w-12 h-12 flex items-center justify-center bg-[#ad023b]/20 rounded-full mx-auto mb-3 group-hover:bg-[#ad023b]/40 transition-colors">
                <i className={`${category.icon} text-2xl text-[#ad023b]`}></i>
              </div>
              <span className="text-white font-medium text-sm">{category.name}</span>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
