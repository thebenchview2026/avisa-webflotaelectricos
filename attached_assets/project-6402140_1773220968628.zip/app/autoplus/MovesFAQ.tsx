'use client';

import { useState } from 'react';

export default function MovesFAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  const faqs = [
    {
      question: '¿Qué es Autoplus?',
      answer: 'Autoplus es el programa de incentivos del gobierno para la adquisición de vehículos eléctricos e híbridos enchufables. Ofrece ayudas económicas directas que pueden llegar hasta los 7.000€ dependiendo del tipo de vehículo y si se achatarra un vehículo antiguo.'
    },
    {
      question: '¿Cuánto tarda en llegar la ayuda de Autoplus?',
      answer: 'Con Grupo Avisa no tienes que esperar. Adelantamos el 100% de la ayuda de Autoplus en el momento de la compra, por lo que puedes disfrutar del descuento inmediatamente. Nosotros nos encargamos de toda la gestión con la administración.'
    },
    {
      question: '¿Qué significa "achatarramiento"?',
      answer: 'El achatarramiento consiste en dar de baja definitiva un vehículo antiguo (más de 7 años) que esté a tu nombre desde hace al menos 1 año. Al achatarrar, obtienes una ayuda mayor: 7.000€ en lugar de 4.500€ para vehículos eléctricos.'
    },
    {
      question: '¿Puedo solicitar la ayuda si soy autónomo o empresa?',
      answer: 'Sí, Autoplus está abierto a particulares, autónomos, empresas de cualquier tamaño, administraciones públicas y entidades sin ánimo de lucro. Las condiciones y cuantías pueden variar ligeramente según el tipo de beneficiario.'
    },
    {
      question: '¿Es compatible con financiación o renting?',
      answer: 'Sí, la ayuda del Autoplus es compatible con cualquier forma de pago: al contado, financiado o renting. En el caso del renting, la ayuda se aplica reduciendo las cuotas mensuales.'
    },
    {
      question: '¿Qué pasa si se agotan los fondos?',
      answer: 'Las solicitudes se tramitan por orden de llegada. Por eso es importante iniciar el proceso cuanto antes. Te mantenemos informado del estado de los fondos en tu comunidad autónoma y te avisamos si hay riesgo de agotamiento.'
    },
    {
      question: '¿Puedo combinar Autoplus con otras ayudas?',
      answer: 'Sí, Autoplus es compatible con ayudas autonómicas y locales. Algunas comunidades autónomas como Andalucía, Cataluña o Madrid ofrecen incentivos adicionales que se pueden sumar a Autoplus. Te asesoramos sobre todas las ayudas disponibles en tu zona.'
    },
    {
      question: '¿Qué vehículos están excluidos del Autoplus?',
      answer: 'Quedan excluidos los vehículos con precio superior a 45.000€ (sin IVA), los híbridos no enchufables (HEV), los vehículos de ocasión y los que no cumplan los requisitos de autonomía eléctrica mínima (30 km para PHEV).'
    },
    {
      question: '¿Grupo Avisa cobra por gestionar la ayuda?',
      answer: 'No, la gestión del Autoplus es completamente gratuita para nuestros clientes. Nos encargamos de toda la tramitación sin ningún coste adicional y además adelantamos el importe de la ayuda.'
    },
    {
      question: '¿Qué documentación necesito para solicitar la ayuda?',
      answer: 'Necesitarás tu DNI/NIE, certificado de empadronamiento, y si vas a achatarrar, el permiso de circulación y ficha técnica del vehículo a dar de baja. Nosotros te guiamos en todo el proceso y te indicamos exactamente qué documentos aportar.'
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-4xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Preguntas frecuentes sobre Autoplus
          </h2>
          <p className="text-xl text-gray-600">
            Resolvemos las dudas más comunes sobre las ayudas
          </p>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <div 
              key={index}
              className="bg-white rounded-xl shadow-sm overflow-hidden"
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full flex items-center justify-between p-6 text-left cursor-pointer hover:bg-gray-50 transition-colors"
              >
                <span className="font-semibold text-gray-900 pr-4">{faq.question}</span>
                <div className={`w-8 h-8 flex items-center justify-center bg-gray-100 rounded-full flex-shrink-0 transition-transform ${openIndex === index ? 'rotate-180' : ''}`}>
                  <i className="ri-arrow-down-s-line text-gray-600"></i>
                </div>
              </button>
              {openIndex === index && (
                <div className="px-6 pb-6">
                  <p className="text-gray-600 leading-relaxed">{faq.answer}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}