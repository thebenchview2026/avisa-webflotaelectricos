'use client';

import dynamic from 'next/dynamic';
import MovesHero from './MovesHero';
import SubsidyCards from './SubsidyCards';

const RequirementsSection = dynamic(() => import('./RequirementsSection'), {
  loading: () => <div className="h-96 bg-gray-50 animate-pulse" />
});

const ProcessSteps = dynamic(() => import('./ProcessSteps'), {
  loading: () => <div className="h-96 bg-gray-50 animate-pulse" />
});

const RegionalAids = dynamic(() => import('./RegionalAids'), {
  loading: () => <div className="h-96 bg-gray-50 animate-pulse" />
});

const MovesRequestForm = dynamic(() => import('./MovesRequestForm'), {
  loading: () => <div className="h-96 bg-gray-50 animate-pulse" />
});

const TestimonialsSection = dynamic(() => import('./TestimonialsSection'), {
  loading: () => <div className="h-96 bg-gray-50 animate-pulse" />
});

const MovesFAQ = dynamic(() => import('./MovesFAQ'), {
  loading: () => <div className="h-96 bg-gray-50 animate-pulse" />
});

const MovesCTA = dynamic(() => import('./MovesCTA'), {
  loading: () => <div className="h-48 bg-gray-50 animate-pulse" />
});

export default function PlanMovesPage() {
  return (
    <main className="pt-[120px]">
      <MovesHero />
      <SubsidyCards />
      <RequirementsSection />
      <ProcessSteps />
      <RegionalAids />
      <MovesRequestForm />
      <TestimonialsSection />
      <MovesFAQ />
      <MovesCTA />
    </main>
  );
}
