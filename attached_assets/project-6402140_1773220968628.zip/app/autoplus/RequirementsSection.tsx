
export default function RequirementsSection() {
  const requirements = [
    {
      icon: 'ri-user-line',
      title: 'Beneficiarios',
      items: [
        'Personas físicas (particulares)',
        'Autónomos y profesionales',
        'Empresas (PYMES y grandes)',
        'Administraciones públicas',
        'Entidades sin ánimo de lucro'
      ]
    },
    {
      icon: 'ri-car-line',
      title: 'Vehículos elegibles',
      items: [
        'Turismos M1 eléctricos o PHEV',
        'Precio máximo 45.000€ (sin IVA)',
        'Furgonetas N1 hasta 53.000€',
        'Motos eléctricas L3e, L4e, L5e',
        'Cuadriciclos L6e y L7e'
      ]
    },
    {
      icon: 'ri-file-list-3-line',
      title: 'Documentación necesaria',
      items: [
        'DNI/NIE del solicitante',
        'Permiso de circulación (achatarramiento)',
        'Ficha técnica del vehículo a achatarrar',
        'Certificado de empadronamiento',
        'Declaración responsable'
      ]
    },
    {
      icon: 'ri-time-line',
      title: 'Compromisos',
      items: [
        'Mantener el vehículo mínimo 2 años',
        'No vender ni transferir en ese periodo',
        'Uso en territorio español',
        'Estar al corriente con Hacienda y SS',
        'No haber recibido otras ayudas similares'
      ]
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Requisitos para acceder a Autoplus
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Cumplir estos requisitos es fundamental para poder beneficiarte de las ayudas
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {requirements.map((req, index) => (
            <div key={index} className="bg-white rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow">
              <div className="w-14 h-14 flex items-center justify-center bg-[#ad023b]/10 rounded-xl mb-4">
                <i className={`${req.icon} text-2xl text-[#ad023b]`}></i>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-4">{req.title}</h3>
              <ul className="space-y-3">
                {req.items.map((item, idx) => (
                  <li key={idx} className="flex items-start gap-2 text-sm text-gray-600">
                    <i className="ri-check-line text-green-500 mt-0.5 flex-shrink-0"></i>
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
