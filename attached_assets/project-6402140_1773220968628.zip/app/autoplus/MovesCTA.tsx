import Link from 'next/link';

export default function MovesCTA() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div 
          className="relative rounded-3xl overflow-hidden"
          style={{
            backgroundImage: `url('https://readdy.ai/api/search-image?query=Modern%20electric%20car%20showroom%20with%20multiple%20vehicles%20on%20display%20clean%20minimalist%20interior%20design%20bright%20lighting%20professional%20automotive%20dealership%20environment%20wide%20angle%20shot&width=1400&height=500&seq=moves-cta-1&orientation=landscape&format=webp')`
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/70 to-black/50" />
          
          <div className="relative px-8 md:px-16 py-16 md:py-20">
            <div className="max-w-2xl">
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
                ¿Listo para dar el salto a la movilidad eléctrica?
              </h2>
              <p className="text-xl text-white/90 mb-8">
                Visita cualquiera de nuestros 9 concesionarios en Andalucía y Extremadura. 
                Te asesoramos sobre el Plan MOVES y te ayudamos a elegir el vehículo perfecto para ti.
              </p>
              
              <div className="flex flex-wrap gap-4 mb-8">
                <Link 
                  href="/concesionarios"
                  className="inline-flex items-center gap-2 bg-[#ad023b] hover:bg-[#8d0230] text-white px-8 py-4 rounded-lg font-bold transition-all duration-300 cursor-pointer whitespace-nowrap"
                >
                  <i className="ri-map-pin-line"></i>
                  Ver concesionarios
                </Link>
                <a 
                  href="tel:+34955034600"
                  className="inline-flex items-center gap-2 bg-white/10 hover:bg-white/20 text-white px-8 py-4 rounded-lg font-bold transition-all duration-300 cursor-pointer whitespace-nowrap backdrop-blur-sm"
                >
                  <i className="ri-phone-line"></i>
                  955 034 600
                </a>
              </div>

              <div className="flex flex-wrap gap-6 text-white/80 text-sm">
                <div className="flex items-center gap-2">
                  <i className="ri-check-line text-green-400"></i>
                  <span>Gestión gratuita</span>
                </div>
                <div className="flex items-center gap-2">
                  <i className="ri-check-line text-green-400"></i>
                  <span>Ayuda adelantada</span>
                </div>
                <div className="flex items-center gap-2">
                  <i className="ri-check-line text-green-400"></i>
                  <span>Asesoramiento experto</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div 
          className="relative rounded-3xl overflow-hidden mt-12"
          style={{
            backgroundImage: `url('https://readdy.ai/api/search-image?query=Professional%20automotive%20service%20center%20with%20electric%20vehicles%20modern%20clean%20workshop%20environment%20bright%20natural%20lighting%20mechanics%20working%20on%20electric%20cars%20wide%20angle%20professional%20photography&width=1400&height=600&seq=moves-cta-2&orientation=landscape&format=webp')`,
            backgroundSize: 'cover',
            backgroundPosition: 'center'
          }}
        >
          <div className="absolute inset-0 bg-gradient-to-b from-black/70 via-black/60 to-black/70" />
          
          <div className="relative px-8 py-16">
            <div className="text-center mb-8">
              <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
                ¿Listo para aprovechar Autoplus?
              </h2>
              <p className="text-xl text-white/90 max-w-2xl mx-auto">
                Contacta con nosotros y te ayudaremos con toda la gestión de forma gratuita
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
              <Link 
                href="/promociones-electricos"
                className="group bg-white/10 hover:bg-white/20 backdrop-blur-sm rounded-xl p-6 transition-all cursor-pointer"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 flex items-center justify-center bg-green-500/20 rounded-xl group-hover:bg-green-500/30 transition-colors">
                    <i className="ri-flashlight-line text-2xl text-green-400"></i>
                  </div>
                  <div>
                    <h3 className="font-bold text-white group-hover:text-green-400 transition-colors">Vehículos Eléctricos</h3>
                    <p className="text-sm text-white/70">Ver promociones</p>
                  </div>
                  <i className="ri-arrow-right-line text-white/60 ml-auto group-hover:translate-x-1 transition-transform"></i>
                </div>
              </Link>

              <Link 
                href="/promociones-hibridos"
                className="group bg-white/10 hover:bg-white/20 backdrop-blur-sm rounded-xl p-6 transition-all cursor-pointer"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 flex items-center justify-center bg-blue-500/20 rounded-xl group-hover:bg-blue-500/30 transition-colors">
                    <i className="ri-charging-pile-2-line text-2xl text-blue-400"></i>
                  </div>
                  <div>
                    <h3 className="font-bold text-white group-hover:text-blue-400 transition-colors">Híbridos Enchufables</h3>
                    <p className="text-sm text-white/70">Ver promociones</p>
                  </div>
                  <i className="ri-arrow-right-line text-white/60 ml-auto group-hover:translate-x-1 transition-transform"></i>
                </div>
              </Link>

              <Link 
                href="/postventa"
                className="group bg-white/10 hover:bg-white/20 backdrop-blur-sm rounded-xl p-6 transition-all cursor-pointer"
              >
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 flex items-center justify-center bg-purple-500/20 rounded-xl group-hover:bg-purple-500/30 transition-colors">
                    <i className="ri-tools-line text-2xl text-purple-400"></i>
                  </div>
                  <div>
                    <h3 className="font-bold text-white group-hover:text-purple-400 transition-colors">Servicio Postventa</h3>
                    <p className="text-sm text-white/70">Mantenimiento especializado</p>
                  </div>
                  <i className="ri-arrow-right-line text-white/60 ml-auto group-hover:translate-x-1 transition-transform"></i>
                </div>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
