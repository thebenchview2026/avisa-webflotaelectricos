export default function MovesHero() {
  return (
    <section 
      className="relative min-h-[600px] flex items-center"
      style={{
        backgroundImage: `url('https://readdy.ai/api/search-image?query=Modern%20electric%20vehicle%20charging%20at%20home%20wallbox%20installation%20clean%20sustainable%20energy%20concept%20bright%20natural%20lighting%20professional%20photography%20wide%20angle%20shot&width=1920&height=800&seq=moves-hero-1&orientation=landscape&format=webp')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }}
    >
      <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/60 to-transparent" />
      
      <div className="relative max-w-7xl mx-auto px-6 py-20">
        <div className="max-w-2xl">
          <div className="inline-flex items-center gap-2 bg-green-500/90 backdrop-blur-sm text-white px-4 py-2 rounded-full text-sm font-medium mb-6">
            <i className="ri-government-line"></i>
            <span>Autoplus - Programa vigente 2024</span>
          </div>
          
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight">
            Hasta 7.000€ de ayuda para tu vehículo eléctrico
          </h1>
          
          <p className="text-xl text-white/90 mb-8 leading-relaxed">
            Gestión gratuita y ayuda adelantada. Te ayudamos con toda la tramitación del Autoplus 
            para que puedas disfrutar de tu nuevo vehículo eléctrico o híbrido enchufable cuanto antes.
          </p>

          <div className="flex flex-wrap gap-4 mb-8">
            <a 
              href="#calculadora"
              className="inline-flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-8 py-4 rounded-lg font-bold transition-all duration-300 cursor-pointer whitespace-nowrap"
            >
              <i className="ri-calculator-line"></i>
              Calcular mi ayuda
            </a>
            <a 
              href="#solicitar-info"
              className="inline-flex items-center gap-2 bg-white/10 hover:bg-white/20 text-white px-8 py-4 rounded-lg font-bold transition-all duration-300 cursor-pointer whitespace-nowrap backdrop-blur-sm"
            >
              <i className="ri-mail-send-line"></i>
              Solicitar información
            </a>
          </div>

          <div className="grid grid-cols-3 gap-6 max-w-xl">
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 text-center">
              <div className="text-3xl font-bold text-white mb-1">0€</div>
              <div className="text-sm text-white/80">Gestión</div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 text-center">
              <div className="text-3xl font-bold text-white mb-1">100%</div>
              <div className="text-sm text-white/80">Adelantada</div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-xl p-4 text-center">
              <div className="text-3xl font-bold text-white mb-1">+500</div>
              <div className="text-sm text-white/80">Clientes</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
