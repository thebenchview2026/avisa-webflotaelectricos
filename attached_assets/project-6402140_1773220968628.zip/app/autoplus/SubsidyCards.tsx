export default function SubsidyCards() {
  return (
    <section id="calculadora" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            ¿Cuánto puedo ahorrar con Autoplus?
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Las ayudas varían según el tipo de vehículo y si achatarras tu coche antiguo. 
            Descubre cuánto puedes recibir.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-12">
          <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-2xl p-8 border-2 border-green-200 relative overflow-hidden">
            <div className="absolute top-0 right-0 bg-green-500 text-white text-xs font-bold px-4 py-1 rounded-bl-lg">
              MÁS POPULAR
            </div>
            <div className="text-center mb-6">
              <div className="w-20 h-20 flex items-center justify-center bg-green-500 rounded-2xl mx-auto mb-4 shadow-lg">
                <i className="ri-car-line text-4xl text-white"></i>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Vehículos BEV</h3>
              <p className="text-gray-600">100% Eléctricos</p>
            </div>
            <div className="space-y-4">
              <div className="bg-white rounded-xl p-5 shadow-sm">
                <div className="flex items-center gap-2 mb-2">
                  <i className="ri-recycle-line text-green-600"></i>
                  <p className="text-sm text-gray-600">Con achatarramiento</p>
                </div>
                <p className="text-4xl font-bold text-green-600">7.000€</p>
              </div>
              <div className="bg-white rounded-xl p-5 shadow-sm">
                <div className="flex items-center gap-2 mb-2">
                  <i className="ri-car-washing-line text-gray-500"></i>
                  <p className="text-sm text-gray-600">Sin achatarramiento</p>
                </div>
                <p className="text-4xl font-bold text-gray-700">4.500€</p>
              </div>
            </div>
            <p className="text-xs text-gray-500 mt-4 text-center">
              Turismos M1 con precio &lt; 45.000€
            </p>
          </div>

          <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-2xl p-8 border-2 border-blue-200">
            <div className="text-center mb-6">
              <div className="w-20 h-20 flex items-center justify-center bg-blue-500 rounded-2xl mx-auto mb-4 shadow-lg">
                <i className="ri-charging-pile-2-line text-4xl text-white"></i>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Vehículos PHEV</h3>
              <p className="text-gray-600">Híbridos Enchufables</p>
            </div>
            <div className="space-y-4">
              <div className="bg-white rounded-xl p-5 shadow-sm">
                <div className="flex items-center gap-2 mb-2">
                  <i className="ri-recycle-line text-blue-600"></i>
                  <p className="text-sm text-gray-600">Con achatarramiento</p>
                </div>
                <p className="text-4xl font-bold text-blue-600">5.000€</p>
              </div>
              <div className="bg-white rounded-xl p-5 shadow-sm">
                <div className="flex items-center gap-2 mb-2">
                  <i className="ri-car-washing-line text-gray-500"></i>
                  <p className="text-sm text-gray-600">Sin achatarramiento</p>
                </div>
                <p className="text-4xl font-bold text-gray-700">2.500€</p>
              </div>
            </div>
            <p className="text-xs text-gray-500 mt-4 text-center">
              Autonomía eléctrica mínima 30 km
            </p>
          </div>

          <div className="bg-gradient-to-br from-purple-50 to-violet-50 rounded-2xl p-8 border-2 border-purple-200">
            <div className="text-center mb-6">
              <div className="w-20 h-20 flex items-center justify-center bg-purple-500 rounded-2xl mx-auto mb-4 shadow-lg">
                <i className="ri-plug-line text-4xl text-white"></i>
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Puntos de recarga</h3>
              <p className="text-gray-600">Infraestructura</p>
            </div>
            <div className="space-y-4">
              <div className="bg-white rounded-xl p-5 shadow-sm">
                <div className="flex items-center gap-2 mb-2">
                  <i className="ri-home-4-line text-purple-600"></i>
                  <p className="text-sm text-gray-600">Uso privado</p>
                </div>
                <p className="text-4xl font-bold text-purple-600">70%</p>
                <p className="text-sm text-gray-500">Hasta 1.500€</p>
              </div>
              <div className="bg-white rounded-xl p-5 shadow-sm">
                <div className="flex items-center gap-2 mb-2">
                  <i className="ri-building-line text-gray-500"></i>
                  <p className="text-sm text-gray-600">Comunidades</p>
                </div>
                <p className="text-4xl font-bold text-gray-700">80%</p>
                <p className="text-sm text-gray-500">Hasta 5.000€</p>
              </div>
            </div>
            <p className="text-xs text-gray-500 mt-4 text-center">
              Wallbox y cargadores domésticos
            </p>
          </div>
        </div>

        <div className="bg-amber-50 border border-amber-200 rounded-xl p-6 flex items-start gap-4">
          <div className="w-12 h-12 flex items-center justify-center bg-amber-100 rounded-full flex-shrink-0">
            <i className="ri-information-line text-2xl text-amber-600"></i>
          </div>
          <div>
            <h4 className="font-bold text-gray-900 mb-1">Importante sobre el achatarramiento</h4>
            <p className="text-gray-600">
              Para obtener la ayuda máxima, debes dar de baja un vehículo de tu propiedad con más de 7 años de antigüedad. 
              El vehículo debe haber estado a tu nombre durante al menos 1 año antes de la solicitud.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}