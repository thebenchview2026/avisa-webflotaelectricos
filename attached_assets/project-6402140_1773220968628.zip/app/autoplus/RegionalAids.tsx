export default function RegionalAids() {
  const regions = [
    {
      name: 'Andalucía',
      status: 'Activo',
      extra: 'Hasta 2.000€ adicionales',
      details: 'Ayudas complementarias para residentes en Andalucía',
      color: 'green'
    },
    {
      name: 'Extremadura',
      status: 'Activo',
      extra: 'Hasta 1.500€ adicionales',
      details: 'Subvenciones autonómicas acumulables',
      color: 'green'
    },
    {
      name: 'Sevilla',
      status: 'Consultar',
      extra: 'Bonificaciones municipales',
      details: 'Descuentos en impuesto de circulación',
      color: 'blue'
    },
    {
      name: 'Málaga',
      status: 'Consultar',
      extra: 'Bonificaciones municipales',
      details: 'Beneficios fiscales para vehículos 0 emisiones',
      color: 'blue'
    }
  ];

  return (
    <section className="py-20 bg-gradient-to-b from-gray-50 to-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Ayudas autonómicas complementarias a Autoplus
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Además de Autoplus, algunas comunidades autónomas ofrecen ayudas adicionales
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {regions.map((region, index) => (
            <div key={index} className="bg-white rounded-xl p-6 shadow-sm border border-gray-100">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-bold text-gray-900">{region.name}</h3>
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                  region.color === 'green' 
                    ? 'bg-green-100 text-green-700' 
                    : 'bg-blue-100 text-blue-700'
                }`}>
                  {region.status}
                </span>
              </div>
              <p className="text-[#ad023b] font-semibold mb-2">{region.extra}</p>
              <p className="text-sm text-gray-600">{region.details}</p>
            </div>
          ))}
        </div>

        <div className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100">
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">
                Ejemplo de ayudas acumuladas
              </h3>
              <p className="text-gray-600 mb-6">
                Un particular residente en Andalucía que compre un vehículo 100% eléctrico 
                y achatarre su coche antiguo puede obtener:
              </p>
              <div className="space-y-3">
                <div className="flex justify-between items-center py-3 border-b border-gray-100">
                  <span className="text-gray-600">Plan MOVES III (nacional)</span>
                  <span className="font-bold text-gray-900">7.000€</span>
                </div>
                <div className="flex justify-between items-center py-3 border-b border-gray-100">
                  <span className="text-gray-600">Ayuda autonómica Andalucía</span>
                  <span className="font-bold text-gray-900">2.000€</span>
                </div>
                <div className="flex justify-between items-center py-3 border-b border-gray-100">
                  <span className="text-gray-600">Descuento marca (según modelo)</span>
                  <span className="font-bold text-gray-900">Variable</span>
                </div>
                <div className="flex justify-between items-center py-3 bg-green-50 rounded-lg px-4">
                  <span className="font-bold text-gray-900">Total ayudas</span>
                  <span className="text-2xl font-bold text-green-600">Hasta 9.000€</span>
                </div>
              </div>
            </div>
            <div className="bg-gradient-to-br from-[#ad023b]/5 to-[#ad023b]/10 rounded-xl p-6">
              <div className="w-16 h-16 flex items-center justify-center bg-[#ad023b] rounded-xl mb-4">
                <i className="ri-customer-service-2-line text-3xl text-white"></i>
              </div>
              <h4 className="text-xl font-bold text-gray-900 mb-3">
                Te asesoramos sin compromiso
              </h4>
              <p className="text-gray-600 mb-6">
                Cada caso es diferente. Contacta con nosotros y te informamos de todas 
                las ayudas disponibles para tu situación particular.
              </p>
              <a 
                href="https://wa.me/34955034600"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-[#ad023b] hover:bg-[#8d0230] text-white px-6 py-3 rounded-lg font-semibold transition-colors cursor-pointer whitespace-nowrap"
              >
                <i className="ri-whatsapp-line"></i>
                Escríbeme
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
