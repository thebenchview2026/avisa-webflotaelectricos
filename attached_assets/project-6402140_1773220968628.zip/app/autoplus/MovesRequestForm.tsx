'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function MovesRequestForm() {
  const router = useRouter();
  const [formData, setFormData] = useState({
    nombre: '',
    email: '',
    telefono: '',
    tipo_vehiculo: '',
    vehiculo_actual: '',
    presupuesto: '',
    mensaje: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [acceptTerms, setAcceptTerms] = useState(false);
  const [acceptMarketing, setAcceptMarketing] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (formData.mensaje.length > 500 || !acceptTerms) {
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      const formBody = new URLSearchParams();
      Object.entries(formData).forEach(([key, value]) => {
        formBody.append(key, value);
      });
      formBody.append('acepta_terminos', acceptTerms ? 'Sí' : 'No');
      formBody.append('acepta_marketing', acceptMarketing ? 'Sí' : 'No');

      const response = await fetch('https://readdy.ai/api/form/d68s7k7mvg9ih2c79nq0', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: formBody.toString(),
      });

      if (response.ok) {
        const params = new URLSearchParams({
          nombre: formData.nombre,
          tipo: formData.tipo_vehiculo
        });
        router.push(`/confirmacion-moves?${params.toString()}`);
      } else {
        setSubmitStatus('error');
      }
    } catch {
      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section id="solicitar-info" className="py-20 bg-gradient-to-b from-white to-slate-50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Solicita información sobre Autoplus
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Déjanos tus datos y te ayudaremos con toda la gestión de forma gratuita
          </p>
        </div>
        <div className="grid lg:grid-cols-2 gap-16 items-start">
          <div>
            <div className="inline-flex items-center gap-2 bg-green-100 text-green-700 px-4 py-2 rounded-full text-sm font-medium mb-6">
              <i className="ri-mail-send-line"></i>
              <span>Solicita información</span>
            </div>
            
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-6">
              ¿Tienes dudas sobre el Plan MOVES?
            </h2>
            
            <p className="text-lg text-slate-600 mb-8 leading-relaxed">
              Nuestro equipo de expertos te asesorará sin compromiso sobre las ayudas disponibles 
              y cómo aplicarlas a tu caso particular.
            </p>

            <div className="space-y-6">
              <div className="flex gap-4 items-start">
                <div className="w-12 h-12 rounded-xl bg-green-100 flex items-center justify-center flex-shrink-0">
                  <i className="ri-shield-check-line text-2xl text-green-600"></i>
                </div>
                <div>
                  <h3 className="font-semibold text-slate-900 mb-1">Gestión 100% gratuita</h3>
                  <p className="text-slate-600 text-sm">No cobramos nada por tramitar tu ayuda del Plan MOVES.</p>
                </div>
              </div>

              <div className="flex gap-4 items-start">
                <div className="w-12 h-12 rounded-xl bg-green-100 flex items-center justify-center flex-shrink-0">
                  <i className="ri-money-euro-circle-line text-2xl text-green-600"></i>
                </div>
                <div>
                  <h3 className="font-semibold text-slate-900 mb-1">Ayuda adelantada</h3>
                  <p className="text-slate-600 text-sm">Descontamos la ayuda directamente del precio del vehículo.</p>
                </div>
              </div>

              <div className="flex gap-4 items-start">
                <div className="w-12 h-12 rounded-xl bg-green-100 flex items-center justify-center flex-shrink-0">
                  <i className="ri-time-line text-2xl text-green-600"></i>
                </div>
                <div>
                  <h3 className="font-semibold text-slate-900 mb-1">Respuesta en 24h</h3>
                  <p className="text-slate-600 text-sm">Te contactamos en menos de 24 horas laborables.</p>
                </div>
              </div>

              <div className="flex gap-4 items-start">
                <div className="w-12 h-12 rounded-xl bg-green-100 flex items-center justify-center flex-shrink-0">
                  <i className="ri-file-list-3-line text-2xl text-green-600"></i>
                </div>
                <div>
                  <h3 className="font-semibold text-slate-900 mb-1">Asesoramiento personalizado</h3>
                  <p className="text-slate-600 text-sm">Analizamos tu caso y te indicamos la mejor opción.</p>
                </div>
              </div>
            </div>

            <div className="mt-10 p-6 bg-green-50 border border-green-200 rounded-2xl">
              <div className="flex items-center gap-3 mb-3">
                <i className="ri-phone-line text-2xl text-green-600"></i>
                <span className="font-semibold text-slate-900">¿Prefieres llamarnos?</span>
              </div>
              <a href="tel:+34955034600" className="text-2xl font-bold text-green-600 hover:text-green-700 transition-colors">
                955 034 600
              </a>
              <p className="text-sm text-slate-600 mt-2">Lunes a Viernes de 9:00 a 18:00</p>
              <p className="text-sm text-slate-600 mt-1">Email: info@grupoavisa.com</p>
            </div>
          </div>

          <div className="bg-white border border-slate-200 rounded-2xl p-8 shadow-lg">
            {submitStatus === 'success' ? (
              <div className="text-center py-12">
                <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <i className="ri-check-line text-4xl text-green-600"></i>
                </div>
                <h3 className="text-2xl font-bold text-slate-900 mb-3">¡Solicitud enviada!</h3>
                <p className="text-slate-600 mb-6">Te contactaremos en menos de 24 horas laborables para resolver todas tus dudas sobre el Plan MOVES.</p>
                <button
                  onClick={() => setSubmitStatus('idle')}
                  className="text-green-600 font-medium hover:text-green-700 transition-colors cursor-pointer"
                >
                  Enviar otra solicitud
                </button>
              </div>
            ) : (
              <>
                <div className="flex items-start gap-4 mb-6 p-4 bg-green-50 rounded-xl border border-green-100">
                  <img 
                    src="https://static.readdy.ai/image/ecd9e0a88a19846633f9ef23a8543c57/7da821f8687606f5711af9936393378a.jpeg" 
                    alt="Ana - Asesora de vehículos eléctricos"
                    className="w-16 h-16 rounded-full object-cover flex-shrink-0"
                  />
                  <div>
                    <p className="text-sm text-slate-700 leading-relaxed">
                      <span className="font-semibold text-slate-900">La persona que te va a atender es Ana</span>, lleva más de 10 años como profesional de flotas en Avisa y de forma rápida tendrás un asesoramiento directo de alta calidad.
                    </p>
                  </div>
                </div>

                <div className="mb-6">
                  <h3 className="text-xl font-bold text-slate-900 mb-2">Solicitar información</h3>
                  <p className="text-slate-600 text-sm">Completa el formulario y te asesoraremos sin compromiso.</p>
                </div>

                <form id="moves-request-form" data-readdy-form onSubmit={handleSubmit} className="space-y-5">
                  <div>
                    <label htmlFor="nombre" className="block text-sm font-medium text-slate-900 mb-2">
                      Nombre completo <span className="text-red-500">*</span>
                    </label>
                    <input
                      id="nombre"
                      name="nombre"
                      required
                      value={formData.nombre}
                      onChange={(e) => setFormData({ ...formData, nombre: e.target.value })}
                      className="w-full px-4 py-3 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-colors"
                      placeholder="Tu nombre"
                    />
                  </div>

                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-slate-900 mb-2">
                      Email <span className="text-red-500">*</span>
                    </label>
                    <input
                      id="email"
                      name="email"
                      type="email"
                      required
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      className="w-full px-4 py-3 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-colors"
                      placeholder="tu@email.com"
                    />
                  </div>

                  <div>
                    <label htmlFor="telefono" className="block text-sm font-medium text-slate-900 mb-2">
                      Teléfono <span className="text-red-500">*</span>
                    </label>
                    <input
                      id="telefono"
                      name="telefono"
                      type="tel"
                      required
                      value={formData.telefono}
                      onChange={(e) => setFormData({ ...formData, telefono: e.target.value })}
                      className="w-full px-4 py-3 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent transition-colors"
                      placeholder="600 000 000"
                    />
                  </div>

                  <div>
                    <label htmlFor="tipo_vehiculo" className="block text-sm font-medium text-slate-900 mb-2">
                      Tipo de vehículo de interés <span className="text-red-500">*</span>
                    </label>
                    <select
                      id="tipo_vehiculo"
                      name="tipo_vehiculo"
                      required
                      value={formData.tipo_vehiculo}
                      onChange={(e) => setFormData({ ...formData, tipo_vehiculo: e.target.value })}
                      className="w-full px-4 py-3 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent pr-8"
                    >
                      <option value="">Selecciona una opción</option>
                      <option value="electrico">100% Eléctrico (BEV)</option>
                      <option value="hibrido_enchufable">Híbrido Enchufable (PHEV)</option>
                      <option value="ambos">Ambos / No estoy seguro</option>
                    </select>
                  </div>

                  <div>
                    <label htmlFor="vehiculo_actual" className="block text-sm font-medium text-slate-900 mb-2">
                      ¿Tienes vehículo para achatarrar?
                    </label>
                    <select
                      id="vehiculo_actual"
                      name="vehiculo_actual"
                      value={formData.vehiculo_actual}
                      onChange={(e) => setFormData({ ...formData, vehiculo_actual: e.target.value })}
                      className="w-full px-4 py-3 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent pr-8"
                    >
                      <option value="">Selecciona una opción</option>
                      <option value="si_mas_7">Sí, con más de 7 años</option>
                      <option value="si_menos_7">Sí, con menos de 7 años</option>
                      <option value="no">No tengo vehículo para achatarrar</option>
                    </select>
                    <p className="text-xs text-slate-500 mt-1">Achatarrar un vehículo de +7 años aumenta la ayuda</p>
                  </div>

                  <div>
                    <label htmlFor="presupuesto" className="block text-sm font-medium text-slate-900 mb-2">
                      Presupuesto aproximado
                    </label>
                    <select
                      id="presupuesto"
                      name="presupuesto"
                      value={formData.presupuesto}
                      onChange={(e) => setFormData({ ...formData, presupuesto: e.target.value })}
                      className="w-full px-4 py-3 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent pr-8"
                    >
                      <option value="">Selecciona una opción</option>
                      <option value="menos_30000">Menos de 30.000€</option>
                      <option value="30000_45000">30.000€ - 45.000€</option>
                      <option value="mas_45000">Más de 45.000€</option>
                    </select>
                  </div>

                  <div>
                    <label htmlFor="mensaje" className="block text-sm font-medium text-slate-900 mb-2">
                      ¿Alguna duda o comentario?
                    </label>
                    <textarea
                      id="mensaje"
                      name="mensaje"
                      maxLength={500}
                      rows={3}
                      value={formData.mensaje}
                      onChange={(e) => setFormData({ ...formData, mensaje: e.target.value })}
                      className="w-full px-4 py-3 border border-slate-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent resize-none transition-colors"
                      placeholder="Cuéntanos tus dudas sobre el Plan MOVES..."
                    />
                    <div className="flex justify-end mt-1">
                      <p className="text-xs text-slate-500">{formData.mensaje.length}/500</p>
                    </div>
                  </div>

                  <div className="space-y-3">
                    <label className="flex items-start gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={acceptTerms}
                        onChange={(e) => setAcceptTerms(e.target.checked)}
                        className="mt-1 w-4 h-4 text-green-600 border-slate-300 rounded focus:ring-green-500 cursor-pointer"
                        required
                      />
                      <span className="text-sm text-slate-600">
                        He leído y acepto <a href="/terminos" className="text-green-600 underline hover:text-green-700">los términos y condiciones de la política de privacidad</a>.
                      </span>
                    </label>
                    
                    <label className="flex items-start gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={acceptMarketing}
                        onChange={(e) => setAcceptMarketing(e.target.checked)}
                        className="mt-1 w-4 h-4 text-green-600 border-slate-300 rounded focus:ring-green-500 cursor-pointer"
                      />
                      <span className="text-sm text-slate-600">
                        Doy mi consentimiento para el tratamiento de mis datos personales con fines de marketing y comerciales (Opcional)
                      </span>
                    </label>
                  </div>

                  <button
                    type="submit"
                    disabled={isSubmitting || formData.mensaje.length > 500 || !acceptTerms}
                    className="w-full bg-green-600 text-white px-6 py-4 rounded-lg font-bold hover:bg-green-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap cursor-pointer flex items-center justify-center gap-2"
                  >
                    {isSubmitting ? (
                      'Enviando...'
                    ) : (
                      <>
                        <i className="ri-send-plane-line"></i>
                        Solicitar información
                      </>
                    )}
                  </button>

                  <p className="text-xs text-slate-500 text-center">
                    Al enviar este formulario aceptas que contactemos contigo para informarte sobre el Plan MOVES.
                  </p>

                  {submitStatus === 'error' && (
                    <p className="text-sm text-red-600 text-center">
                      Ha ocurrido un error. Por favor, inténtalo de nuevo.
                    </p>
                  )}
                </form>
              </>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
