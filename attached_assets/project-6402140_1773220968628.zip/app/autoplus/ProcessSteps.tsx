
export default function ProcessSteps() {
  const steps = [
    {
      number: '01',
      title: 'Elige tu vehículo',
      description: 'Visita cualquiera de nuestros concesionarios y selecciona el modelo eléctrico o híbrido enchufable que mejor se adapte a tus necesidades.',
      icon: 'ri-search-line'
    },
    {
      number: '02',
      title: 'Verificamos tu elegibilidad',
      description: 'Nuestro equipo comprueba que cumples todos los requisitos del Plan MOVES y te asesora sobre la mejor opción de ayuda.',
      icon: 'ri-checkbox-circle-line'
    },
    {
      number: '03',
      title: 'Preparamos la documentación',
      description: 'Te indicamos exactamente qué documentos necesitas y te ayudamos a recopilarlos. Solo necesitarás firmar.',
      icon: 'ri-file-text-line'
    },
    {
      number: '04',
      title: 'Tramitamos la solicitud',
      description: 'Presentamos toda la documentación ante la administración correspondiente y hacemos seguimiento del expediente.',
      icon: 'ri-send-plane-line'
    },
    {
      number: '05',
      title: 'Adelantamos la ayuda',
      description: 'No tienes que esperar a que se apruebe. Aplicamos el descuento de la ayuda directamente en la compra de tu vehículo.',
      icon: 'ri-money-euro-circle-line'
    },
    {
      number: '06',
      title: 'Disfruta tu vehículo',
      description: 'Recoge tu nuevo coche eléctrico y empieza a disfrutar de la movilidad sostenible. Nosotros seguimos con la gestión.',
      icon: 'ri-car-line'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            ¿Cómo funciona el proceso de Autoplus?
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Te acompañamos en cada paso para que recibas tu ayuda sin complicaciones
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {steps.map((step, index) => (
            <div key={index} className="relative">
              <div className="bg-gray-50 rounded-2xl p-6 h-full hover:bg-gray-100 transition-colors">
                <div className="flex items-start gap-4 mb-4">
                  <div className="w-12 h-12 flex items-center justify-center bg-[#ad023b] rounded-xl flex-shrink-0">
                    <i className={`${step.icon} text-xl text-white`}></i>
                  </div>
                  <span className="text-5xl font-bold text-gray-200">{step.number}</span>
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-16 bg-gradient-to-r from-[#ad023b] to-[#8d0230] rounded-2xl p-8 md:p-12">
          <div className="grid md:grid-cols-3 gap-8 text-center">
            <div>
              <div className="text-5xl font-bold text-white mb-2">0€</div>
              <p className="text-white/80">Coste de gestión</p>
            </div>
            <div>
              <div className="text-5xl font-bold text-white mb-2">100%</div>
              <p className="text-white/80">Ayuda adelantada</p>
            </div>
            <div>
              <div className="text-5xl font-bold text-white mb-2">+500</div>
              <p className="text-white/80">Solicitudes gestionadas</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
