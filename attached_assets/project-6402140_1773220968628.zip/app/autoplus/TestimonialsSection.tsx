
'use client';

import { useState } from 'react';

const testimonials = [
  {
    id: 1,
    name: 'María García López',
    location: 'Sevilla',
    vehicle: 'Volkswagen ID.4',
    subsidy: '7.000€',
    image: 'https://readdy.ai/api/search-image?query=Professional%20Spanish%20woman%20in%20her%2040s%20smiling%20warmly%20portrait%20photo%20natural%20lighting%20clean%20white%20background%20friendly%20expression%20business%20casual%20attire&width=200&height=200&seq=test1&orientation=squarish&format=webp',
    quote: 'El proceso fue muy sencillo. El equipo de Movesur se encargó de toda la gestión y en menos de 3 meses ya tenía mi nuevo coche eléctrico con la ayuda aplicada. ¡Ahorro más de 150€ al mes en combustible!',
    rating: 5,
    date: 'Marzo 2024'
  },
  {
    id: 2,
    name: 'Antonio Fernández Ruiz',
    location: 'Málaga',
    vehicle: 'Škoda Enyaq iV',
    subsidy: '7.000€',
    image: 'https://readdy.ai/api/search-image?query=Professional%20Spanish%20man%20in%20his%2050s%20smiling%20portrait%20photo%20natural%20lighting%20clean%20white%20background%20friendly%20expression%20casual%20smart%20attire&width=200&height=200&seq=test2&orientation=squarish&format=webp',
    quote: 'Tenía dudas sobre pasarme al eléctrico, pero con la ayuda del Plan MOVES y el asesoramiento de Movesur, fue la mejor decisión. La gestión de la subvención fue totalmente gratuita y muy rápida.',
    rating: 5,
    date: 'Febrero 2024'
  },
  {
    id: 3,
    name: 'Carmen Moreno Díaz',
    location: 'Córdoba',
    vehicle: 'Audi Q4 e-tron',
    subsidy: '4.500€',
    image: 'https://readdy.ai/api/search-image?query=Professional%20Spanish%20woman%20in%20her%2030s%20smiling%20portrait%20photo%20natural%20lighting%20clean%20white%20background%20confident%20expression%20modern%20style&width=200&height=200&seq=test3&orientation=squarish&format=webp',
    quote: 'Como autónoma, el Plan MOVES me permitió renovar mi vehículo de empresa con una ayuda significativa. El equipo me explicó todos los requisitos y se ocuparon de todo el papeleo.',
    rating: 5,
    date: 'Enero 2024'
  },
  {
    id: 4,
    name: 'Francisco Jiménez Torres',
    location: 'Huelva',
    vehicle: 'Volkswagen ID.3',
    subsidy: '7.000€',
    image: 'https://readdy.ai/api/search-image?query=Professional%20Spanish%20man%20in%20his%2040s%20smiling%20portrait%20photo%20natural%20lighting%20clean%20white%20background%20friendly%20approachable%20expression&width=200&height=200&seq=test4&orientation=squarish&format=webp',
    quote: 'Achatarré mi antiguo diésel y conseguí la ayuda máxima de 7.000€. Además, con las ayudas regionales de Andalucía sumé otros 2.000€. El ahorro total fue increíble.',
    rating: 5,
    date: 'Diciembre 2023'
  },
  {
    id: 5,
    name: 'Laura Sánchez Martín',
    location: 'Sevilla',
    vehicle: 'Volkswagen ID.Buzz',
    subsidy: '7.000€',
    image: 'https://readdy.ai/api/search-image?query=Professional%20Spanish%20woman%20in%20her%2045s%20smiling%20portrait%20photo%20natural%20lighting%20clean%20white%20background%20warm%20friendly%20expression&width=200&height=200&seq=test5&orientation=squarish&format=webp',
    quote: 'Necesitaba un vehículo familiar grande y el ID.Buzz era perfecto. Gracias al Plan MOVES y la financiación especial, pude acceder a él. El equipo de Movesur fue excepcional.',
    rating: 5,
    date: 'Noviembre 2023'
  },
  {
    id: 6,
    name: 'Pedro Romero Vega',
    location: 'Cádiz',
    vehicle: 'Škoda Octavia iV',
    subsidy: '5.000€',
    image: 'https://readdy.ai/api/search-image?query=Professional%20Spanish%20man%20in%20his%2035s%20smiling%20portrait%20photo%20natural%20lighting%20clean%20white%20background%20professional%20confident%20look&width=200&height=200&seq=test6&orientation=squarish&format=webp',
    quote: 'Opté por un híbrido enchufable y recibí 5.000€ de ayuda. Perfecto para mis desplazamientos diarios en eléctrico y viajes largos sin preocupaciones. Muy contento con la gestión.',
    rating: 5,
    date: 'Octubre 2023'
  }
];

export default function TestimonialsSection() {
  const [activeIndex, setActiveIndex] = useState(0);
  const visibleCount = 3;

  const nextSlide = () => {
    setActiveIndex((prev) => (prev + 1) % (testimonials.length - visibleCount + 1));
  };

  const prevSlide = () => {
    setActiveIndex((prev) => (prev - 1 + (testimonials.length - visibleCount + 1)) % (testimonials.length - visibleCount + 1));
  };

  return (
    <section className="py-20 bg-gradient-to-b from-white to-gray-50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Clientes satisfechos con Autoplus
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Más de 500 clientes ya han confiado en nosotros para gestionar sus ayudas
          </p>
        </div>

        <div className="relative">
          <div className="flex gap-6 overflow-hidden">
            {testimonials.slice(activeIndex, activeIndex + visibleCount).map((testimonial) => (
              <div
                key={testimonial.id}
                className="flex-1 min-w-0 bg-white rounded-2xl p-6 shadow-lg border border-gray-100 transition-all duration-300 hover:shadow-xl"
              >
                <div className="flex items-start gap-4 mb-4">
                  <img
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-16 h-16 rounded-full object-cover object-top border-2 border-green-500"
                  />
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900">{testimonial.name}</h3>
                    <p className="text-sm text-gray-500 flex items-center gap-1">
                      <i className="ri-map-pin-line"></i>
                      {testimonial.location}
                    </p>
                    <div className="flex items-center gap-1 mt-1">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <i key={i} className="ri-star-fill text-yellow-400 text-sm"></i>
                      ))}
                    </div>
                  </div>
                </div>

                <blockquote className="text-gray-600 text-sm leading-relaxed mb-4 italic">
                  "{testimonial.quote}"
                </blockquote>

                <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                  <div className="flex items-center gap-2">
                    <div className="w-8 h-8 flex items-center justify-center bg-gray-100 rounded-lg">
                      <i className="ri-car-line text-gray-600"></i>
                    </div>
                    <span className="text-sm font-medium text-gray-700">{testimonial.vehicle}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-gray-500">{testimonial.date}</span>
                    <span className="bg-green-100 text-green-700 px-3 py-1 rounded-full text-sm font-semibold">
                      {testimonial.subsidy}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="flex items-center justify-center gap-4 mt-8">
            <button
              onClick={prevSlide}
              className="w-12 h-12 flex items-center justify-center rounded-full bg-white border border-gray-200 text-gray-600 hover:bg-gray-50 hover:border-gray-300 transition-all cursor-pointer shadow-sm"
              aria-label="Anterior"
            >
              <i className="ri-arrow-left-s-line text-xl"></i>
            </button>
            <div className="flex gap-2">
              {[...Array(testimonials.length - visibleCount + 1)].map((_, i) => (
                <button
                  key={i}
                  onClick={() => setActiveIndex(i)}
                  className={`w-2.5 h-2.5 rounded-full transition-all cursor-pointer ${
                    i === activeIndex ? 'bg-green-600 w-8' : 'bg-gray-300 hover:bg-gray-400'
                  }`}
                  aria-label={`Ir a slide ${i + 1}`}
                />
              ))}
            </div>
            <button
              onClick={nextSlide}
              className="w-12 h-12 flex items-center justify-center rounded-full bg-white border border-gray-200 text-gray-600 hover:bg-gray-50 hover:border-gray-300 transition-all cursor-pointer shadow-sm"
              aria-label="Siguiente"
            >
              <i className="ri-arrow-right-s-line text-xl"></i>
            </button>
          </div>
        </div>

        <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-6">
          <div className="text-center p-4 bg-white rounded-xl shadow-sm border border-gray-100">
            <div className="text-3xl font-bold text-green-600 mb-1">+500</div>
            <div className="text-sm text-gray-600">Clientes beneficiados</div>
          </div>
          <div className="text-center p-4 bg-white rounded-xl shadow-sm border border-gray-100">
            <div className="text-3xl font-bold text-green-600 mb-1">3.2M€</div>
            <div className="text-sm text-gray-600">En ayudas gestionadas</div>
          </div>
          <div className="text-center p-4 bg-white rounded-xl shadow-sm border border-gray-100">
            <div className="text-3xl font-bold text-green-600 mb-1">100%</div>
            <div className="text-sm text-gray-600">Gestión gratuita</div>
          </div>
          <div className="text-center p-4 bg-white rounded-xl shadow-sm border border-gray-100">
            <div className="text-3xl font-bold text-green-600 mb-1">4.9/5</div>
            <div className="text-sm text-gray-600">Valoración media</div>
          </div>
        </div>
      </div>
    </section>
  );
}
