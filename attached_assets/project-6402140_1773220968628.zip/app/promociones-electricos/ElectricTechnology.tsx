
'use client';

export default function ElectricTechnology() {
  const technologies = [
    {
      icon: 'ri-battery-2-charge-line',
      title: 'Baterías de última generación',
      description: 'Tecnología de iones de litio con alta densidad energética, garantía de 8 años y capacidad de carga rápida hasta el 80% en 30 minutos.'
    },
    {
      icon: 'ri-flashlight-line',
      title: 'Motores eléctricos eficientes',
      description: 'Motores síncronos de imanes permanentes con eficiencia superior al 95%, par instantáneo y conducción silenciosa.'
    },
    {
      icon: 'ri-refresh-line',
      title: 'Frenado regenerativo',
      description: 'Sistema que recupera energía durante la frenada, aumentando la autonomía hasta un 20% en conducción urbana.'
    },
    {
      icon: 'ri-smartphone-line',
      title: 'Conectividad total',
      description: 'Control remoto desde tu smartphone: preclimatización, estado de carga, localización y actualizaciones OTA.'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="font-['Playfair_Display'] text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Tecnología eléctrica avanzada
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Los vehículos eléctricos representan la evolución más significativa en la historia del automóvil. Descubre la tecnología que hace posible una movilidad más limpia, eficiente y conectada.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 mb-16">
          {technologies.map((tech, index) => (
            <div key={index} className="bg-slate-50 rounded-xl p-6 hover:shadow-lg transition-shadow">
              <div className="w-14 h-14 flex items-center justify-center bg-[#ad023b] text-white rounded-xl mb-4">
                <i className={`${tech.icon} text-2xl`}></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">{tech.title}</h3>
              <p className="text-gray-600 text-sm leading-relaxed">{tech.description}</p>
            </div>
          ))}
        </div>

        <div className="bg-gradient-to-br from-slate-900 to-slate-800 rounded-2xl overflow-hidden">
          <div className="grid lg:grid-cols-2 gap-0">
            <div className="p-10 lg:p-12 flex flex-col justify-center">
              <h3 className="font-['Playfair_Display'] text-2xl md:text-3xl font-bold text-white mb-6">
                ¿Cómo funciona un vehículo eléctrico?
              </h3>
              <div className="space-y-4">
                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 flex items-center justify-center bg-[#ad023b] text-white rounded-full flex-shrink-0 font-bold text-sm">1</div>
                  <div>
                    <p className="font-semibold text-white">Almacenamiento de energía</p>
                    <p className="text-white/70 text-sm">La batería almacena electricidad que alimenta el motor eléctrico.</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 flex items-center justify-center bg-[#ad023b] text-white rounded-full flex-shrink-0 font-bold text-sm">2</div>
                  <div>
                    <p className="font-semibold text-white">Conversión de energía</p>
                    <p className="text-white/70 text-sm">El inversor convierte la corriente continua en alterna para el motor.</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 flex items-center justify-center bg-[#ad023b] text-white rounded-full flex-shrink-0 font-bold text-sm">3</div>
                  <div>
                    <p className="font-semibold text-white">Propulsión instantánea</p>
                    <p className="text-white/70 text-sm">El motor eléctrico genera par máximo desde el primer momento.</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-8 h-8 flex items-center justify-center bg-[#ad023b] text-white rounded-full flex-shrink-0 font-bold text-sm">4</div>
                  <div>
                    <p className="font-semibold text-white">Recuperación de energía</p>
                    <p className="text-white/70 text-sm">Al frenar, el motor actúa como generador y recarga la batería.</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="relative min-h-[400px]">
              <img
                src="https://readdy.ai/api/search-image?query=detailed%20cutaway%20technical%20illustration%20of%20electric%20vehicle%20powertrain%20showing%20battery%20pack%20motor%20and%20electronics%2C%20clean%20modern%20infographic%20style%20with%20blue%20accent%20lighting%20on%20dark%20background%2C%20professional%20automotive%20engineering%20visualization&width=800&height=600&seq=ev-tech-cutaway-1&orientation=landscape&format=webp"
                alt="Tecnología vehículo eléctrico"
                className="absolute inset-0 w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
