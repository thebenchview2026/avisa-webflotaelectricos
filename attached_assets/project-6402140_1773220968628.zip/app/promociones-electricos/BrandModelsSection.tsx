
'use client';

import { useState } from 'react';
import Link from 'next/link';

const brands = [
  {
    id: 'volkswagen',
    name: 'Volkswagen',
    logo: 'https://readdy.ai/api/search-image?query=Volkswagen%20logo%20simple%20clean%20vector%20style%20on%20white%20background%20minimalist%20automotive%20brand%20identity&width=80&height=60&seq=vw-logo-1&orientation=landscape&format=webp',
    models: [
      {
        id: 'id3',
        slug: 'volkswagen-id3-pro',
        name: 'ID.3 Pro',
        type: '100% Eléctrico',
        price: '399€/mes',
        pvp: '42.900€',
        badge: 'Más vendido',
        image: 'https://readdy.ai/api/search-image?query=Volkswagen%20ID3%20electric%20hatchback%20in%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20modern%20compact%20electric%20car&width=480&height=320&seq=vw-id3-1&orientation=landscape&format=webp',
        specs: {
          autonomia: '426 km',
          potencia: '204 CV',
          bateria: '58 kWh',
          cargaRapida: '30 min (80%)',
          aceleracion: '7.3 s (0-100)',
          consumo: '14.5 kWh/100km'
        }
      },
      {
        id: 'id4',
        slug: 'volkswagen-id4-pro',
        name: 'ID.4 Pro',
        type: '100% Eléctrico',
        price: '485€/mes',
        pvp: '52.400€',
        badge: 'SUV familiar',
        image: 'https://readdy.ai/api/search-image?query=Volkswagen%20ID4%20electric%20SUV%20in%20metallic%20gray%20color%20on%20clean%20white%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20modern%20crossover&width=480&height=320&seq=vw-id4-2&orientation=landscape&format=webp',
        specs: {
          autonomia: '521 km',
          potencia: '204 CV',
          bateria: '77 kWh',
          cargaRapida: '38 min (80%)',
          aceleracion: '8.5 s (0-100)',
          consumo: '16.3 kWh/100km'
        }
      },
      {
        id: 'id5',
        slug: 'volkswagen-id5-gtx',
        name: 'ID.5 GTX',
        type: '100% Eléctrico',
        price: '599€/mes',
        pvp: '64.900€',
        badge: 'Deportivo',
        image: 'https://readdy.ai/api/search-image?query=Volkswagen%20ID5%20GTX%20electric%20coupe%20SUV%20in%20dark%20blue%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20design&width=480&height=320&seq=vw-id5-1&orientation=landscape&format=webp',
        specs: {
          autonomia: '490 km',
          potencia: '299 CV',
          bateria: '77 kWh',
          cargaRapida: '36 min (80%)',
          aceleracion: '6.3 s (0-100)',
          consumo: '17.2 kWh/100km'
        }
      }
    ]
  },
  {
    id: 'audi',
    name: 'Audi',
    logo: 'https://readdy.ai/api/search-image?query=Audi%20logo%20four%20rings%20simple%20clean%20vector%20style%20on%20white%20background%20minimalist%20automotive%20brand%20identity&width=80&height=60&seq=audi-logo-1&orientation=landscape&format=webp',
    models: [
      {
        id: 'q4etron',
        slug: 'audi-q4-etron-45',
        name: 'Q4 e-tron 45',
        type: '100% Eléctrico',
        price: '549€/mes',
        pvp: '59.400€',
        badge: 'SUV versátil',
        image: 'https://readdy.ai/api/search-image?query=Audi%20Q4%20e-tron%20electric%20SUV%20in%20glacier%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20premium%20crossover&width=480&height=320&seq=audi-q4-1&orientation=landscape&format=webp',
        specs: {
          autonomia: '520 km',
          potencia: '286 CV',
          bateria: '82 kWh',
          cargaRapida: '38 min (80%)',
          aceleracion: '6.2 s (0-100)',
          consumo: '17.0 kWh/100km'
        }
      },
      {
        id: 'etrongt',
        slug: 'audi-etron-gt-quattro',
        name: 'e-tron GT quattro',
        type: '100% Eléctrico',
        price: '999€/mes',
        pvp: '107.900€',
        badge: 'Gran Turismo',
        image: 'https://readdy.ai/api/search-image?query=Audi%20e-tron%20GT%20electric%20sports%20car%20in%20daytona%20gray%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20luxury%20performance&width=480&height=320&seq=audi-etrongt-1&orientation=landscape&format=webp',
        specs: {
          autonomia: '488 km',
          potencia: '476 CV',
          bateria: '93.4 kWh',
          cargaRapida: '23 min (80%)',
          aceleracion: '4.1 s (0-100)',
          consumo: '19.6 kWh/100km'
        }
      },
      {
        id: 'q8etron',
        slug: 'audi-q8-etron-55',
        name: 'Q8 e-tron 55',
        type: '100% Eléctrico',
        price: '899€/mes',
        pvp: '97.100€',
        badge: 'Flagship SUV',
        image: 'https://readdy.ai/api/search-image?query=Audi%20Q8%20e-tron%20electric%20luxury%20SUV%20in%20mythos%20black%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20flagship%20crossover&width=480&height=320&seq=audi-q8-1&orientation=landscape&format=webp',
        specs: {
          autonomia: '582 km',
          potencia: '408 CV',
          bateria: '114 kWh',
          cargaRapida: '31 min (80%)',
          aceleracion: '5.6 s (0-100)',
          consumo: '20.6 kWh/100km'
        }
      }
    ]
  },
  {
    id: 'cupra',
    name: 'CUPRA',
    logo: 'https://readdy.ai/api/search-image?query=CUPRA%20logo%20simple%20clean%20vector%20style%20on%20white%20background%20minimalist%20automotive%20brand%20identity%20copper%20bronze%20color&width=80&height=60&seq=cupra-logo-1&orientation=landscape&format=webp',
    models: [
      {
        id: 'born',
        slug: 'cupra-born-eboost',
        name: 'Born e-Boost',
        type: '100% Eléctrico',
        price: '429€/mes',
        pvp: '46.400€',
        badge: 'Deportivo compacto',
        image: 'https://readdy.ai/api/search-image?query=CUPRA%20Born%20electric%20hatchback%20in%20copper%20bronze%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20compact%20car&width=480&height=320&seq=cupra-born-1&orientation=landscape&format=webp',
        specs: {
          autonomia: '548 km',
          potencia: '231 CV',
          bateria: '77 kWh',
          cargaRapida: '35 min (80%)',
          aceleracion: '6.6 s (0-100)',
          consumo: '15.4 kWh/100km'
        }
      },
      {
        id: 'tavascan',
        slug: 'cupra-tavascan-vz',
        name: 'Tavascan VZ',
        type: '100% Eléctrico',
        price: '649€/mes',
        pvp: '70.100€',
        badge: 'SUV Coupé',
        image: 'https://readdy.ai/api/search-image?query=CUPRA%20Tavascan%20electric%20coupe%20SUV%20in%20dark%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20crossover&width=480&height=320&seq=cupra-tavascan-1&orientation=landscape&format=webp',
        specs: {
          autonomia: '520 km',
          potencia: '340 CV',
          bateria: '77 kWh',
          cargaRapida: '35 min (80%)',
          aceleracion: '5.6 s (0-100)',
          consumo: '16.8 kWh/100km'
        }
      },
      {
        id: 'born-vz',
        slug: 'cupra-born-vz',
        name: 'Born VZ',
        type: '100% Eléctrico',
        price: '479€/mes',
        pvp: '51.800€',
        badge: 'Máxima potencia',
        image: 'https://readdy.ai/api/search-image?query=CUPRA%20Born%20VZ%20electric%20hot%20hatch%20in%20matte%20gray%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20performance%20compact&width=480&height=320&seq=cupra-born-vz-1&orientation=landscape&format=webp',
        specs: {
          autonomia: '511 km',
          potencia: '326 CV',
          bateria: '77 kWh',
          cargaRapida: '35 min (80%)',
          aceleracion: '5.6 s (0-100)',
          consumo: '16.2 kWh/100km'
        }
      }
    ]
  },
  {
    id: 'skoda',
    name: 'Skoda',
    logo: 'https://readdy.ai/api/search-image?query=Skoda%20logo%20simple%20clean%20vector%20style%20on%20white%20background%20minimalist%20automotive%20brand%20identity%20green%20arrow&width=80&height=60&seq=skoda-logo-1&orientation=landscape&format=webp',
    models: [
      {
        id: 'enyaq',
        slug: 'skoda-enyaq-iv-80',
        name: 'Enyaq iV 80',
        type: '100% Eléctrico',
        price: '499€/mes',
        pvp: '53.900€',
        badge: 'SUV espacioso',
        image: 'https://readdy.ai/api/search-image?query=Skoda%20Enyaq%20iV%20electric%20SUV%20in%20green%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20family%20crossover&width=480&height=320&seq=skoda-enyaq-1&orientation=landscape&format=webp',
        specs: {
          autonomia: '534 km',
          potencia: '204 CV',
          bateria: '82 kWh',
          cargaRapida: '36 min (80%)',
          aceleracion: '8.6 s (0-100)',
          consumo: '16.7 kWh/100km'
        }
      },
      {
        id: 'enyaq-coupe',
        slug: 'skoda-enyaq-coupe-rs',
        name: 'Enyaq Coupé RS',
        type: '100% Eléctrico',
        price: '649€/mes',
        pvp: '70.200€',
        badge: 'Deportivo',
        image: 'https://readdy.ai/api/search-image?query=Skoda%20Enyaq%20Coupe%20RS%20electric%20SUV%20coupe%20in%20black%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20design&width=480&height=320&seq=skoda-enyaq-coupe-1&orientation=landscape&format=webp',
        specs: {
          autonomia: '513 km',
          potencia: '340 CV',
          bateria: '82 kWh',
          cargaRapida: '36 min (80%)',
          aceleracion: '6.5 s (0-100)',
          consumo: '17.4 kWh/100km'
        }
      },
      {
        id: 'enyaq-60',
        slug: 'skoda-enyaq-iv-60',
        name: 'Enyaq iV 60',
        type: '100% Eléctrico',
        price: '429€/mes',
        pvp: '46.400€',
        badge: 'Mejor precio',
        image: 'https://readdy.ai/api/search-image?query=Skoda%20Enyaq%20iV%2060%20electric%20SUV%20in%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20affordable%20crossover&width=480&height=320&seq=skoda-enyaq-60-1&orientation=landscape&format=webp',
        specs: {
          autonomia: '417 km',
          potencia: '180 CV',
          bateria: '62 kWh',
          cargaRapida: '36 min (80%)',
          aceleracion: '9.0 s (0-100)',
          consumo: '15.9 kWh/100km'
        }
      }
    ]
  }
];

export default function BrandModelsSection() {
  const [activeBrand, setActiveBrand] = useState('volkswagen');
  const [expandedModel, setExpandedModel] = useState<string | null>(null);

  const currentBrand = brands.find(b => b.id === activeBrand);

  return (
    <section id="modelos" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="inline-block px-4 py-2 bg-[#ad023b]/10 text-[#ad023b] text-sm font-bold rounded-full mb-4">
            Catálogo completo
          </div>
          <h2 className="font-['Playfair_Display'] text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Modelos eléctricos por marca
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Explora nuestra gama completa de vehículos eléctricos. Selecciona una marca para ver todos los modelos disponibles con sus especificaciones técnicas.
          </p>
        </div>

        <div className="flex flex-wrap justify-center gap-4 mb-12">
          {brands.map((brand) => (
            <button
              key={brand.id}
              onClick={() => {
                setActiveBrand(brand.id);
                setExpandedModel(null);
              }}
              className={`px-6 py-3 rounded-xl font-bold text-sm transition-all cursor-pointer whitespace-nowrap ${
                activeBrand === brand.id
                  ? 'bg-[#ad023b] text-white shadow-lg'
                  : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
              }`}
            >
              {brand.name}
            </button>
          ))}
        </div>

        {currentBrand && (
          <div className="space-y-6">
            <div className="flex items-center gap-4 mb-8">
              <div className="h-px flex-1 bg-slate-200"></div>
              <h3 className="text-xl font-bold text-gray-900">{currentBrand.name}</h3>
              <div className="h-px flex-1 bg-slate-200"></div>
            </div>

            <div className="grid md:grid-cols-3 gap-6" data-product-shop>
              {currentBrand.models.map((model) => (
                <div
                  key={model.id}
                  className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-2xl transition-all duration-300 border border-gray-100 flex flex-col"
                >
                  <div className="relative">
                    <div className="w-full h-52 bg-slate-100">
                      <img
                        src={model.image}
                        alt={`${currentBrand.name} ${model.name}`}
                        className="w-full h-full object-cover object-top"
                        loading="lazy"
                        width={480}
                        height={320}
                      />
                    </div>
                    <div className="absolute top-3 right-3 bg-[#ad023b] text-white px-3 py-1.5 rounded-full text-xs font-bold shadow-lg">
                      {model.badge}
                    </div>
                    <div className="absolute top-3 left-3 bg-green-500 text-white px-3 py-1.5 rounded-full text-xs font-bold shadow-lg flex items-center gap-1">
                      <i className="ri-flashlight-line"></i>
                      {model.type}
                    </div>
                  </div>

                  <div className="p-5 flex flex-col flex-grow">
                    <div className="mb-4">
                      <div className="text-xs text-gray-500 mb-1 uppercase tracking-wide">
                        {currentBrand.name}
                      </div>
                      <h4 className="text-xl font-bold text-gray-900 mb-2">
                        {model.name}
                      </h4>
                    </div>

                    <div className="grid grid-cols-2 gap-3 mb-4">
                      <div className="bg-slate-50 rounded-lg p-3 text-center">
                        <div className="text-xs text-gray-500 mb-1">Autonomía</div>
                        <div className="font-bold text-gray-900">{model.specs.autonomia}</div>
                      </div>
                      <div className="bg-slate-50 rounded-lg p-3 text-center">
                        <div className="text-xs text-gray-500 mb-1">Potencia</div>
                        <div className="font-bold text-gray-900">{model.specs.potencia}</div>
                      </div>
                    </div>

                    <button
                      onClick={() => setExpandedModel(expandedModel === model.id ? null : model.id)}
                      className="text-sm text-[#ad023b] font-medium flex items-center gap-1 mb-4 cursor-pointer hover:underline"
                    >
                      {expandedModel === model.id ? 'Ocultar ficha técnica' : 'Ver ficha técnica completa'}
                      <i className={`ri-arrow-${expandedModel === model.id ? 'up' : 'down'}-s-line`}></i>
                    </button>

                    {expandedModel === model.id && (
                      <div className="bg-slate-50 rounded-lg p-4 mb-4 space-y-2 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-600">Batería</span>
                          <span className="font-medium text-gray-900">{model.specs.bateria}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Carga rápida</span>
                          <span className="font-medium text-gray-900">{model.specs.cargaRapida}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">0-100 km/h</span>
                          <span className="font-medium text-gray-900">{model.specs.aceleracion}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-600">Consumo</span>
                          <span className="font-medium text-gray-900">{model.specs.consumo}</span>
                        </div>
                      </div>
                    )}

                    <div className="flex items-end justify-between mb-5 mt-auto">
                      <div>
                        <div className="text-2xl font-bold text-gray-900">{model.price}</div>
                        <div className="text-xs text-gray-500">desde / 48 meses</div>
                      </div>
                      <div className="text-right">
                        <div className="text-sm font-medium text-gray-900">{model.pvp}</div>
                        <div className="text-xs text-gray-500">PVP</div>
                      </div>
                    </div>

                    <div className="flex gap-2">
                      <Link
                        href={`/vehiculos/electricos/${model.slug}`}
                        className="flex-1 bg-[#ad023b] text-white text-center py-3 rounded-lg text-sm font-bold hover:bg-[#8a0230] transition-colors cursor-pointer whitespace-nowrap"
                      >
                        Ver ficha completa
                      </Link>
                      <Link
                        href={`/vehiculos/electricos/${model.slug}#configurador`}
                        className="w-12 h-12 flex items-center justify-center bg-slate-100 text-slate-700 rounded-lg hover:bg-slate-200 transition-colors cursor-pointer"
                        title="Configurar cuota"
                      >
                        <i className="ri-settings-3-line text-xl"></i>
                      </Link>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="mt-12 bg-amber-50 border border-amber-200 rounded-lg p-6">
          <div className="flex items-start gap-4">
            <div className="w-6 h-6 flex items-center justify-center flex-shrink-0">
              <i className="ri-information-line text-xl text-amber-600"></i>
            </div>
            <div>
              <h4 className="font-bold text-slate-900 mb-2">Promociones sujetas a disponibilidad</h4>
              <p className="text-slate-700 text-sm leading-relaxed">
                Las cuotas mostradas son orientativas e incluyen IVA. Pueden variar según financiación, entrada y condiciones específicas. Plan MOVES sujeto a aprobación y disponibilidad de fondos. Consulta condiciones en tu concesionario Grupo Avisa.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
