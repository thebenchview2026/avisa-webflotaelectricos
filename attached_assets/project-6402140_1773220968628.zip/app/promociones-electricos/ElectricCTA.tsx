'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function ElectricCTA() {
  const router = useRouter();
  const [formData, setFormData] = useState({
    nombre: '',
    email: '',
    telefono: '',
    modelo: '',
    mensaje: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [acceptTerms, setAcceptTerms] = useState(false);
  const [acceptMarketing, setAcceptMarketing] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (formData.mensaje.length > 500 || !acceptTerms) {
      return;
    }

    setIsSubmitting(true);
    
    try {
      const formBody = new URLSearchParams();
      formBody.append('nombre', formData.nombre);
      formBody.append('email', formData.email);
      formBody.append('telefono', formData.telefono);
      formBody.append('modelo', formData.modelo);
      formBody.append('mensaje', formData.mensaje);
      formBody.append('acepta_terminos', acceptTerms ? 'Sí' : 'No');
      formBody.append('acepta_marketing', acceptMarketing ? 'Sí' : 'No');
      
      const response = await fetch('https://readdy.ai/api/form/d68ua4fmvg9ih2c79os0', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: formBody.toString()
      });

      if (response.ok) {
        const params = new URLSearchParams({
          nombre: formData.nombre,
          origen: 'electricos'
        });
        router.push(`/confirmacion-contacto?${params.toString()}`);
      }
    } catch (error) {
      console.error('Error al enviar el formulario:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  const models = [
    'Volkswagen ID.3',
    'Volkswagen ID.4',
    'Volkswagen ID.5',
    'Hyundai IONIQ 5',
    'Hyundai IONIQ 6',
    'Hyundai Kona Electric',
    'BMW iX1',
    'BMW i4',
    'BMW iX',
    'Mercedes EQA',
    'Mercedes EQB',
    'Mercedes EQE',
    'Audi Q4 e-tron',
    'Audi e-tron GT',
    'Audi Q8 e-tron'
  ];

  return (
    <section id="contacto" className="py-20 bg-gradient-to-br from-slate-900 to-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <div className="inline-block px-4 py-2 bg-[#ad023b] text-white text-sm font-bold rounded-full mb-6">
              Contacta con nosotros
            </div>
            <h2 className="font-['Playfair_Display'] text-3xl md:text-4xl font-bold text-white mb-6">
              ¿Listo para dar el salto a la movilidad eléctrica?
            </h2>
            <p className="text-lg text-white/80 mb-8 leading-relaxed">
              Nuestros asesores especializados te ayudarán a encontrar el vehículo eléctrico perfecto para ti. Sin compromiso, sin presión.
            </p>

            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 flex items-center justify-center bg-[#ad023b] text-white rounded-xl flex-shrink-0">
                  <i className="ri-file-list-3-line text-xl"></i>
                </div>
                <div>
                  <h3 className="font-bold text-white mb-1">Gestión Plan MOVES</h3>
                  <p className="text-white/70 text-sm">Nos encargamos de toda la tramitación de las ayudas para que tú solo disfrutes.</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 flex items-center justify-center bg-[#ad023b] text-white rounded-xl flex-shrink-0">
                  <i className="ri-bank-card-line text-xl"></i>
                </div>
                <div>
                  <h3 className="font-bold text-white mb-1">Financiación flexible</h3>
                  <p className="text-white/70 text-sm">Opciones de financiación adaptadas a tu situación con las mejores condiciones.</p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 flex items-center justify-center bg-[#ad023b] text-white rounded-xl flex-shrink-0">
                  <i className="ri-steering-2-line text-xl"></i>
                </div>
                <div>
                  <h3 className="font-bold text-white mb-1">Test drive gratuito</h3>
                  <p className="text-white/70 text-sm">Prueba el vehículo que te interesa sin ningún compromiso.</p>
                </div>
              </div>
            </div>

            <div className="mt-10 flex flex-wrap items-center gap-6">
              <a href="tel:955034600" className="flex items-center gap-2 text-white hover:text-white/80 transition-colors">
                <div className="w-10 h-10 flex items-center justify-center bg-white/10 rounded-full">
                  <i className="ri-phone-line text-lg"></i>
                </div>
                <span className="font-bold">955 034 600</span>
              </a>
              <a href="mailto:info@grupoavisa.com" className="flex items-center gap-2 text-white hover:text-white/80 transition-colors">
                <div className="w-10 h-10 flex items-center justify-center bg-white/10 rounded-full">
                  <i className="ri-mail-line text-lg"></i>
                </div>
                <span className="font-bold">info@grupoavisa.com</span>
              </a>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-8 shadow-2xl">
            {submitted ? (
              <div className="text-center py-12">
                <div className="w-20 h-20 flex items-center justify-center bg-green-100 text-green-600 rounded-full mx-auto mb-6">
                  <i className="ri-check-line text-4xl"></i>
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-2">¡Solicitud enviada!</h3>
                <p className="text-gray-600 mb-6">
                  Gracias por tu interés. Un asesor se pondrá en contacto contigo en las próximas 24 horas.
                </p>
                <button
                  onClick={() => {
                    setSubmitted(false);
                    setFormData({ nombre: '', email: '', telefono: '', modelo: '', mensaje: '' });
                  }}
                  className="text-[#ad023b] font-bold hover:underline cursor-pointer"
                >
                  Enviar otra solicitud
                </button>
              </div>
            ) : (
              <>
                <h3 className="text-xl font-bold text-gray-900 mb-4">Solicita información</h3>
                <div className="flex items-start gap-4 mb-6 p-4 bg-gray-50 rounded-xl">
                  <img 
                    src="https://static.readdy.ai/image/ecd9e0a88a19846633f9ef23a8543c57/7da821f8687606f5711af9936393378a.jpeg" 
                    alt="Ana - Asesora de Vehículos Eléctricos"
                    className="w-16 h-16 rounded-full object-cover border-2 border-[#ad023b]/20 flex-shrink-0"
                  />
                  <p className="text-sm text-gray-600 leading-relaxed">
                    La persona que te va a atender es <strong className="text-gray-900">Ana</strong>, lleva más de 10 años como profesional en Avisa y de forma rápida tendrás un asesoramiento directo de alta calidad.
                  </p>
                </div>
                <form id="form-electricos" data-readdy-form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Nombre completo *</label>
                    <input
                      type="text"
                      name="nombre"
                      required
                      value={formData.nombre}
                      onChange={(e) => setFormData({ ...formData, nombre: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#ad023b] focus:border-transparent outline-none transition-all text-sm"
                      placeholder="Tu nombre"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Email *</label>
                      <input
                        type="email"
                        name="email"
                        required
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#ad023b] focus:border-transparent outline-none transition-all text-sm"
                        placeholder="tu@email.com"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Teléfono *</label>
                      <input
                        type="tel"
                        name="telefono"
                        required
                        value={formData.telefono}
                        onChange={(e) => setFormData({ ...formData, telefono: e.target.value })}
                        className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#ad023b] focus:border-transparent outline-none transition-all text-sm"
                        placeholder="600 000 000"
                      />
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Modelo de interés</label>
                    <div className="relative">
                      <select
                        name="modelo"
                        value={formData.modelo}
                        onChange={(e) => setFormData({ ...formData, modelo: e.target.value })}
                        className="w-full px-4 py-3 pr-8 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#ad023b] focus:border-transparent outline-none transition-all text-sm appearance-none bg-white"
                      >
                        <option value="">Selecciona un modelo</option>
                        {models.map((model, index) => (
                          <option key={index} value={model}>{model}</option>
                        ))}
                      </select>
                      <div className="absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none">
                        <i className="ri-arrow-down-s-line text-gray-400"></i>
                      </div>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Mensaje</label>
                    <textarea
                      name="mensaje"
                      value={formData.mensaje}
                      onChange={(e) => setFormData({ ...formData, mensaje: e.target.value.slice(0, 500) })}
                      rows={3}
                      maxLength={500}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#ad023b] focus:border-transparent outline-none transition-all text-sm resize-none"
                      placeholder="Cuéntanos qué necesitas..."
                    />
                    <div className="text-xs text-gray-400 text-right mt-1">{formData.mensaje.length}/500</div>
                  </div>
                  
                  <div className="space-y-3">
                    <label className="flex items-start gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={acceptTerms}
                        onChange={(e) => setAcceptTerms(e.target.checked)}
                        className="mt-1 w-4 h-4 text-[#ad023b] border-gray-300 rounded focus:ring-[#ad023b] cursor-pointer"
                        required
                      />
                      <span className="text-sm text-gray-600">
                        He leído y acepto <a href="/terminos" className="text-[#ad023b] underline hover:text-[#8d0230]">los términos y condiciones de la política de privacidad</a>. *
                      </span>
                    </label>
                    
                    <label className="flex items-start gap-3 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={acceptMarketing}
                        onChange={(e) => setAcceptMarketing(e.target.checked)}
                        className="mt-1 w-4 h-4 text-[#ad023b] border-gray-300 rounded focus:ring-[#ad023b] cursor-pointer"
                      />
                      <span className="text-sm text-gray-600">
                        Doy mi consentimiento para el tratamiento de mis datos personales con fines de marketing y comerciales (Opcional)
                      </span>
                    </label>
                  </div>
                  
                  <button
                    type="submit"
                    disabled={isSubmitting || !acceptTerms}
                    className="w-full bg-[#ad023b] text-white py-4 rounded-lg font-bold hover:bg-[#8a0230] transition-colors cursor-pointer disabled:opacity-50 disabled:cursor-not-allowed whitespace-nowrap flex items-center justify-center gap-2"
                  >
                    {isSubmitting ? (
                      <>
                        <i className="ri-loader-4-line animate-spin"></i>
                        Enviando...
                      </>
                    ) : (
                      <>
                        <i className="ri-send-plane-line"></i>
                        Solicitar información
                      </>
                    )}
                  </button>
                </form>
              </>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
