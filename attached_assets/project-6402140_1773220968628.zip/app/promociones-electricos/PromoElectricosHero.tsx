
'use client';

export default function PromoElectricosHero() {
  return (
    <section className="relative min-h-[70vh] flex items-center overflow-hidden">
      <div className="absolute inset-0">
        <img
          src="https://readdy.ai/api/search-image?query=modern%20electric%20vehicle%20charging%20station%20at%20sunset%20with%20sleek%20electric%20car%20connected%20to%20charger%2C%20futuristic%20urban%20environment%20with%20clean%20energy%20infrastructure%2C%20professional%20automotive%20photography%20with%20dramatic%20lighting%20and%20reflections%2C%20premium%20luxury%20feel%20with%20blue%20and%20purple%20ambient%20lighting&width=1440&height=810&seq=promo-electricos-hero-1&orientation=landscape&format=webp"
          alt="Vehículos Eléctricos Grupo Avisa"
          className="w-full h-full object-cover object-center"
          loading="eager"
          fetchPriority="high"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/60 to-transparent"></div>
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="max-w-2xl">
          <div className="inline-block px-4 py-2 bg-[#ad023b] text-white text-sm font-bold rounded-full mb-6">
            Promociones Exclusivas
          </div>
          <h1 className="font-['Playfair_Display'] text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight">
            Vehículos 100% Eléctricos
          </h1>
          <p className="text-xl text-white/90 mb-8 leading-relaxed">
            Descubre nuestra gama completa de vehículos eléctricos con las mejores condiciones del mercado. Plan MOVES incluido y financiación a tu medida.
          </p>
          <div className="flex flex-wrap gap-4">
            <a
              href="#modelos"
              className="inline-flex items-center gap-2 bg-[#ad023b] text-white px-8 py-4 rounded-lg font-bold hover:bg-[#8a0230] transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-car-line text-xl"></i>
              Ver modelos
            </a>
            <a
              href="#contacto"
              className="inline-flex items-center gap-2 bg-white text-slate-900 px-8 py-4 rounded-lg font-bold hover:bg-slate-100 transition-colors cursor-pointer whitespace-nowrap"
            >
              <i className="ri-phone-line text-xl"></i>
              Solicitar información
            </a>
          </div>

          <div className="mt-12 grid grid-cols-3 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-white mb-1">7.000€</div>
              <div className="text-sm text-white/70">Ayudas Plan MOVES</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-white mb-1">0%</div>
              <div className="text-sm text-white/70">Emisiones CO₂</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-white mb-1">70%</div>
              <div className="text-sm text-white/70">Ahorro combustible</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
