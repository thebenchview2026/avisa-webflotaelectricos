
'use client';

export default function ElectricBenefits() {
  const benefits = [
    {
      icon: 'ri-leaf-line',
      title: 'Cero emisiones',
      description: 'Sin emisiones de CO₂ ni contaminantes. Contribuye activamente a la mejora de la calidad del aire.',
      color: 'bg-green-500'
    },
    {
      icon: 'ri-money-euro-circle-line',
      title: 'Ahorro económico',
      description: 'Hasta un 70% de ahorro en combustible y mantenimiento reducido sin cambios de aceite ni filtros.',
      color: 'bg-blue-500'
    },
    {
      icon: 'ri-shield-check-line',
      title: 'Etiqueta CERO',
      description: 'Acceso libre a zonas de bajas emisiones, descuentos en peajes y aparcamiento gratuito.',
      color: 'bg-purple-500'
    },
    {
      icon: 'ri-government-line',
      title: 'Ayudas y subvenciones',
      description: 'Plan MOVES III con hasta 7.000€ de ayuda directa. Grupo Avisa gestiona todo el proceso.',
      color: 'bg-[#ad023b]'
    },
    {
      icon: 'ri-volume-mute-line',
      title: 'Conducción silenciosa',
      description: 'Experiencia de conducción premium sin ruido de motor, solo el sonido del viento.',
      color: 'bg-indigo-500'
    },
    {
      icon: 'ri-speed-line',
      title: 'Rendimiento superior',
      description: 'Par instantáneo desde 0 rpm. Aceleración inmediata y respuesta excepcional.',
      color: 'bg-orange-500'
    }
  ];

  const comparisons = [
    { concept: 'Coste por 100 km', electric: '2-3€', combustion: '10-15€' },
    { concept: 'Mantenimiento anual', electric: '200-400€', combustion: '600-1.200€' },
    { concept: 'Emisiones CO₂', electric: '0 g/km', combustion: '120-180 g/km' },
    { concept: 'Impuesto circulación', electric: '75% descuento', combustion: '100%' },
    { concept: 'Acceso ZBE', electric: 'Sin restricciones', combustion: 'Limitado' }
  ];

  return (
    <section className="py-20 bg-gradient-to-br from-slate-50 to-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-block px-4 py-2 bg-green-100 text-green-700 text-sm font-bold rounded-full mb-4">
            Ventajas exclusivas
          </div>
          <h2 className="font-['Playfair_Display'] text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            ¿Por qué elegir un eléctrico?
          </h2>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Los vehículos eléctricos ofrecen ventajas económicas, medioambientales y de conducción que los convierten en la mejor opción para el presente y el futuro.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {benefits.map((benefit, index) => (
            <div key={index} className="bg-white rounded-xl p-6 shadow-sm hover:shadow-lg transition-all duration-300 border border-gray-100">
              <div className={`w-12 h-12 flex items-center justify-center ${benefit.color} text-white rounded-xl mb-4`}>
                <i className={`${benefit.icon} text-2xl`}></i>
              </div>
              <h3 className="text-lg font-bold text-gray-900 mb-2">{benefit.title}</h3>
              <p className="text-gray-600 text-sm leading-relaxed">{benefit.description}</p>
            </div>
          ))}
        </div>

        <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
          <div className="bg-slate-900 px-8 py-6">
            <h3 className="text-xl font-bold text-white text-center">
              Comparativa: Eléctrico vs Combustión
            </h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="bg-slate-50">
                  <th className="px-6 py-4 text-left text-sm font-bold text-gray-900">Concepto</th>
                  <th className="px-6 py-4 text-center text-sm font-bold text-green-600">
                    <div className="flex items-center justify-center gap-2">
                      <i className="ri-flashlight-line"></i>
                      Eléctrico
                    </div>
                  </th>
                  <th className="px-6 py-4 text-center text-sm font-bold text-gray-500">
                    <div className="flex items-center justify-center gap-2">
                      <i className="ri-gas-station-line"></i>
                      Combustión
                    </div>
                  </th>
                </tr>
              </thead>
              <tbody>
                {comparisons.map((row, index) => (
                  <tr key={index} className={index % 2 === 0 ? 'bg-white' : 'bg-slate-50'}>
                    <td className="px-6 py-4 text-sm font-medium text-gray-900">{row.concept}</td>
                    <td className="px-6 py-4 text-center text-sm font-bold text-green-600">{row.electric}</td>
                    <td className="px-6 py-4 text-center text-sm text-gray-500">{row.combustion}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div className="bg-green-50 px-8 py-4 border-t border-green-100">
            <p className="text-sm text-green-700 text-center">
              <i className="ri-information-line mr-2"></i>
              Ahorro estimado de más de 1.500€ anuales con un vehículo eléctrico
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
