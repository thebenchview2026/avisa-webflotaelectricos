
import dynamic from 'next/dynamic';
import PromoElectricosHero from './PromoElectricosHero';
import ElectricTechnology from './ElectricTechnology';

const ElectricBenefits = dynamic(() => import('./ElectricBenefits'), {
  loading: () => <div className="h-96 bg-gray-50 animate-pulse" />
});

const BrandModelsSection = dynamic(() => import('./BrandModelsSection'), {
  loading: () => <div className="h-96 bg-gray-50 animate-pulse" />
});

const ElectricCTA = dynamic(() => import('./ElectricCTA'), {
  loading: () => <div className="h-48 bg-gray-50 animate-pulse" />
});

export const metadata = {
  title: 'Promociones Vehículos Eléctricos | Grupo Avisa - Concesionario Oficial',
  description: 'Descubre las mejores ofertas en coches eléctricos. Tesla, Volkswagen, Hyundai, BMW y más. Plan MOVES incluido, financiación flexible y hasta 7.000€ en ayudas.',
  keywords: 'coches eléctricos, promociones eléctricos, Tesla, Volkswagen ID, Hyundai IONIQ, BMW iX, Plan MOVES, Grupo Avisa',
};

export default function PromocionesElectricosPage() {
  return (
    <main className="pt-[120px]">
      <PromoElectricosHero />
      <ElectricTechnology />
      <ElectricBenefits />
      <BrandModelsSection />
      <ElectricCTA />
    </main>
  );
}
