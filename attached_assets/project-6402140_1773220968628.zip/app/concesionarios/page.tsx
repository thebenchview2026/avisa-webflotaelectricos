
import dynamic from 'next/dynamic';
import ContactHero from './ContactHero';
import ContactForm from './ContactForm';

const DealerLocations = dynamic(() => import('./DealerLocations'), {
  loading: () => <div className="h-96 bg-gray-50 animate-pulse" />
});

const ContactFAQ = dynamic(() => import('./ContactFAQ'), {
  loading: () => <div className="h-96 bg-gray-50 animate-pulse" />
});

const RelatedLinks = dynamic(() => import('./RelatedLinks'), {
  loading: () => <div className="h-48 bg-gray-50 animate-pulse" />
});

export default function ConcesionariosPage() {
  return (
    <div className="min-h-screen bg-white pt-[120px]">
      <nav className="bg-slate-50 border-b border-slate-200" aria-label="Breadcrumb">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
          <ol className="flex items-center space-x-2 text-sm">
            <li>
              <a className="text-slate-600 hover:text-slate-900 transition-colors cursor-pointer" href="/">Inicio</a>
            </li>
            <li className="flex items-center space-x-2">
              <span className="text-slate-400">/</span>
              <span className="text-slate-900 font-medium">Contacto</span>
            </li>
          </ol>
        </div>
      </nav>
      
      <ContactHero />
      <ContactForm />
      <DealerLocations />
      <ContactFAQ />
      <RelatedLinks />
    </div>
  );
}
