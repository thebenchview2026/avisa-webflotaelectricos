
'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function ContactForm() {
  const router = useRouter();
  const [formData, setFormData] = useState({
    nombre: '',
    email: '',
    telefono: '',
    tipoVehiculo: '',
    presupuesto: '',
    mensaje: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [charCount, setCharCount] = useState(0);
  const [acceptTerms, setAcceptTerms] = useState(false);
  const [acceptMarketing, setAcceptMarketing] = useState(false);
  const maxChars = 500;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    
    if (name === 'mensaje') {
      if (value.length <= maxChars) {
        setFormData(prev => ({ ...prev, [name]: value }));
        setCharCount(value.length);
      }
    } else {
      setFormData(prev => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (charCount > maxChars || !acceptTerms) {
      return;
    }
    
    setIsSubmitting(true);
    setSubmitStatus('idle');

    try {
      const formBody = new URLSearchParams();
      Object.entries(formData).forEach(([key, value]) => {
        formBody.append(key, value);
      });
      formBody.append('acepta_terminos', acceptTerms ? 'Sí' : 'No');
      formBody.append('acepta_marketing', acceptMarketing ? 'Sí' : 'No');

      const response = await fetch('https://readdy.ai/api/public/form/submit/concesionarios-contacto', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: formBody.toString()
      });

      if (response.ok) {
        const params = new URLSearchParams({
          nombre: formData.nombre,
          origen: 'concesionarios'
        });
        router.push(`/confirmacion-contacto?${params.toString()}`);
      } else {
        setSubmitStatus('error');
      }
    } catch (error) {
      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-6">
        <div className="bg-slate-50 p-8 rounded-2xl border border-slate-200">
          <h2 className="text-3xl font-bold text-slate-900 mb-2">
            Solicita información sobre vehículos eléctricos e híbridos
          </h2>
          <p className="text-slate-600 mb-8">
            Rellena el formulario y un asesor especializado te contactará en menos de 24 horas laborables.
          </p>

          <div className="flex items-start gap-4 mb-8 p-4 bg-teal-50 rounded-xl border border-teal-100">
            <img 
              src="https://static.readdy.ai/image/ecd9e0a88a19846633f9ef23a8543c57/7da821f8687606f5711af9936393378a.jpeg" 
              alt="Ana - Asesora de vehículos eléctricos"
              className="w-16 h-16 rounded-full object-cover flex-shrink-0"
            />
            <div>
              <p className="text-sm text-slate-700 leading-relaxed">
                <span className="font-semibold text-slate-900">La persona que te va a atender es Ana</span>, lleva más de 10 años como profesional de flotas en Avisa y de forma rápida tendrás un asesoramiento directo de alta calidad.
              </p>
            </div>
          </div>

          <form id="concesionarios-contacto" data-readdy-form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="nombre" className="block text-sm font-medium text-slate-700 mb-2">
                  Nombre completo *
                </label>
                <input
                  type="text"
                  id="nombre"
                  name="nombre"
                  value={formData.nombre}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm"
                  placeholder="Tu nombre"
                />
              </div>

              <div>
                <label htmlFor="email" className="block text-sm font-medium text-slate-700 mb-2">
                  Email *
                </label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm"
                  placeholder="tu@email.com"
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div>
                <label htmlFor="telefono" className="block text-sm font-medium text-slate-700 mb-2">
                  Teléfono
                </label>
                <input
                  type="tel"
                  id="telefono"
                  name="telefono"
                  value={formData.telefono}
                  onChange={handleChange}
                  className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm"
                  placeholder="Opcional"
                />
              </div>

              <div>
                <label htmlFor="tipoVehiculo" className="block text-sm font-medium text-slate-700 mb-2">
                  Tipo de vehículo que te interesa
                </label>
                <select
                  id="tipoVehiculo"
                  name="tipoVehiculo"
                  value={formData.tipoVehiculo}
                  onChange={handleChange}
                  className="w-full px-4 py-3 pr-8 border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm cursor-pointer"
                >
                  <option value="">Selecciona una opción</option>
                  <option value="electrico">100% Eléctrico</option>
                  <option value="hibrido-enchufable">Híbrido Enchufable (PHEV)</option>
                  <option value="hibrido">Híbrido (HEV)</option>
                  <option value="no-seguro">Aún no lo tengo claro</option>
                </select>
              </div>
            </div>

            <div>
              <label htmlFor="presupuesto" className="block text-sm font-medium text-slate-700 mb-2">
                Presupuesto aproximado
              </label>
              <select
                id="presupuesto"
                name="presupuesto"
                value={formData.presupuesto}
                onChange={handleChange}
                className="w-full px-4 py-3 pr-8 border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm cursor-pointer"
              >
                <option value="">Selecciona una opción</option>
                <option value="hasta-25000">Hasta 25.000€</option>
                <option value="25000-35000">25.000€ - 35.000€</option>
                <option value="35000-50000">35.000€ - 50.000€</option>
                <option value="mas-50000">Más de 50.000€</option>
                <option value="financiacion">Prefiero opciones de financiación</option>
              </select>
            </div>

            <div>
              <label htmlFor="mensaje" className="block text-sm font-medium text-slate-700 mb-2">
                ¿Qué necesitas saber? *
              </label>
              <textarea
                id="mensaje"
                name="mensaje"
                value={formData.mensaje}
                onChange={handleChange}
                required
                rows={5}
                maxLength={maxChars}
                className="w-full px-4 py-3 border border-slate-300 rounded-lg focus:ring-2 focus:ring-teal-500 focus:border-transparent text-sm resize-none"
                placeholder="Cuéntanos qué modelo te interesa, dudas sobre autonomía, puntos de carga, ayudas disponibles..."
              />
              <div className="flex justify-between items-center mt-2">
                <p className="text-xs text-slate-500">
                  {charCount}/{maxChars} caracteres
                </p>
                {charCount > maxChars && (
                  <p className="text-xs text-red-600 font-medium">
                    Has superado el límite de caracteres
                  </p>
                )}
              </div>
            </div>

            {submitStatus === 'success' && (
              <div className="p-4 bg-teal-50 border border-teal-200 rounded-lg">
                <p className="text-teal-800 text-sm">
                  ¡Gracias por tu interés! Un asesor especializado te contactará pronto.
                </p>
              </div>
            )}

            {submitStatus === 'error' && (
              <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-red-800 text-sm">
                  Hubo un error al enviar el formulario. Por favor, inténtalo de nuevo.
                </p>
              </div>
            )}

            <div className="space-y-3">
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={acceptTerms}
                  onChange={(e) => setAcceptTerms(e.target.checked)}
                  className="mt-1 w-4 h-4 text-teal-600 border-slate-300 rounded focus:ring-teal-500 cursor-pointer"
                  required
                />
                <span className="text-sm text-slate-600">
                  He leído y acepto <a href="/terminos" className="text-teal-600 underline hover:text-teal-700">los términos y condiciones de la política de privacidad</a>.
                </span>
              </label>
              
              <label className="flex items-start gap-3 cursor-pointer">
                <input
                  type="checkbox"
                  checked={acceptMarketing}
                  onChange={(e) => setAcceptMarketing(e.target.checked)}
                  className="mt-1 w-4 h-4 text-teal-600 border-slate-300 rounded focus:ring-teal-500 cursor-pointer"
                />
                <span className="text-sm text-slate-600">
                  Doy mi consentimiento para el tratamiento de mis datos personales con fines de marketing y comerciales (Opcional)
                </span>
              </label>
            </div>

            <button
              type="submit"
              disabled={isSubmitting || charCount > maxChars || !acceptTerms}
              className="w-full bg-teal-600 text-white py-4 rounded-lg font-semibold hover:bg-teal-700 transition-colors disabled:bg-slate-300 disabled:cursor-not-allowed whitespace-nowrap cursor-pointer"
            >
              {isSubmitting ? 'Enviando...' : 'Solicitar información'}
            </button>
          </form>

          <div className="mt-8 pt-8 border-t border-slate-200">
            <h3 className="font-semibold text-slate-900 mb-4">O contáctanos directamente:</h3>
            <div className="space-y-3">
              <a href="tel:+34955034600" className="flex items-center gap-3 text-slate-700 hover:text-teal-600 transition-colors cursor-pointer">
                <i className="ri-phone-line text-xl w-5 h-5 flex items-center justify-center"></i>
                <span>955 034 600</span>
              </a>
              <a href="mailto:info@grupoavisa.com" className="flex items-center gap-3 text-slate-700 hover:text-teal-600 transition-colors cursor-pointer">
                <i className="ri-mail-line text-xl w-5 h-5 flex items-center justify-center"></i>
                <span>info@grupoavisa.com</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
