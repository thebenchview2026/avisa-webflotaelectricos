'use client';

import { useState } from 'react';

const dealers = [
  {
    name: 'Avisa Volkswagen Sevilla',
    address: 'C/ Alhami, 2-4, 41020 Sevilla',
    phone: '955 03 46 00',
    phoneLink: '+34955034600',
    logo: 'https://cdn.dealerk.es/cars/make/brand/48/white/volkswagen.png',
    lat: 37.4019,
    lng: -5.9426
  },
  {
    name: 'Avisa Audi Sevilla',
    address: 'Av. Averroes, 12, 41020 Sevilla',
    phone: '955 03 46 04',
    phoneLink: '+34955034604',
    logo: 'https://cdn.dealerk.es/cars/make/brand/48/white/audi.png',
    lat: 37.4025,
    lng: -5.9398
  },
  {
    name: 'Cartuja Motor Sevilla',
    address: 'Pol. Ind. Su Eminencia, C/ D, 1-2, 41006 Sevilla',
    phone: '954 32 21 21',
    phoneLink: '+34954322121',
    logo: 'https://cdn.dealerk.es/cars/make/brand/48/white/skoda.png',
    lat: 37.3650,
    lng: -5.9650
  },
  {
    name: 'Cartuja Motor Dos Hermanas',
    address: 'Pol. Ind. La Isla, C/ Astronomía, 1, 41703 Dos Hermanas, Sevilla',
    phone: '955 03 46 00',
    phoneLink: '+34955034600',
    logo: 'https://cdn.dealerk.es/cars/make/brand/48/white/skoda.png',
    lat: 37.2850,
    lng: -5.9250
  },
  {
    name: 'Cartuja Motor Huelva',
    address: 'Pol. Ind. La Paz, Av. de las Veredas, 18, 21007 Huelva',
    phone: '959 81 10 45',
    phoneLink: '+34959811045',
    logo: 'https://cdn.dealerk.es/cars/make/brand/48/white/skoda.png',
    lat: 37.2614,
    lng: -6.9447
  },
  {
    name: 'Avisa Škoda Badajoz',
    address: 'Ctra. Madrid-Lisboa, Km. 409, 06008 Badajoz',
    phone: '924 29 11 00',
    phoneLink: '+34924291100',
    logo: 'https://cdn.dealerk.es/cars/make/brand/48/white/skoda.png',
    lat: 38.8794,
    lng: -6.9706
  },
  {
    name: 'Avisa Škoda Cáceres',
    address: 'Pol. Ind. Las Capellanías, C/ Hojalateros, 121 Oeste, 10005 Cáceres',
    phone: '927 23 48 88',
    phoneLink: '+34927234888',
    logo: 'https://cdn.dealerk.es/cars/make/brand/48/white/skoda.png',
    lat: 39.4697,
    lng: -6.3724
  },
  {
    name: 'Avisa Škoda Fuente de Cantos',
    address: 'C/ Real, 48, 06240 Fuente de Cantos, Badajoz',
    phone: '924 50 00 69',
    phoneLink: '+34924500069',
    logo: 'https://cdn.dealerk.es/cars/make/brand/48/white/skoda.png',
    lat: 38.2419,
    lng: -6.3058
  },
  {
    name: 'Avisa Škoda Córdoba',
    address: 'C/ Esteban de Cabrera, 90, 14014 Córdoba',
    phone: '957 42 17 00',
    phoneLink: '+34957421700',
    logo: 'https://cdn.dealerk.es/cars/make/brand/48/white/skoda.png',
    lat: 37.8882,
    lng: -4.7794
  }
];

export default function DealerLocations() {
  const [selectedDealer, setSelectedDealer] = useState<number | null>(null);
  
  const mapUrl = `https://www.google.com/maps/embed/v1/view?key=AIzaSyBFw0Qbyq9zTFTd-tUY6dZWTgaQzuU17R8&center=38.0,-5.5&zoom=7&maptype=roadmap`;

  return (
    <section className="py-20 bg-slate-50">
      <div className="max-w-7xl mx-auto px-6">
        <h2 className="text-3xl font-bold text-slate-900 mb-4 text-center">Nuestras Ubicaciones</h2>
        <p className="text-slate-600 text-center mb-8 max-w-2xl mx-auto">
          Grupo Avisa cuenta con concesionarios en Sevilla, Huelva, Badajoz, Cáceres y Córdoba. Encuentra el más cercano a ti.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {dealers.map((dealer, index) => (
            <div 
              key={index} 
              className={`bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-shadow cursor-pointer ${selectedDealer === index ? 'ring-2 ring-teal-500' : ''}`}
              onClick={() => setSelectedDealer(index)}
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 bg-slate-900 rounded-lg flex items-center justify-center p-2">
                  <img alt={`${dealer.name} logo`} className="w-full h-full object-contain" src={dealer.logo} />
                </div>
                <h3 className="font-bold text-slate-900">{dealer.name}</h3>
              </div>
              <p className="text-slate-600 text-sm mb-3">
                <i className="ri-map-pin-line text-teal-600 mr-2"></i>
                {dealer.address}
              </p>
              <p className="text-slate-600 text-sm mb-3">
                <i className="ri-phone-line text-teal-600 mr-2"></i>
                <a href={`tel:${dealer.phoneLink}`} className="hover:text-teal-600">{dealer.phone}</a>
              </p>
              <a 
                href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(dealer.address)}`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center text-teal-600 hover:text-teal-700 text-sm font-medium mt-2 cursor-pointer"
              >
                Ver en mapa <i className="ri-arrow-right-line ml-1"></i>
              </a>
            </div>
          ))}
        </div>

        <div className="mt-12 rounded-2xl overflow-hidden shadow-lg border border-slate-200">
          <iframe
            src={mapUrl}
            width="100%"
            height="400"
            style={{ border: 0 }}
            allowFullScreen
            loading="lazy"
            referrerPolicy="no-referrer-when-downgrade"
            title="Mapa de concesionarios Grupo Avisa"
          ></iframe>
          <div className="bg-white p-4 border-t border-slate-200">
            <div className="flex flex-wrap gap-6 justify-center text-sm">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 bg-slate-900 rounded-full flex items-center justify-center flex-shrink-0">
                  <i className="ri-map-pin-fill text-white text-xs"></i>
                </div>
                <span className="text-slate-600">9 concesionarios en Andalucía y Extremadura</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
