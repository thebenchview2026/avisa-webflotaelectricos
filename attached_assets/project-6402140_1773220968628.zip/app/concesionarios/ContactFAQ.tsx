export default function ContactFAQ() {
  const faqs = [
    {
      question: '¿Cuánto tarda la respuesta?',
      answer: 'Respondemos en menos de 24 horas laborables. Si tu consulta requiere análisis detallado, te lo indicaremos y acordaremos una llamada.'
    },
    {
      question: '¿Tiene coste la consulta inicial?',
      answer: 'No. La primera conversación es gratuita y sin compromiso. Solo queremos entender tus necesidades y ayudarte a elegir el vehículo eléctrico o híbrido adecuado.'
    },
    {
      question: '¿Me ayudáis con las ayudas del Plan MOVES?',
      answer: 'Sí. Te asesoramos sobre todas las ayudas disponibles (Plan MOVES III, ayudas autonómicas, etc.) y nos encargamos de toda la tramitación sin coste adicional. Además, adelantamos el importe de la ayuda.'
    },
    {
      question: '¿Puedo probar un vehículo antes de decidirme?',
      answer: 'Por supuesto. Ofrecemos pruebas de conducción de vehículos eléctricos e híbridos en todos nuestros concesionarios para que puedas experimentar la diferencia antes de tomar una decisión.'
    },
    {
      question: '¿Qué diferencia hay entre un híbrido y un híbrido enchufable?',
      answer: 'Los híbridos enchufables (PHEV) tienen baterías más grandes que se cargan en la red eléctrica y pueden circular en modo 100% eléctrico hasta 50-80 km. Los híbridos convencionales solo se cargan con el motor y la frenada regenerativa. Los PHEV tienen acceso a las ayudas del Plan MOVES.'
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-4xl mx-auto px-6">
        <h2 className="text-3xl font-bold text-slate-900 mb-12 text-center">
          Preguntas frecuentes
        </h2>
        <div className="space-y-6">
          {faqs.map((faq, index) => (
            <div key={index} className="bg-white p-6 rounded-xl border border-slate-200">
              <h3 className="font-semibold text-slate-900 mb-2">{faq.question}</h3>
              <p className="text-slate-600 text-sm leading-relaxed">{faq.answer}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}