
import Link from 'next/link';

export default function RelatedLinks() {
  const links = [
    {
      title: 'Promociones Eléctricos',
      description: 'Descubre las mejores ofertas en vehículos 100% eléctricos',
      href: '/promociones-electricos'
    },
    {
      title: 'Promociones Híbridos',
      description: 'Ofertas especiales en vehículos híbridos y PHEV',
      href: '/promociones-hibridos'
    },
    {
      title: '¿Cuándo electrificar?',
      description: '¿Tiene sentido para ti un vehículo eléctrico?',
      href: '/electrificacion'
    },
    {
      title: 'Plan MOVES III',
      description: 'Ayudas y subvenciones para tu vehículo eléctrico',
      href: '/plan-moves'
    }
  ];

  return (
    <section className="py-20 bg-slate-50">
      <div className="max-w-4xl mx-auto px-6">
        <h2 className="text-2xl font-bold text-slate-900 mb-8">
          Antes de contactar, quizás te interese:
        </h2>
        <div className="grid md:grid-cols-2 gap-4">
          {links.map((link, index) => (
            <Link
              key={index}
              href={link.href}
              className="p-6 border border-slate-200 rounded-xl hover:border-teal-500 hover:shadow-md transition-all group bg-white cursor-pointer"
            >
              <h3 className="font-semibold text-slate-900 mb-2 group-hover:text-teal-600 transition-colors">
                {link.title}
              </h3>
              <p className="text-sm text-slate-600 leading-relaxed">{link.description}</p>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
