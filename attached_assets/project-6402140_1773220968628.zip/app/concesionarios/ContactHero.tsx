
export default function ContactHero() {
  return (
    <section className="relative bg-gradient-to-br from-slate-50 to-white pt-20 pb-16">
      <div className="max-w-7xl mx-auto px-6">
        <div className="max-w-3xl">
          <h1 className="text-5xl font-bold text-slate-900 mb-6 leading-tight">
            Tu próximo vehículo eléctrico o híbrido
          </h1>
          <p className="text-xl text-slate-600 leading-relaxed">
            Sin compromiso. Sin presión comercial. Solo una conversación honesta sobre qué vehículo se adapta mejor a tus necesidades.
          </p>
        </div>
      </div>
    </section>
  );
}
