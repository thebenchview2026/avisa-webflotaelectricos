
'use client';

export default function CuandoNoElectrificar() {
  const razones = [
    {
      icon: 'ri-road-map-line',
      title: 'Recorridos largos e impredecibles',
      description: 'Si tus vehículos hacen más de 300 km diarios en rutas variables, la autonomía se convierte en un problema operativo real. Los eléctricos actuales no están diseñados para uso intensivo en carretera sin planificación de carga.'
    },
    {
      icon: 'ri-plug-line',
      title: 'Sin infraestructura de carga',
      description: 'Si no tienes parking propio ni acceso garantizado a carga, dependerás de electrolineras públicas. Esto multiplica el tiempo de inactividad y genera conflictos con conductores que pierden tiempo personal cargando.'
    },
    {
      icon: 'ri-money-euro-circle-line',
      title: 'Presupuesto ajustado sin margen',
      description: 'El precio de compra de un eléctrico es entre un 20% y 40% superior al de un térmico equivalente. Si no puedes asumir ese sobrecoste inicial o no tienes acceso a ayudas, el TCO puede no compensar en 4 años.'
    },
    {
      icon: 'ri-time-line',
      title: 'Necesidad de renovación inmediata',
      description: 'Si necesitas vehículos en menos de 3 meses, los plazos de entrega de eléctricos pueden ser un problema. Algunos modelos tienen listas de espera de 6 a 12 meses. Electrificar bajo presión aumenta el riesgo de mala elección.'
    }
  ];

  return (
    <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 bg-gray-50">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-3xl font-bold text-gray-900 mb-8">Cuándo NO tiene sentido electrificar (todavía)</h2>
        <div className="space-y-6">
          {razones.map((razon, index) => (
            <div key={index} className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
              <h3 className="text-xl font-bold text-gray-900 mb-3 flex items-center gap-3">
                <span className="w-10 h-10 flex items-center justify-center">
                  <i className={`${razon.icon} text-[#14B8A6] text-2xl`}></i>
                </span>
                {razon.title}
              </h3>
              <p className="text-gray-700 leading-relaxed">{razon.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
