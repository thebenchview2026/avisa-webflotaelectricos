
'use client';

export default function ElectrificacionHero() {
  return (
    <section className="bg-gradient-to-br from-gray-50 to-white pt-16 pb-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <h1 className="text-4xl md:text-5xl font-bold text-gray-900 leading-tight mb-6">
          ¿Cuándo tiene sentido pasarse al coche eléctrico?
        </h1>
        <div className="w-24 h-1 bg-[#14B8A6] rounded-full mb-8"></div>
        <div className="bg-white border-l-4 border-[#14B8A6] p-6 rounded-r-lg shadow-sm mb-12">
          <p className="text-xl text-gray-800 leading-relaxed">
            Depende de tu perfil de uso, infraestructura disponible y capacidad de gestionar el cambio. No existe un momento universal. En la mayoría de casos, tiene sentido cuando los recorridos son predecibles, la carga puede planificarse y estás preparado para el cambio. Electrificar sin analizar estos factores aumenta el riesgo de frustraciones y costes ocultos.
          </p>
        </div>

        <div className="bg-gray-50 rounded-lg p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Por qué esta pregunta es clave para ti</h2>
          <p className="text-gray-700 leading-relaxed mb-4">
            Pasarse al eléctrico no es solo cambiar de motor. Es modificar hábitos, adaptar infraestructura y gestionar expectativas. El 60% de los conductores que electrifican sin planificación enfrentan frustraciones en los primeros 6 meses.
          </p>
          <p className="text-gray-700 leading-relaxed">
            La presión regulatoria y las ayudas públicas empujan hacia la electrificación, pero el timing importa. Electrificar demasiado pronto puede generar costes innecesarios. Hacerlo tarde puede dejarte sin opciones cuando las normativas se endurezcan. Esta decisión requiere análisis, no urgencia.
          </p>
        </div>
      </div>
    </section>
  );
}
