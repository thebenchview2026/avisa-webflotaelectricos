
import ElectrificacionHero from './ElectrificacionHero';
import CuandoSiElectrificar from './CuandoSiElectrificar';
import CuandoNoElectrificar from './CuandoNoElectrificar';
import ErroresHabituales from './ErroresHabituales';
import FactoresDecision from './FactoresDecision';
import DependeTuCaso from './DependeTuCaso';
import ElectrificacionCTA from './ElectrificacionCTA';

export const metadata = {
  title: '¿Cuándo pasarse al coche eléctrico? | Grupo Avisa',
  description: 'Descubre cuándo tiene sentido pasarse al coche eléctrico. Análisis de factores clave, errores habituales y guía para tomar la mejor decisión.',
  keywords: 'coche eléctrico, cuándo electrificar, vehículo eléctrico, TCO eléctricos, comprar coche eléctrico',
};

export default function ElectrificacionPage() {
  return (
    <main className="pt-[120px]">
      <ElectrificacionHero />
      <CuandoSiElectrificar />
      <CuandoNoElectrificar />
      <ErroresHabituales />
      <FactoresDecision />
      <DependeTuCaso />
      <ElectrificacionCTA />
    </main>
  );
}
