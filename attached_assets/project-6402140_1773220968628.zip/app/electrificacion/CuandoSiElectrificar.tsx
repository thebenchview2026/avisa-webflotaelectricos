
'use client';

export default function CuandoSiElectrificar() {
  const razones = [
    {
      icon: 'ri-map-pin-line',
      title: 'Recorridos predecibles y urbanos',
      description: 'Si tus vehículos hacen menos de 200 km diarios en rutas conocidas, la autonomía deja de ser un problema. Los eléctricos funcionan mejor en ciudad que en carretera, y la regeneración en tráfico denso reduce el consumo real.'
    },
    {
      icon: 'ri-charging-pile-2-line',
      title: 'Infraestructura de carga disponible',
      description: 'Si tienes parking propio o acceso garantizado a carga nocturna, el 80% del problema operativo desaparece. La carga en destino es más eficiente y económica que depender de electrolineras públicas.'
    },
    {
      icon: 'ri-team-line',
      title: 'Equipo preparado para el cambio',
      description: 'Si tus conductores están abiertos al cambio o ya tienen experiencia con eléctricos, la curva de adaptación es más corta. La resistencia interna es el factor más subestimado en la electrificación.'
    },
    {
      icon: 'ri-file-list-3-line',
      title: 'Presión regulatoria o de clientes',
      description: 'Si operas en Zonas de Bajas Emisiones o tus clientes exigen vehículos sostenibles, electrificar deja de ser opcional. En estos casos, el coste de no hacerlo supera el coste de adaptación.'
    }
  ];

  return (
    <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h2 className="text-3xl font-bold text-gray-900 mb-8">Cuándo SÍ tiene sentido electrificar</h2>
      <div className="space-y-6">
        {razones.map((razon, index) => (
          <div key={index} className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
            <h3 className="text-xl font-bold text-gray-900 mb-3 flex items-center gap-3">
              <span className="w-10 h-10 flex items-center justify-center">
                <i className={`${razon.icon} text-[#14B8A6] text-2xl`}></i>
              </span>
              {razon.title}
            </h3>
            <p className="text-gray-700 leading-relaxed ml-13">{razon.description}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
