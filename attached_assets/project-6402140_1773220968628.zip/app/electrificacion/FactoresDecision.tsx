
'use client';

export default function FactoresDecision() {
  const factores = [
    {
      title: 'Ayudas públicas disponibles',
      description: 'Las ayudas MOVES pueden cubrir hasta 7.000€ por vehículo, pero los plazos de cobro superan los 12 meses. Si no puedes anticipar ese coste, la ayuda pierde parte de su valor.'
    },
    {
      title: 'Precio de la electricidad',
      description: 'Si tienes tarifa nocturna o acceso a carga solar, el coste por kilómetro puede ser hasta un 70% inferior al diésel. Sin tarifa optimizada, la ventaja se reduce al 30-40%.'
    },
    {
      title: 'Política de renovación',
      description: 'Si renuevas cada 2-3 años, el valor residual del eléctrico es más incierto. Si mantienes vehículos 5-6 años, el ahorro en mantenimiento compensa mejor el sobrecoste inicial.'
    },
    {
      title: 'Imagen corporativa',
      description: 'Si tu empresa tiene compromisos ESG o tus clientes valoran la sostenibilidad, el beneficio reputacional puede justificar un TCO ligeramente superior.'
    }
  ];

  return (
    <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12 bg-gray-50">
      <div className="max-w-4xl mx-auto">
        <h2 className="text-3xl font-bold text-gray-900 mb-8">Factores que cambian completamente la decisión</h2>
        <div className="grid md:grid-cols-2 gap-6">
          {factores.map((factor, index) => (
            <div key={index} className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-md transition-shadow">
              <h3 className="text-lg font-bold text-gray-900 mb-3">{factor.title}</h3>
              <p className="text-gray-700 leading-relaxed">{factor.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
