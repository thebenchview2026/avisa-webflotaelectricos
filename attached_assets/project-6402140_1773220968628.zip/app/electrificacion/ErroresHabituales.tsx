
'use client';

export default function ErroresHabituales() {
  const errores = [
    {
      title: 'Cambiar todos los vehículos de golpe',
      description: 'El cambio brusco genera resistencia, errores y sobrecarga en infraestructura. Lo recomendable es empezar con un vehículo, aprender y escalar progresivamente.'
    },
    {
      title: 'No formarse antes de conducir',
      description: 'Usar un eléctrico sin formación genera ansiedad de autonomía, uso ineficiente y quejas. La formación no es opcional, es parte del proceso de electrificación.'
    },
    {
      title: 'Confiar solo en la autonomía oficial',
      description: 'La autonomía WLTP puede reducirse hasta un 30% en condiciones reales de frío, calefacción y uso urbano. Planifica siempre con un margen de seguridad del 20-25%.'
    },
    {
      title: 'No calcular el coste de infraestructura',
      description: 'Instalar cargadores, adaptar instalación eléctrica y gestionar contratos de suministro tiene un coste que puede superar los 10.000€ por punto de carga. Este coste debe incluirse en el TCO.'
    }
  ];

  return (
    <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <h2 className="text-3xl font-bold text-gray-900 mb-8">Errores habituales al electrificar</h2>
      <div className="space-y-4">
        {errores.map((error, index) => (
          <div key={index} className="bg-red-50 border-l-4 border-red-500 p-6 rounded-r-lg">
            <h3 className="text-lg font-bold text-gray-900 mb-2">{error.title}</h3>
            <p className="text-gray-700 leading-relaxed">{error.description}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
