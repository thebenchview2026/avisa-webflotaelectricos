'use client';

import Link from 'next/link';

export default function ElectrificacionCTA() {
  const preguntasRelacionadas = [
    {
      pregunta: '¿A partir de cuántos kilómetros es rentable el renting?',
      href: '/preguntas'
    },
    {
      pregunta: '¿Renting o compra para mi vehículo eléctrico?',
      href: '/preguntas'
    },
    {
      pregunta: '¿Cómo calcular el coste real de un vehículo eléctrico?',
      href: '/preguntas'
    },
    {
      pregunta: '¿Qué marca es más fiable en eléctricos?',
      href: '/preguntas'
    }
  ];

  return (
    <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="mb-16">
        <h2 className="text-3xl font-bold text-gray-900 mb-8">Otras preguntas relacionadas</h2>
        <div className="grid md:grid-cols-2 gap-4">
          {preguntasRelacionadas.map((item, index) => (
            <Link 
              key={index}
              href={item.href}
              className="bg-white border border-gray-200 rounded-lg p-6 hover:border-[#14B8A6] hover:shadow-lg transition-all duration-300 cursor-pointer group"
            >
              <div className="flex items-start justify-between gap-4">
                <p className="text-gray-900 font-semibold leading-tight group-hover:text-[#14B8A6] transition-colors">
                  {item.pregunta}
                </p>
                <span className="w-6 h-6 flex items-center justify-center flex-shrink-0">
                  <i className="ri-arrow-right-line text-xl text-gray-400 group-hover:text-[#14B8A6] group-hover:translate-x-1 transition-all"></i>
                </span>
              </div>
            </Link>
          ))}
        </div>
      </div>

      <div className="bg-gradient-to-br from-[#14B8A6] to-[#0d9488] rounded-lg p-8">
        <div className="flex flex-col md:flex-row items-center gap-6 mb-6">
          <img 
            src="https://static.readdy.ai/image/ecd9e0a88a19846633f9ef23a8543c57/7da821f8687606f5711af9936393378a.jpeg" 
            alt="Ana - Asesora de Electrificación"
            className="w-20 h-20 rounded-full object-cover border-4 border-white/30 shadow-lg flex-shrink-0"
          />
          <div className="text-center md:text-left">
            <h2 className="text-3xl font-bold text-white mb-2">¿Quieres que un asesor revise tu caso concreto?</h2>
            <p className="text-white/90 text-sm">
              La persona que te va a atender es <strong>Ana</strong>, lleva más de 10 años como profesional en Avisa y de forma rápida tendrás un asesoramiento directo de alta calidad.
            </p>
          </div>
        </div>
        <p className="text-lg text-white/90 mb-8 leading-relaxed max-w-2xl mx-auto text-center">
          Cada situación es diferente. Analizamos tu perfil de uso, infraestructura y necesidades para ayudarte a decidir si electrificar tiene sentido en tu caso.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <a 
            href="https://wa.me/34955034600" 
            target="_blank" 
            rel="noopener noreferrer"
            className="whitespace-nowrap bg-[#25D366] hover:bg-[#20BD5A] text-white px-6 py-3 rounded-lg font-semibold transition-all duration-300 shadow-lg hover:shadow-xl flex items-center justify-center gap-2 cursor-pointer"
          >
            <span className="w-5 h-5 flex items-center justify-center">
              <i className="ri-whatsapp-line text-lg"></i>
            </span>
            Escríbeme
          </a>
          <Link 
            href="/concesionarios"
            className="whitespace-nowrap bg-white/20 text-white hover:bg-white/30 px-8 py-3 rounded-lg font-semibold transition-all duration-300 cursor-pointer border-2 border-white/20"
          >
            Ver concesionarios
          </Link>
        </div>
      </div>
    </section>
  );
}
