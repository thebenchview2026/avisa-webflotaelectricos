
'use client';

export default function DependeTuCaso() {
  const casos = [
    {
      titulo: 'Tipo de uso',
      descripcion: 'Un uso principalmente urbano tiene un perfil ideal para eléctricos. Un uso mayoritariamente interurbano o de largo recorrido, no tanto.'
    },
    {
      titulo: 'Número de vehículos',
      descripcion: 'Con 1-2 vehículos, la inversión en infraestructura es proporcionalmente mayor. Con varios vehículos, se diluye.'
    },
    {
      titulo: 'Uso real',
      descripcion: 'Si tus vehículos hacen 50 km diarios, electrificar es casi siempre rentable. Si hacen 400 km, casi nunca lo es.'
    },
    {
      titulo: 'Actitud personal',
      descripcion: 'Si tienes cultura de innovación, el cambio será más fluido. Si hay resistencia al cambio, necesitarás más tiempo y adaptación.'
    },
    {
      titulo: 'Capacidad de gestión',
      descripcion: 'Electrificar requiere tiempo de gestión. Si ya estás saturado, el cambio puede generar más problemas que beneficios.'
    },
    {
      titulo: 'Horizonte temporal',
      descripcion: 'Si necesitas resultados inmediatos, electrificar puede no ser la mejor opción. Si piensas a 3-5 años, el análisis cambia completamente.'
    }
  ];

  return (
    <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
      <div className="bg-gradient-to-br from-[#14B8A6]/10 to-[#0d9488]/10 rounded-lg p-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-6">Depende de tu caso si...</h2>
        <div className="space-y-4">
          {casos.map((caso, index) => (
            <div key={index} className="flex items-start gap-4">
              <span className="w-6 h-6 flex items-center justify-center flex-shrink-0 mt-1">
                <i className="ri-checkbox-circle-fill text-[#14B8A6] text-2xl"></i>
              </span>
              <p className="text-gray-800 leading-relaxed">
                <strong>{caso.titulo}:</strong> {caso.descripcion}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
