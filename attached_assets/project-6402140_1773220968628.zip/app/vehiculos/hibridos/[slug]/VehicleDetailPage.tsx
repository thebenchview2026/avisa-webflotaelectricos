'use client';

import { useState } from 'react';
import Link from 'next/link';
import VehicleContactForm from '@/components/VehicleContactForm';

const hybridVehicles: Record<string, any> = {
  'volkswagen-golf-gte': {
    brand: 'Volkswagen',
    name: 'Golf GTE',
    type: 'Híbrido Enchufable',
    price: '379€',
    pvp: '40.900€',
    badge: 'Compacto deportivo',
    tagline: 'Compacto deportivo híbrido · 245 CV · Etiqueta CERO',
    image: 'https://readdy.ai/api/search-image?query=Volkswagen%20Golf%20GTE%20plug-in%20hybrid%20in%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20compact%20hatchback&width=800&height=500&seq=vw-golf-gte-detail&orientation=landscape',
    gallery: [
      'https://readdy.ai/api/search-image?query=Volkswagen%20Golf%20GTE%20plug-in%20hybrid%20in%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20compact%20hatchback&width=900&height=600&seq=vw-golf-gte-g1&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Volkswagen%20Golf%20GTE%20rear%20view%20white%20studio%20background%20showing%20sporty%20design%20and%20LED%20lights&width=900&height=600&seq=vw-golf-gte-g2&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Volkswagen%20Golf%20GTE%20interior%20sporty%20cockpit%20digital%20displays%20premium%20materials&width=900&height=600&seq=vw-golf-gte-g3&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Volkswagen%20Golf%20GTE%20side%20profile%20white%20showing%20sporty%20hatchback%20proportions&width=900&height=600&seq=vw-golf-gte-g4&orientation=landscape'
    ],
    specs: {
      motor: {
        motorizacion: '1.4 TSI + Motor eléctrico',
        potenciaCombinada: '245 CV',
        parMaximo: '400 Nm',
        transmision: 'DSG 6 velocidades',
        traccion: 'Delantera',
        aceleracion: '6.7 s (0-100 km/h)',
        velocidadMaxima: '225 km/h'
      },
      bateria: {
        capacidad: '13 kWh',
        autonomiaElectrica: '62 km WLTP',
        tiempoCarga: '3h 40min (wallbox)',
        cargaAC: '3.6 kW',
        consumoMixto: '1.3 l/100km',
        emisionesCO2: '30 g/km'
      },
      dimensiones: {
        longitud: '4.284 mm',
        anchura: '1.789 mm',
        altura: '1.456 mm',
        batalla: '2.636 mm',
        maletero: '273 - 1.106 litros',
        peso: '1.615 kg',
        plazas: '5',
        puertas: '5'
      }
    },
    equipamiento: {
      exterior: ['Faros LED Matrix IQ.Light', 'Pilotos LED', 'Llantas 17" GTE', 'Difusor trasero GTE', 'Cristales tintados', 'Retrovisores eléctricos'],
      interior: ['Digital Cockpit Pro', 'Pantalla táctil 10"', 'Climatizador automático', 'Volante multifunción', 'Asientos deportivos', 'Iluminación ambiental'],
      tecnologia: ['We Connect Plus', 'Apple CarPlay / Android Auto', 'Navegación', 'Sistema de sonido', 'Carga inalámbrica', 'Asistente de voz'],
      seguridad: ['Front Assist', 'Lane Assist', 'ACC', 'Park Assist', '7 airbags', 'Cámara trasera']
    },
    ventajas: [
      { icon: 'ri-flashlight-line', title: 'Modo eléctrico', desc: 'Hasta 62 km en modo 100% eléctrico para trayectos urbanos sin emisiones' },
      { icon: 'ri-speed-line', title: 'Prestaciones GTE', desc: '245 CV combinados para una conducción deportiva y emocionante' },
      { icon: 'ri-leaf-line', title: 'Etiqueta CERO', desc: 'Acceso libre a zonas de bajas emisiones y ventajas fiscales' },
      { icon: 'ri-gas-station-line', title: 'Versatilidad', desc: 'Motor de combustión para viajes largos sin preocupaciones de autonomía' }
    ],
    related: [
      { slug: 'volkswagen-tiguan-ehybrid', name: 'Tiguan eHybrid', price: '479€/mes', image: 'https://readdy.ai/api/search-image?query=Volkswagen%20Tiguan%20eHybrid%20plug-in%20hybrid%20SUV%20in%20gray%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20family%20crossover&width=400&height=250&seq=vw-tiguan-rel&orientation=landscape' },
      { slug: 'seat-leon-ehybrid', name: 'SEAT León e-HYBRID', price: '349€/mes', image: 'https://readdy.ai/api/search-image?query=SEAT%20Leon%20e-HYBRID%20plug-in%20hybrid%20in%20red%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20compact%20sporty%20hatchback&width=400&height=250&seq=seat-leon-rel&orientation=landscape' },
      { slug: 'cupra-leon-ehybrid', name: 'CUPRA León e-HYBRID', price: '399€/mes', image: 'https://readdy.ai/api/search-image?query=CUPRA%20Leon%20e-HYBRID%20plug-in%20hybrid%20in%20copper%20bronze%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20performance%20hatchback&width=400&height=250&seq=cupra-leon-rel&orientation=landscape' }
    ]
  },
  'volkswagen-tiguan-ehybrid': {
    brand: 'Volkswagen',
    name: 'Tiguan eHybrid',
    type: 'Híbrido Enchufable',
    price: '479€',
    pvp: '51.800€',
    badge: 'SUV familiar',
    tagline: 'SUV familiar híbrido · 245 CV · Etiqueta CERO',
    image: 'https://readdy.ai/api/search-image?query=Volkswagen%20Tiguan%20eHybrid%20plug-in%20hybrid%20SUV%20in%20gray%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20family%20crossover&width=800&height=500&seq=vw-tiguan-detail&orientation=landscape',
    gallery: [
      'https://readdy.ai/api/search-image?query=Volkswagen%20Tiguan%20eHybrid%20plug-in%20hybrid%20SUV%20in%20gray%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20family%20crossover&width=900&height=600&seq=vw-tiguan-g1&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Volkswagen%20Tiguan%20eHybrid%20rear%20view%20gray%20studio%20background%20showing%20LED%20lights&width=900&height=600&seq=vw-tiguan-g2&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Volkswagen%20Tiguan%20eHybrid%20interior%20spacious%20cabin%20digital%20displays&width=900&height=600&seq=vw-tiguan-g3&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Volkswagen%20Tiguan%20eHybrid%20side%20profile%20gray%20showing%20SUV%20proportions&width=900&height=600&seq=vw-tiguan-g4&orientation=landscape'
    ],
    specs: {
      motor: {
        motorizacion: '1.4 TSI + Motor eléctrico',
        potenciaCombinada: '245 CV',
        parMaximo: '400 Nm',
        transmision: 'DSG 6 velocidades',
        traccion: 'Delantera',
        aceleracion: '7.5 s (0-100 km/h)',
        velocidadMaxima: '205 km/h'
      },
      bateria: {
        capacidad: '13 kWh',
        autonomiaElectrica: '50 km WLTP',
        tiempoCarga: '3h 50min (wallbox)',
        cargaAC: '3.6 kW',
        consumoMixto: '1.6 l/100km',
        emisionesCO2: '36 g/km'
      },
      dimensiones: {
        longitud: '4.509 mm',
        anchura: '1.839 mm',
        altura: '1.675 mm',
        batalla: '2.681 mm',
        maletero: '477 - 1.497 litros',
        peso: '1.764 kg',
        plazas: '5',
        puertas: '5'
      }
    },
    equipamiento: {
      exterior: ['Faros LED Matrix', 'Pilotos LED', 'Llantas 18"', 'Barras de techo', 'Portón eléctrico', 'Cristales tintados'],
      interior: ['Digital Cockpit Pro', 'Pantalla táctil 9.2"', 'Climatizador trizona', 'Volante multifunción', 'Asientos ergonómicos', 'Iluminación ambiental'],
      tecnologia: ['We Connect Plus', 'Apple CarPlay / Android Auto', 'Navegación', 'Sistema de sonido', 'Carga inalámbrica', 'Asistente de voz'],
      seguridad: ['Front Assist', 'Lane Assist', 'ACC', 'Park Assist', '7 airbags', 'Cámara 360°']
    },
    ventajas: [
      { icon: 'ri-space', title: 'Espacio familiar', desc: 'Amplio habitáculo y maletero de 477 litros para toda la familia' },
      { icon: 'ri-flashlight-line', title: 'Modo eléctrico', desc: 'Hasta 50 km en modo 100% eléctrico para trayectos urbanos' },
      { icon: 'ri-leaf-line', title: 'Etiqueta CERO', desc: 'Acceso libre a zonas de bajas emisiones y ventajas fiscales' },
      { icon: 'ri-shield-check-line', title: 'Seguridad 5 estrellas', desc: 'Máxima puntuación Euro NCAP con sistemas de asistencia avanzados' }
    ],
    related: [
      { slug: 'volkswagen-golf-gte', name: 'Golf GTE', price: '379€/mes', image: 'https://readdy.ai/api/search-image?query=Volkswagen%20Golf%20GTE%20plug-in%20hybrid%20in%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20compact%20hatchback&width=400&height=250&seq=vw-golf-rel&orientation=landscape' },
      { slug: 'volkswagen-touareg-ehybrid', name: 'Touareg eHybrid', price: '749€/mes', image: 'https://readdy.ai/api/search-image?query=Volkswagen%20Touareg%20eHybrid%20plug-in%20hybrid%20luxury%20SUV%20in%20black%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20flagship%20crossover&width=400&height=250&seq=vw-touareg-rel&orientation=landscape' },
      { slug: 'seat-tarraco-ehybrid', name: 'SEAT Tarraco e-HYBRID', price: '479€/mes', image: 'https://readdy.ai/api/search-image?query=SEAT%20Tarraco%20e-HYBRID%20plug-in%20hybrid%20large%20SUV%20in%20gray%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20seven%20seater%20crossover&width=400&height=250&seq=seat-tarraco-rel&orientation=landscape' }
    ]
  },
  'volkswagen-touareg-ehybrid': {
    brand: 'Volkswagen',
    name: 'Touareg eHybrid',
    type: 'Híbrido Enchufable',
    price: '749€',
    pvp: '80.900€',
    badge: 'Premium SUV',
    tagline: 'SUV premium híbrido · 462 CV · Etiqueta CERO',
    image: 'https://readdy.ai/api/search-image?query=Volkswagen%20Touareg%20eHybrid%20plug-in%20hybrid%20luxury%20SUV%20in%20black%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20flagship%20crossover&width=800&height=500&seq=vw-touareg-detail&orientation=landscape',
    gallery: [
      'https://readdy.ai/api/search-image?query=Volkswagen%20Touareg%20eHybrid%20plug-in%20hybrid%20luxury%20SUV%20in%20black%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20flagship%20crossover&width=900&height=600&seq=vw-touareg-g1&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Volkswagen%20Touareg%20eHybrid%20rear%20view%20black%20studio%20background%20showing%20premium%20LED%20lights&width=900&height=600&seq=vw-touareg-g2&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Volkswagen%20Touareg%20eHybrid%20interior%20luxury%20cabin%20premium%20leather%20digital%20displays&width=900&height=600&seq=vw-touareg-g3&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Volkswagen%20Touareg%20eHybrid%20side%20profile%20black%20showing%20flagship%20SUV%20proportions&width=900&height=600&seq=vw-touareg-g4&orientation=landscape'
    ],
    specs: {
      motor: {
        motorizacion: '3.0 V6 TSI + Motor eléctrico',
        potenciaCombinada: '462 CV',
        parMaximo: '700 Nm',
        transmision: 'Tiptronic 8 velocidades',
        traccion: 'Total (4MOTION)',
        aceleracion: '5.7 s (0-100 km/h)',
        velocidadMaxima: '250 km/h'
      },
      bateria: {
        capacidad: '14.3 kWh',
        autonomiaElectrica: '47 km WLTP',
        tiempoCarga: '4h 30min (wallbox)',
        cargaAC: '3.6 kW',
        consumoMixto: '2.7 l/100km',
        emisionesCO2: '62 g/km'
      },
      dimensiones: {
        longitud: '4.878 mm',
        anchura: '1.984 mm',
        altura: '1.717 mm',
        batalla: '2.904 mm',
        maletero: '610 - 1.675 litros',
        peso: '2.510 kg',
        plazas: '5',
        puertas: '5'
      }
    },
    equipamiento: {
      exterior: ['Faros LED Matrix IQ.Light HD', 'Pilotos LED 3D', 'Llantas 20"', 'Techo panorámico', 'Portón eléctrico', 'Estribos iluminados'],
      interior: ['Innovision Cockpit', 'Pantalla táctil 15"', 'Climatizador 4 zonas', 'Asientos Ergocomfort', 'Cuero Nappa', 'Iluminación ambiental 30 colores'],
      tecnologia: ['We Connect Plus', 'Apple CarPlay / Android Auto', 'Navegación premium', 'Dynaudio 3D', 'Head-up Display', 'Asistente de voz'],
      seguridad: ['Front Assist', 'Lane Assist', 'ACC predictivo', 'Night Vision', '9 airbags', 'Cámara 360°']
    },
    ventajas: [
      { icon: 'ri-vip-crown-line', title: 'Lujo absoluto', desc: 'Materiales premium y tecnología de vanguardia en cada detalle' },
      { icon: 'ri-speed-line', title: 'Prestaciones V6', desc: '462 CV combinados para prestaciones de deportivo en un SUV' },
      { icon: 'ri-leaf-line', title: 'Etiqueta CERO', desc: 'Lujo sostenible con acceso a todas las zonas' },
      { icon: 'ri-steering-2-line', title: 'Tracción 4MOTION', desc: 'Capacidad todoterreno con confort de berlina de lujo' }
    ],
    related: [
      { slug: 'volkswagen-tiguan-ehybrid', name: 'Tiguan eHybrid', price: '479€/mes', image: 'https://readdy.ai/api/search-image?query=Volkswagen%20Tiguan%20eHybrid%20plug-in%20hybrid%20SUV%20in%20gray%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20family%20crossover&width=400&height=250&seq=vw-tiguan-rel2&orientation=landscape' },
      { slug: 'audi-q5-tfsi-e', name: 'Audi Q5 TFSI e', price: '649€/mes', image: 'https://readdy.ai/api/search-image?query=Audi%20Q5%20TFSI%20e%20quattro%20plug-in%20hybrid%20SUV%20in%20dark%20blue%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20premium%20crossover&width=400&height=250&seq=audi-q5-rel&orientation=landscape' },
      { slug: 'audi-q3-tfsi-e', name: 'Audi Q3 TFSI e', price: '499€/mes', image: 'https://readdy.ai/api/search-image?query=Audi%20Q3%20TFSI%20e%20plug-in%20hybrid%20SUV%20in%20silver%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20compact%20crossover&width=400&height=250&seq=audi-q3-rel&orientation=landscape' }
    ]
  },
  'audi-a3-tfsi-e': {
    brand: 'Audi',
    name: 'A3 Sportback TFSI e',
    type: 'Híbrido Enchufable',
    price: '429€',
    pvp: '46.400€',
    badge: 'Compacto premium',
    tagline: 'Compacto premium híbrido · 204 CV · Etiqueta CERO',
    image: 'https://readdy.ai/api/search-image?query=Audi%20A3%20Sportback%20TFSI%20e%20plug-in%20hybrid%20in%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20premium%20compact%20hatchback&width=800&height=500&seq=audi-a3-tfsi-detail&orientation=landscape',
    gallery: [
      'https://readdy.ai/api/search-image?query=Audi%20A3%20Sportback%20TFSI%20e%20plug-in%20hybrid%20in%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20premium%20compact%20hatchback&width=900&height=600&seq=audi-a3-tfsi-g1&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Audi%20A3%20Sportback%20TFSI%20e%20rear%20view%20white%20studio%20background%20showing%20LED%20lights&width=900&height=600&seq=audi-a3-tfsi-g2&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Audi%20A3%20Sportback%20TFSI%20e%20interior%20virtual%20cockpit%20premium%20materials&width=900&height=600&seq=audi-a3-tfsi-g3&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Audi%20A3%20Sportback%20TFSI%20e%20side%20profile%20white%20showing%20compact%20proportions&width=900&height=600&seq=audi-a3-tfsi-g4&orientation=landscape'
    ],
    specs: {
      motor: {
        motorizacion: '1.4 TFSI + Motor eléctrico',
        potenciaCombinada: '204 CV',
        parMaximo: '350 Nm',
        transmision: 'S tronic 6 velocidades',
        traccion: 'Delantera',
        aceleracion: '7.6 s (0-100 km/h)',
        velocidadMaxima: '227 km/h'
      },
      bateria: {
        capacidad: '13 kWh',
        autonomiaElectrica: '78 km WLTP',
        tiempoCarga: '3h 40min (wallbox)',
        cargaAC: '3.6 kW',
        consumoMixto: '1.2 l/100km',
        emisionesCO2: '28 g/km'
      },
      dimensiones: {
        longitud: '4.343 mm',
        anchura: '1.816 mm',
        altura: '1.449 mm',
        batalla: '2.636 mm',
        maletero: '280 - 1.100 litros',
        peso: '1.590 kg',
        plazas: '5',
        puertas: '5'
      }
    },
    equipamiento: {
      exterior: ['Faros LED', 'Pilotos LED', 'Llantas 17"', 'Retrovisores eléctricos', 'Cristales tintados', 'Sensor de lluvia'],
      interior: ['Audi Virtual Cockpit', 'MMI touch 10.1"', 'Climatizador automático', 'Volante multifunción', 'Asientos deportivos', 'Iluminación ambiental'],
      tecnologia: ['Audi connect', 'Apple CarPlay / Android Auto', 'Navegación MMI', 'Sistema de sonido', 'Carga inalámbrica', 'Asistente Audi'],
      seguridad: ['Audi pre sense front', 'Lane Assist', 'ACC', 'Park Assist', '6 airbags', 'Cámara trasera']
    },
    ventajas: [
      { icon: 'ri-flashlight-line', title: 'Líder en autonomía', desc: 'Hasta 78 km en modo eléctrico, la mejor de su categoría' },
      { icon: 'ri-vip-crown-line', title: 'Premium Audi', desc: 'Calidad de construcción y materiales de primer nivel' },
      { icon: 'ri-leaf-line', title: 'Etiqueta CERO', desc: 'Acceso libre a zonas de bajas emisiones y ventajas fiscales' },
      { icon: 'ri-money-euro-circle-line', title: 'Consumo mínimo', desc: 'Solo 1.2 l/100km en ciclo mixto WLTP' }
    ],
    related: [
      { slug: 'audi-q3-tfsi-e', name: 'Q3 TFSI e', price: '499€/mes', image: 'https://readdy.ai/api/search-image?query=Audi%20Q3%20TFSI%20e%20plug-in%20hybrid%20SUV%20in%20silver%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20compact%20crossover&width=400&height=250&seq=audi-q3-rel2&orientation=landscape' },
      { slug: 'audi-q5-tfsi-e', name: 'Q5 TFSI e quattro', price: '649€/mes', image: 'https://readdy.ai/api/search-image?query=Audi%20Q5%20TFSI%20e%20quattro%20plug-in%20hybrid%20SUV%20in%20dark%20blue%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20premium%20crossover&width=400&height=250&seq=audi-q5-rel2&orientation=landscape' },
      { slug: 'volkswagen-golf-gte', name: 'VW Golf GTE', price: '379€/mes', image: 'https://readdy.ai/api/search-image?query=Volkswagen%20Golf%20GTE%20plug-in%20hybrid%20in%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20compact%20hatchback&width=400&height=250&seq=vw-golf-rel2&orientation=landscape' }
    ]
  },
  'audi-q3-tfsi-e': {
    brand: 'Audi',
    name: 'Q3 TFSI e',
    type: 'Híbrido Enchufable',
    price: '499€',
    pvp: '53.900€',
    badge: 'SUV compacto',
    tagline: 'SUV compacto premium híbrido · 245 CV · Etiqueta CERO',
    image: 'https://readdy.ai/api/search-image?query=Audi%20Q3%20TFSI%20e%20plug-in%20hybrid%20SUV%20in%20silver%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20compact%20crossover&width=800&height=500&seq=audi-q3-detail&orientation=landscape',
    gallery: [
      'https://readdy.ai/api/search-image?query=Audi%20Q3%20TFSI%20e%20plug-in%20hybrid%20SUV%20in%20silver%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20compact%20crossover&width=900&height=600&seq=audi-q3-g1&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Audi%20Q3%20TFSI%20e%20rear%20view%20silver%20studio%20background%20showing%20LED%20lights&width=900&height=600&seq=audi-q3-g2&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Audi%20Q3%20TFSI%20e%20interior%20virtual%20cockpit%20premium%20cabin&width=900&height=600&seq=audi-q3-g3&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Audi%20Q3%20TFSI%20e%20side%20profile%20silver%20showing%20compact%20SUV%20proportions&width=900&height=600&seq=audi-q3-g4&orientation=landscape'
    ],
    specs: {
      motor: {
        motorizacion: '1.4 TFSI + Motor eléctrico',
        potenciaCombinada: '245 CV',
        parMaximo: '400 Nm',
        transmision: 'S tronic 6 velocidades',
        traccion: 'Delantera',
        aceleracion: '7.3 s (0-100 km/h)',
        velocidadMaxima: '210 km/h'
      },
      bateria: {
        capacidad: '13 kWh',
        autonomiaElectrica: '61 km WLTP',
        tiempoCarga: '3h 45min (wallbox)',
        cargaAC: '3.6 kW',
        consumoMixto: '1.4 l/100km',
        emisionesCO2: '32 g/km'
      },
      dimensiones: {
        longitud: '4.484 mm',
        anchura: '1.849 mm',
        altura: '1.616 mm',
        batalla: '2.680 mm',
        maletero: '380 - 1.375 litros',
        peso: '1.790 kg',
        plazas: '5',
        puertas: '5'
      }
    },
    equipamiento: {
      exterior: ['Faros LED', 'Pilotos LED', 'Llantas 18"', 'Barras de techo', 'Portón eléctrico', 'Cristales tintados'],
      interior: ['Audi Virtual Cockpit', 'MMI touch 10.1"', 'Climatizador bizona', 'Volante multifunción', 'Asientos deportivos', 'Iluminación ambiental'],
      tecnologia: ['Audi connect', 'Apple CarPlay / Android Auto', 'Navegación MMI', 'Sistema de sonido', 'Carga inalámbrica', 'Asistente Audi'],
      seguridad: ['Audi pre sense front', 'Lane Assist', 'ACC', 'Park Assist', '6 airbags', 'Cámara trasera']
    },
    ventajas: [
      { icon: 'ri-space', title: 'Compacto versátil', desc: 'Tamaño ideal para ciudad con espacio para toda la familia' },
      { icon: 'ri-flashlight-line', title: 'Modo eléctrico', desc: 'Hasta 61 km en modo 100% eléctrico para uso urbano' },
      { icon: 'ri-leaf-line', title: 'Etiqueta CERO', desc: 'Acceso libre a zonas de bajas emisiones y ventajas fiscales' },
      { icon: 'ri-vip-crown-line', title: 'Premium Audi', desc: 'Calidad y tecnología Audi en formato compacto' }
    ],
    related: [
      { slug: 'audi-a3-tfsi-e', name: 'A3 Sportback TFSI e', price: '429€/mes', image: 'https://readdy.ai/api/search-image?query=Audi%20A3%20Sportback%20TFSI%20e%20plug-in%20hybrid%20in%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20premium%20compact%20hatchback&width=400&height=250&seq=audi-a3-rel&orientation=landscape' },
      { slug: 'audi-q5-tfsi-e', name: 'Q5 TFSI e quattro', price: '649€/mes', image: 'https://readdy.ai/api/search-image?query=Audi%20Q5%20TFSI%20e%20quattro%20plug-in%20hybrid%20SUV%20in%20dark%20blue%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20premium%20crossover&width=400&height=250&seq=audi-q5-rel3&orientation=landscape' },
      { slug: 'volkswagen-tiguan-ehybrid', name: 'VW Tiguan eHybrid', price: '479€/mes', image: 'https://readdy.ai/api/search-image?query=Volkswagen%20Tiguan%20eHybrid%20plug-in%20hybrid%20SUV%20in%20gray%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20family%20crossover&width=400&height=250&seq=vw-tiguan-rel3&orientation=landscape' }
    ]
  },
  'audi-q5-tfsi-e': {
    brand: 'Audi',
    name: 'Q5 TFSI e quattro',
    type: 'Híbrido Enchufable',
    price: '649€',
    pvp: '70.100€',
    badge: 'SUV versátil',
    tagline: 'SUV premium híbrido · 367 CV · Etiqueta CERO',
    image: 'https://readdy.ai/api/search-image?query=Audi%20Q5%20TFSI%20e%20quattro%20plug-in%20hybrid%20SUV%20in%20dark%20blue%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20premium%20crossover&width=800&height=500&seq=audi-q5-detail&orientation=landscape',
    gallery: [
      'https://readdy.ai/api/search-image?query=Audi%20Q5%20TFSI%20e%20quattro%20plug-in%20hybrid%20SUV%20in%20dark%20blue%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20premium%20crossover&width=900&height=600&seq=audi-q5-g1&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Audi%20Q5%20TFSI%20e%20rear%20view%20dark%20blue%20studio%20background%20showing%20LED%20lights&width=900&height=600&seq=audi-q5-g2&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Audi%20Q5%20TFSI%20e%20interior%20luxury%20cabin%20virtual%20cockpit%20premium%20leather&width=900&height=600&seq=audi-q5-g3&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Audi%20Q5%20TFSI%20e%20side%20profile%20dark%20blue%20showing%20SUV%20proportions&width=900&height=600&seq=audi-q5-g4&orientation=landscape'
    ],
    specs: {
      motor: {
        motorizacion: '2.0 TFSI + Motor eléctrico',
        potenciaCombinada: '367 CV',
        parMaximo: '500 Nm',
        transmision: 'S tronic 7 velocidades',
        traccion: 'Total (quattro)',
        aceleracion: '5.3 s (0-100 km/h)',
        velocidadMaxima: '239 km/h'
      },
      bateria: {
        capacidad: '17.9 kWh',
        autonomiaElectrica: '62 km WLTP',
        tiempoCarga: '5h 30min (wallbox)',
        cargaAC: '3.6 kW',
        consumoMixto: '1.9 l/100km',
        emisionesCO2: '44 g/km'
      },
      dimensiones: {
        longitud: '4.682 mm',
        anchura: '1.893 mm',
        altura: '1.659 mm',
        batalla: '2.819 mm',
        maletero: '465 - 1.450 litros',
        peso: '2.105 kg',
        plazas: '5',
        puertas: '5'
      }
    },
    equipamiento: {
      exterior: ['Faros LED Matrix', 'Pilotos LED', 'Llantas 19"', 'Barras de techo', 'Portón eléctrico', 'Cristales acústicos'],
      interior: ['Audi Virtual Cockpit Plus', 'MMI touch 10.1"', 'Climatizador trizona', 'Volante multifunción', 'Asientos S line', 'Iluminación ambiental plus'],
      tecnologia: ['Audi connect plus', 'Apple CarPlay / Android Auto', 'Navegación MMI plus', 'Bang & Olufsen', 'Head-up Display', 'Asistente Audi'],
      seguridad: ['Audi pre sense 360°', 'Lane Assist', 'ACC predictivo', 'Park Assist plus', '8 airbags', 'Cámara 360°']
    },
    ventajas: [
      { icon: 'ri-speed-line', title: 'Prestaciones deportivas', desc: '367 CV y 0-100 en 5.3 segundos con tracción quattro' },
      { icon: 'ri-flashlight-line', title: 'Modo eléctrico', desc: 'Hasta 62 km en modo 100% eléctrico para uso urbano' },
      { icon: 'ri-leaf-line', title: 'Etiqueta CERO', desc: 'Potencia sin renunciar a ventajas fiscales y acceso a ZBE' },
      { icon: 'ri-steering-2-line', title: 'Tracción quattro', desc: 'Seguridad y control en cualquier condición meteorológica' }
    ],
    related: [
      { slug: 'audi-q3-tfsi-e', name: 'Q3 TFSI e', price: '499€/mes', image: 'https://readdy.ai/api/search-image?query=Audi%20Q3%20TFSI%20e%20plug-in%20hybrid%20SUV%20in%20silver%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20compact%20crossover&width=400&height=250&seq=audi-q3-rel3&orientation=landscape' },
      { slug: 'audi-a3-tfsi-e', name: 'A3 Sportback TFSI e', price: '429€/mes', image: 'https://readdy.ai/api/search-image?query=Audi%20A3%20Sportback%20TFSI%20e%20plug-in%20hybrid%20in%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20premium%20compact%20hatchback&width=400&height=250&seq=audi-a3-rel2&orientation=landscape' },
      { slug: 'volkswagen-touareg-ehybrid', name: 'VW Touareg eHybrid', price: '749€/mes', image: 'https://readdy.ai/api/search-image?query=Volkswagen%20Touareg%20eHybrid%20plug-in%20hybrid%20luxury%20SUV%20in%20black%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20flagship%20crossover&width=400&height=250&seq=vw-touareg-rel2&orientation=landscape' }
    ]
  },
  'seat-leon-ehybrid': {
    brand: 'SEAT',
    name: 'León e-HYBRID',
    type: 'Híbrido Enchufable',
    price: '349€',
    pvp: '37.700€',
    badge: 'Mejor precio',
    tagline: 'Compacto híbrido accesible · 204 CV · Etiqueta CERO',
    image: 'https://readdy.ai/api/search-image?query=SEAT%20Leon%20e-HYBRID%20plug-in%20hybrid%20in%20red%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20compact%20sporty%20hatchback&width=800&height=500&seq=seat-leon-detail&orientation=landscape',
    gallery: [
      'https://readdy.ai/api/search-image?query=SEAT%20Leon%20e-HYBRID%20plug-in%20hybrid%20in%20red%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20compact%20sporty%20hatchback&width=900&height=600&seq=seat-leon-g1&orientation=landscape',
      'https://readdy.ai/api/search-image?query=SEAT%20Leon%20e-HYBRID%20rear%20view%20red%20studio%20background%20showing%20LED%20lights&width=900&height=600&seq=seat-leon-g2&orientation=landscape',
      'https://readdy.ai/api/search-image?query=SEAT%20Leon%20e-HYBRID%20interior%20modern%20cockpit%20digital%20displays&width=900&height=600&seq=seat-leon-g3&orientation=landscape',
      'https://readdy.ai/api/search-image?query=SEAT%20Leon%20e-HYBRID%20side%20profile%20red%20showing%20sporty%20hatchback%20design&width=900&height=600&seq=seat-leon-g4&orientation=landscape'
    ],
    specs: {
      motor: {
        motorizacion: '1.4 TSI + Motor eléctrico',
        potenciaCombinada: '204 CV',
        parMaximo: '350 Nm',
        transmision: 'DSG 6 velocidades',
        traccion: 'Delantera',
        aceleracion: '7.5 s (0-100 km/h)',
        velocidadMaxima: '220 km/h'
      },
      bateria: {
        capacidad: '13 kWh',
        autonomiaElectrica: '63 km WLTP',
        tiempoCarga: '3h 40min (wallbox)',
        cargaAC: '3.6 kW',
        consumoMixto: '1.2 l/100km',
        emisionesCO2: '27 g/km'
      },
      dimensiones: {
        longitud: '4.368 mm',
        anchura: '1.800 mm',
        altura: '1.456 mm',
        batalla: '2.686 mm',
        maletero: '270 - 1.143 litros',
        peso: '1.580 kg',
        plazas: '5',
        puertas: '5'
      }
    },
    equipamiento: {
      exterior: ['Faros Full LED', 'Pilotos LED', 'Llantas 17"', 'Retrovisores eléctricos', 'Cristales tintados', 'Sensor de lluvia'],
      interior: ['Digital Cockpit', 'Pantalla 10"', 'Climatizador automático', 'Volante multifunción', 'Asientos ergonómicos', 'Iluminación ambiental'],
      tecnologia: ['SEAT Connect', 'Apple CarPlay / Android Auto', 'Navegación', 'Sistema de sonido', 'Carga inalámbrica', 'Asistente de voz'],
      seguridad: ['Front Assist', 'Lane Assist', 'ACC', 'Park Assist', '7 airbags', 'Cámara trasera']
    },
    ventajas: [
      { icon: 'ri-money-euro-circle-line', title: 'Mejor precio', desc: 'El híbrido enchufable más accesible del grupo Volkswagen' },
      { icon: 'ri-flashlight-line', title: 'Gran autonomía EV', desc: 'Hasta 63 km en modo eléctrico, líder en su segmento' },
      { icon: 'ri-leaf-line', title: 'Etiqueta CERO', desc: 'Acceso libre a zonas de bajas emisiones y ventajas fiscales' },
      { icon: 'ri-palette-line', title: 'Diseño español', desc: 'Líneas dinámicas y deportivas diseñadas en Barcelona' }
    ],
    related: [
      { slug: 'seat-leon-sportstourer-ehybrid', name: 'León Sportstourer e-HYBRID', price: '369€/mes', image: 'https://readdy.ai/api/search-image?query=SEAT%20Leon%20Sportstourer%20e-HYBRID%20plug-in%20hybrid%20wagon%20in%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20family%20estate%20car&width=400&height=250&seq=seat-leon-st-rel&orientation=landscape' },
      { slug: 'seat-tarraco-ehybrid', name: 'Tarraco e-HYBRID', price: '479€/mes', image: 'https://readdy.ai/api/search-image?query=SEAT%20Tarraco%20e-HYBRID%20plug-in%20hybrid%20large%20SUV%20in%20gray%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20seven%20seater%20crossover&width=400&height=250&seq=seat-tarraco-rel2&orientation=landscape' },
      { slug: 'cupra-leon-ehybrid', name: 'CUPRA León e-HYBRID', price: '399€/mes', image: 'https://readdy.ai/api/search-image?query=CUPRA%20Leon%20e-HYBRID%20plug-in%20hybrid%20in%20copper%20bronze%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20performance%20hatchback&width=400&height=250&seq=cupra-leon-rel2&orientation=landscape' }
    ]
  },
  'seat-leon-sportstourer-ehybrid': {
    brand: 'SEAT',
    name: 'León Sportstourer e-HYBRID',
    type: 'Híbrido Enchufable',
    price: '369€',
    pvp: '39.900€',
    badge: 'Familiar',
    tagline: 'Familiar híbrido versátil · 204 CV · Etiqueta CERO',
    image: 'https://readdy.ai/api/search-image?query=SEAT%20Leon%20Sportstourer%20e-HYBRID%20plug-in%20hybrid%20wagon%20in%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20family%20estate%20car&width=800&height=500&seq=seat-leon-st-detail&orientation=landscape',
    gallery: [
      'https://readdy.ai/api/search-image?query=SEAT%20Leon%20Sportstourer%20e-HYBRID%20plug-in%20hybrid%20wagon%20in%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20family%20estate%20car&width=900&height=600&seq=seat-leon-st-g1&orientation=landscape',
      'https://readdy.ai/api/search-image?query=SEAT%20Leon%20Sportstourer%20e-HYBRID%20rear%20view%20white%20studio%20background%20showing%20wagon%20design&width=900&height=600&seq=seat-leon-st-g2&orientation=landscape',
      'https://readdy.ai/api/search-image?query=SEAT%20Leon%20Sportstourer%20e-HYBRID%20interior%20spacious%20cabin%20digital%20displays&width=900&height=600&seq=seat-leon-st-g3&orientation=landscape',
      'https://readdy.ai/api/search-image?query=SEAT%20Leon%20Sportstourer%20e-HYBRID%20side%20profile%20white%20showing%20estate%20proportions&width=900&height=600&seq=seat-leon-st-g4&orientation=landscape'
    ],
    specs: {
      motor: {
        motorizacion: '1.4 TSI + Motor eléctrico',
        potenciaCombinada: '204 CV',
        parMaximo: '350 Nm',
        transmision: 'DSG 6 velocidades',
        traccion: 'Delantera',
        aceleracion: '7.8 s (0-100 km/h)',
        velocidadMaxima: '218 km/h'
      },
      bateria: {
        capacidad: '13 kWh',
        autonomiaElectrica: '64 km WLTP',
        tiempoCarga: '3h 40min (wallbox)',
        cargaAC: '3.6 kW',
        consumoMixto: '1.3 l/100km',
        emisionesCO2: '29 g/km'
      },
      dimensiones: {
        longitud: '4.642 mm',
        anchura: '1.800 mm',
        altura: '1.448 mm',
        batalla: '2.686 mm',
        maletero: '470 - 1.450 litros',
        peso: '1.620 kg',
        plazas: '5',
        puertas: '5'
      }
    },
    equipamiento: {
      exterior: ['Faros Full LED', 'Pilotos LED', 'Llantas 17"', 'Barras de techo', 'Portón eléctrico', 'Cristales tintados'],
      interior: ['Digital Cockpit', 'Pantalla 10"', 'Climatizador automático', 'Volante multifunción', 'Asientos ergonómicos', 'Iluminación ambiental'],
      tecnologia: ['SEAT Connect', 'Apple CarPlay / Android Auto', 'Navegación', 'Sistema de sonido', 'Carga inalámbrica', 'Asistente de voz'],
      seguridad: ['Front Assist', 'Lane Assist', 'ACC', 'Park Assist', '7 airbags', 'Cámara trasera']
    },
    ventajas: [
      { icon: 'ri-space', title: 'Máximo espacio', desc: 'Maletero de 470 litros, ideal para familias y profesionales' },
      { icon: 'ri-flashlight-line', title: 'Gran autonomía EV', desc: 'Hasta 64 km en modo eléctrico para uso diario sin emisiones' },
      { icon: 'ri-leaf-line', title: 'Etiqueta CERO', desc: 'Acceso libre a zonas de bajas emisiones y ventajas fiscales' },
      { icon: 'ri-money-euro-circle-line', title: 'Precio competitivo', desc: 'El familiar híbrido enchufable más accesible' }
    ],
    related: [
      { slug: 'seat-leon-ehybrid', name: 'León e-HYBRID', price: '349€/mes', image: 'https://readdy.ai/api/search-image?query=SEAT%20Leon%20e-HYBRID%20plug-in%20hybrid%20in%20red%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20compact%20sporty%20hatchback&width=400&height=250&seq=seat-leon-rel2&orientation=landscape' },
      { slug: 'seat-tarraco-ehybrid', name: 'Tarraco e-HYBRID', price: '479€/mes', image: 'https://readdy.ai/api/search-image?query=SEAT%20Tarraco%20e-HYBRID%20plug-in%20hybrid%20large%20SUV%20in%20gray%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20seven%20seater%20crossover&width=400&height=250&seq=seat-tarraco-rel3&orientation=landscape' },
      { slug: 'skoda-octavia-combi-iv', name: 'Škoda Octavia Combi iV', price: '379€/mes', image: 'https://readdy.ai/api/search-image?query=Skoda%20Octavia%20Combi%20iV%20plug-in%20hybrid%20wagon%20in%20green%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20spacious%20estate%20car&width=400&height=250&seq=skoda-octavia-combi-rel&orientation=landscape' }
    ]
  },
  'seat-tarraco-ehybrid': {
    brand: 'SEAT',
    name: 'Tarraco e-HYBRID',
    type: 'Híbrido Enchufable',
    price: '479€',
    pvp: '51.700€',
    badge: '7 plazas',
    tagline: 'SUV familiar 7 plazas híbrido · 245 CV · Etiqueta CERO',
    image: 'https://readdy.ai/api/search-image?query=SEAT%20Tarraco%20e-HYBRID%20plug-in%20hybrid%20large%20SUV%20in%20gray%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20seven%20seater%20crossover&width=800&height=500&seq=seat-tarraco-detail&orientation=landscape',
    gallery: [
      'https://readdy.ai/api/search-image?query=SEAT%20Tarraco%20e-HYBRID%20plug-in%20hybrid%20large%20SUV%20in%20gray%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20seven%20seater%20crossover&width=900&height=600&seq=seat-tarraco-g1&orientation=landscape',
      'https://readdy.ai/api/search-image?query=SEAT%20Tarraco%20e-HYBRID%20rear%20view%20gray%20studio%20background%20showing%20LED%20lights&width=900&height=600&seq=seat-tarraco-g2&orientation=landscape',
      'https://readdy.ai/api/search-image?query=SEAT%20Tarraco%20e-HYBRID%20interior%20spacious%20seven%20seater%20cabin&width=900&height=600&seq=seat-tarraco-g3&orientation=landscape',
      'https://readdy.ai/api/search-image?query=SEAT%20Tarraco%20e-HYBRID%20side%20profile%20gray%20showing%20large%20SUV%20proportions&width=900&height=600&seq=seat-tarraco-g4&orientation=landscape'
    ],
    specs: {
      motor: {
        motorizacion: '1.4 TSI + Motor eléctrico',
        potenciaCombinada: '245 CV',
        parMaximo: '400 Nm',
        transmision: 'DSG 6 velocidades',
        traccion: 'Delantera',
        aceleracion: '7.7 s (0-100 km/h)',
        velocidadMaxima: '205 km/h'
      },
      bateria: {
        capacidad: '13 kWh',
        autonomiaElectrica: '49 km WLTP',
        tiempoCarga: '3h 50min (wallbox)',
        cargaAC: '3.6 kW',
        consumoMixto: '1.7 l/100km',
        emisionesCO2: '38 g/km'
      },
      dimensiones: {
        longitud: '4.735 mm',
        anchura: '1.839 mm',
        altura: '1.674 mm',
        batalla: '2.790 mm',
        maletero: '610 - 1.775 litros',
        peso: '1.847 kg',
        plazas: '7',
        puertas: '5'
      }
    },
    equipamiento: {
      exterior: ['Faros Full LED', 'Pilotos LED', 'Llantas 18"', 'Barras de techo', 'Portón eléctrico', 'Cristales tintados'],
      interior: ['Digital Cockpit', 'Pantalla 9.2"', 'Climatizador trizona', 'Volante multifunción', '3ª fila de asientos', 'Iluminación ambiental'],
      tecnologia: ['SEAT Connect', 'Apple CarPlay / Android Auto', 'Navegación', 'Sistema de sonido', 'Carga inalámbrica', 'Asistente de voz'],
      seguridad: ['Front Assist', 'Lane Assist', 'ACC', 'Park Assist', '7 airbags', 'Cámara 360°']
    },
    ventajas: [
      { icon: 'ri-group-line', title: '7 plazas reales', desc: 'Espacio para toda la familia con tercera fila de asientos' },
      { icon: 'ri-flashlight-line', title: 'Modo eléctrico', desc: 'Hasta 49 km en modo 100% eléctrico para uso urbano' },
      { icon: 'ri-leaf-line', title: 'Etiqueta CERO', desc: 'SUV grande con acceso a zonas de bajas emisiones' },
      { icon: 'ri-space', title: 'Maletero enorme', desc: 'Hasta 1.775 litros con los asientos abatidos' }
    ],
    related: [
      { slug: 'seat-leon-ehybrid', name: 'León e-HYBRID', price: '349€/mes', image: 'https://readdy.ai/api/search-image?query=SEAT%20Leon%20e-HYBRID%20plug-in%20hybrid%20in%20red%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20compact%20sporty%20hatchback&width=400&height=250&seq=seat-leon-rel3&orientation=landscape' },
      { slug: 'seat-leon-sportstourer-ehybrid', name: 'León Sportstourer e-HYBRID', price: '369€/mes', image: 'https://readdy.ai/api/search-image?query=SEAT%20Leon%20Sportstourer%20e-HYBRID%20plug-in%20hybrid%20wagon%20in%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20family%20estate%20car&width=400&height=250&seq=seat-leon-st-rel2&orientation=landscape' },
      { slug: 'volkswagen-tiguan-ehybrid', name: 'VW Tiguan eHybrid', price: '479€/mes', image: 'https://readdy.ai/api/search-image?query=Volkswagen%20Tiguan%20eHybrid%20plug-in%20hybrid%20SUV%20in%20gray%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20family%20crossover&width=400&height=250&seq=vw-tiguan-rel4&orientation=landscape' }
    ]
  },
  'cupra-leon-ehybrid': {
    brand: 'CUPRA',
    name: 'León e-HYBRID',
    type: 'Híbrido Enchufable',
    price: '399€',
    pvp: '43.100€',
    badge: 'Deportivo',
    tagline: 'Compacto deportivo híbrido · 245 CV · Etiqueta CERO',
    image: 'https://readdy.ai/api/search-image?query=CUPRA%20Leon%20e-HYBRID%20plug-in%20hybrid%20in%20copper%20bronze%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20performance%20hatchback&width=800&height=500&seq=cupra-leon-detail&orientation=landscape',
    gallery: [
      'https://readdy.ai/api/search-image?query=CUPRA%20Leon%20e-HYBRID%20plug-in%20hybrid%20in%20copper%20bronze%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20performance%20hatchback&width=900&height=600&seq=cupra-leon-g1&orientation=landscape',
      'https://readdy.ai/api/search-image?query=CUPRA%20Leon%20e-HYBRID%20rear%20view%20copper%20bronze%20studio%20background%20showing%20sporty%20design&width=900&height=600&seq=cupra-leon-g2&orientation=landscape',
      'https://readdy.ai/api/search-image?query=CUPRA%20Leon%20e-HYBRID%20interior%20sporty%20cockpit%20bucket%20seats%20copper%20accents&width=900&height=600&seq=cupra-leon-g3&orientation=landscape',
      'https://readdy.ai/api/search-image?query=CUPRA%20Leon%20e-HYBRID%20side%20profile%20copper%20bronze%20showing%20sporty%20hatchback%20design&width=900&height=600&seq=cupra-leon-g4&orientation=landscape'
    ],
    specs: {
      motor: {
        motorizacion: '1.4 TSI + Motor eléctrico',
        potenciaCombinada: '245 CV',
        parMaximo: '400 Nm',
        transmision: 'DSG 6 velocidades',
        traccion: 'Delantera',
        aceleracion: '6.7 s (0-100 km/h)',
        velocidadMaxima: '225 km/h'
      },
      bateria: {
        capacidad: '13 kWh',
        autonomiaElectrica: '63 km WLTP',
        tiempoCarga: '3h 40min (wallbox)',
        cargaAC: '3.6 kW',
        consumoMixto: '1.3 l/100km',
        emisionesCO2: '30 g/km'
      },
      dimensiones: {
        longitud: '4.398 mm',
        anchura: '1.800 mm',
        altura: '1.442 mm',
        batalla: '2.686 mm',
        maletero: '270 - 1.143 litros',
        peso: '1.620 kg',
        plazas: '5',
        puertas: '5'
      }
    },
    equipamiento: {
      exterior: ['Faros Full LED', 'Pilotos LED', 'Llantas 18" CUPRA', 'Difusor trasero', 'Escapes cuádruples', 'Pintura mate disponible'],
      interior: ['Digital Cockpit', 'Pantalla 10"', 'Asientos deportivos CUPRA', 'Volante CUPRA', 'Pedales en aluminio', 'Iluminación ambiental cobre'],
      tecnologia: ['CUPRA Connect', 'Apple CarPlay / Android Auto', 'Navegación', 'Beats Audio', 'Carga inalámbrica', 'Asistente de voz'],
      seguridad: ['Front Assist', 'Lane Assist', 'ACC', 'DCC', '7 airbags', 'Cámara trasera']
    },
    ventajas: [
      { icon: 'ri-speed-line', title: 'ADN deportivo', desc: '245 CV y 0-100 en 6.7 segundos con carácter CUPRA' },
      { icon: 'ri-flashlight-line', title: 'Modo eléctrico', desc: 'Hasta 63 km en modo 100% eléctrico para uso urbano' },
      { icon: 'ri-leaf-line', title: 'Etiqueta CERO', desc: 'Deportividad sin renunciar a ventajas fiscales' },
      { icon: 'ri-palette-line', title: 'Diseño exclusivo', desc: 'Estética CUPRA con detalles en cobre distintivos' }
    ],
    related: [
      { slug: 'cupra-formentor-ehybrid', name: 'Formentor e-HYBRID', price: '479€/mes', image: 'https://readdy.ai/api/search-image?query=CUPRA%20Formentor%20e-HYBRID%20plug-in%20hybrid%20coupe%20SUV%20in%20dark%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20crossover&width=400&height=250&seq=cupra-formentor-rel&orientation=landscape' },
      { slug: 'cupra-formentor-vz-ehybrid', name: 'Formentor VZ e-HYBRID', price: '549€/mes', image: 'https://readdy.ai/api/search-image?query=CUPRA%20Formentor%20VZ%20e-HYBRID%20plug-in%20hybrid%20performance%20SUV%20in%20matte%20gray%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20high%20performance%20crossover&width=400&height=250&seq=cupra-formentor-vz-rel&orientation=landscape' },
      { slug: 'seat-leon-ehybrid', name: 'SEAT León e-HYBRID', price: '349€/mes', image: 'https://readdy.ai/api/search-image?query=SEAT%20Leon%20e-HYBRID%20plug-in%20hybrid%20in%20red%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20compact%20sporty%20hatchback&width=400&height=250&seq=seat-leon-rel4&orientation=landscape' }
    ]
  },
  'cupra-formentor-ehybrid': {
    brand: 'CUPRA',
    name: 'Formentor e-HYBRID',
    type: 'Híbrido Enchufable',
    price: '479€',
    pvp: '51.700€',
    badge: 'SUV Coupé',
    tagline: 'SUV Coupé deportivo híbrido · 245 CV · Etiqueta CERO',
    image: 'https://readdy.ai/api/search-image?query=CUPRA%20Formentor%20e-HYBRID%20plug-in%20hybrid%20coupe%20SUV%20in%20dark%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20crossover&width=800&height=500&seq=cupra-formentor-detail&orientation=landscape',
    gallery: [
      'https://readdy.ai/api/search-image?query=CUPRA%20Formentor%20e-HYBRID%20plug-in%20hybrid%20coupe%20SUV%20in%20dark%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20crossover&width=900&height=600&seq=cupra-formentor-g1&orientation=landscape',
      'https://readdy.ai/api/search-image?query=CUPRA%20Formentor%20e-HYBRID%20rear%20view%20dark%20metallic%20studio%20background%20showing%20coupe%20roofline&width=900&height=600&seq=cupra-formentor-g2&orientation=landscape',
      'https://readdy.ai/api/search-image?query=CUPRA%20Formentor%20e-HYBRID%20interior%20sporty%20cockpit%20bucket%20seats%20copper%20accents&width=900&height=600&seq=cupra-formentor-g3&orientation=landscape',
      'https://readdy.ai/api/search-image?query=CUPRA%20Formentor%20e-HYBRID%20side%20profile%20dark%20metallic%20showing%20SUV%20coupe%20silhouette&width=900&height=600&seq=cupra-formentor-g4&orientation=landscape'
    ],
    specs: {
      motor: {
        motorizacion: '1.4 TSI + Motor eléctrico',
        potenciaCombinada: '245 CV',
        parMaximo: '400 Nm',
        transmision: 'DSG 6 velocidades',
        traccion: 'Delantera',
        aceleracion: '7.0 s (0-100 km/h)',
        velocidadMaxima: '205 km/h'
      },
      bateria: {
        capacidad: '12.8 kWh',
        autonomiaElectrica: '55 km WLTP',
        tiempoCarga: '3h 40min (wallbox)',
        cargaAC: '3.6 kW',
        consumoMixto: '1.4 l/100km',
        emisionesCO2: '32 g/km'
      },
      dimensiones: {
        longitud: '4.450 mm',
        anchura: '1.839 mm',
        altura: '1.511 mm',
        batalla: '2.680 mm',
        maletero: '345 - 1.292 litros',
        peso: '1.730 kg',
        plazas: '5',
        puertas: '5'
      }
    },
    equipamiento: {
      exterior: ['Faros Full LED', 'Pilotos LED', 'Llantas 19" CUPRA', 'Difusor trasero', 'Escapes cuádruples', 'Techo panorámico'],
      interior: ['Digital Cockpit', 'Pantalla 12"', 'Asientos deportivos CUPRA', 'Volante CUPRA', 'Pedales en aluminio', 'Iluminación ambiental cobre'],
      tecnologia: ['CUPRA Connect', 'Apple CarPlay / Android Auto', 'Navegación', 'Beats Audio', 'Carga inalámbrica', 'Asistente de voz'],
      seguridad: ['Front Assist', 'Lane Assist', 'ACC', 'DCC', '7 airbags', 'Cámara 360°']
    },
    ventajas: [
      { icon: 'ri-palette-line', title: 'Diseño único', desc: 'El primer modelo 100% CUPRA con diseño SUV coupé exclusivo' },
      { icon: 'ri-flashlight-line', title: 'Modo eléctrico', desc: 'Hasta 55 km en modo 100% eléctrico para uso urbano' },
      { icon: 'ri-leaf-line', title: 'Etiqueta CERO', desc: 'Deportividad sin renunciar a ventajas fiscales' },
      { icon: 'ri-speed-line', title: 'Prestaciones', desc: '245 CV combinados para una conducción emocionante' }
    ],
    related: [
      { slug: 'cupra-leon-ehybrid', name: 'León e-HYBRID', price: '399€/mes', image: 'https://readdy.ai/api/search-image?query=CUPRA%20Leon%20e-HYBRID%20plug-in%20hybrid%20in%20copper%20bronze%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20performance%20hatchback&width=400&height=250&seq=cupra-leon-rel3&orientation=landscape' },
      { slug: 'cupra-formentor-vz-ehybrid', name: 'Formentor VZ e-HYBRID', price: '549€/mes', image: 'https://readdy.ai/api/search-image?query=CUPRA%20Formentor%20VZ%20e-HYBRID%20plug-in%20hybrid%20performance%20SUV%20in%20matte%20gray%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20high%20performance%20crossover&width=400&height=250&seq=cupra-formentor-vz-rel2&orientation=landscape' },
      { slug: 'volkswagen-tiguan-ehybrid', name: 'VW Tiguan eHybrid', price: '479€/mes', image: 'https://readdy.ai/api/search-image?query=Volkswagen%20Tiguan%20eHybrid%20plug-in%20hybrid%20SUV%20in%20gray%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20family%20crossover&width=400&height=250&seq=vw-tiguan-rel5&orientation=landscape' }
    ]
  },
  'cupra-formentor-vz-ehybrid': {
    brand: 'CUPRA',
    name: 'Formentor VZ e-HYBRID',
    type: 'Híbrido Enchufable',
    price: '549€',
    pvp: '59.300€',
    badge: 'Máxima potencia',
    tagline: 'SUV Coupé deportivo híbrido · 245 CV · Etiqueta CERO',
    image: 'https://readdy.ai/api/search-image?query=CUPRA%20Formentor%20VZ%20e-HYBRID%20plug-in%20hybrid%20performance%20SUV%20in%20matte%20gray%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20high%20performance%20crossover&width=800&height=500&seq=cupra-formentor-vz-detail&orientation=landscape',
    gallery: [
      'https://readdy.ai/api/search-image?query=CUPRA%20Formentor%20VZ%20e-HYBRID%20plug-in%20hybrid%20performance%20SUV%20in%20matte%20gray%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20high%20performance%20crossover&width=900&height=600&seq=cupra-formentor-vz-g1&orientation=landscape',
      'https://readdy.ai/api/search-image?query=CUPRA%20Formentor%20VZ%20e-HYBRID%20rear%20view%20matte%20gray%20studio%20background%20showing%20sporty%20design&width=900&height=600&seq=cupra-formentor-vz-g2&orientation=landscape',
      'https://readdy.ai/api/search-image?query=CUPRA%20Formentor%20VZ%20e-HYBRID%20interior%20racing%20cockpit%20bucket%20seats%20copper%20accents&width=900&height=600&seq=cupra-formentor-vz-g3&orientation=landscape',
      'https://readdy.ai/api/search-image?query=CUPRA%20Formentor%20VZ%20e-HYBRID%20side%20profile%20matte%20gray%20showing%20SUV%20coupe%20silhouette&width=900&height=600&seq=cupra-formentor-vz-g4&orientation=landscape'
    ],
    specs: {
      motor: {
        motorizacion: '1.4 TSI + Motor eléctrico',
        potenciaCombinada: '245 CV',
        parMaximo: '400 Nm',
        transmision: 'DSG 6 velocidades',
        traccion: 'Delantera',
        aceleracion: '7.0 s (0-100 km/h)',
        velocidadMaxima: '205 km/h'
      },
      bateria: {
        capacidad: '12.8 kWh',
        autonomiaElectrica: '58 km WLTP',
        tiempoCarga: '3h 40min (wallbox)',
        cargaAC: '3.6 kW',
        consumoMixto: '1.5 l/100km',
        emisionesCO2: '34 g/km'
      },
      dimensiones: {
        longitud: '4.450 mm',
        anchura: '1.839 mm',
        altura: '1.511 mm',
        batalla: '2.680 mm',
        maletero: '345 - 1.292 litros',
        peso: '1.760 kg',
        plazas: '5',
        puertas: '5'
      }
    },
    equipamiento: {
      exterior: ['Faros Full LED Matrix', 'Pilotos LED', 'Llantas 19" VZ', 'Difusor trasero VZ', 'Escapes Akrapovič', 'Pintura mate exclusiva'],
      interior: ['Digital Cockpit', 'Pantalla 12"', 'Asientos CUPBucket', 'Volante CUPRA VZ', 'Pedales en aluminio', 'Iluminación ambiental cobre'],
      tecnologia: ['CUPRA Connect Plus', 'Apple CarPlay / Android Auto', 'Navegación', 'Beats Audio Premium', 'Carga inalámbrica', 'Head-up Display'],
      seguridad: ['Front Assist', 'Lane Assist', 'ACC', 'DCC Sport', '7 airbags', 'Cámara 360°']
    },
    ventajas: [
      { icon: 'ri-vip-crown-line', title: 'Equipamiento VZ', desc: 'La versión más equipada y exclusiva del Formentor' },
      { icon: 'ri-steering-2-line', title: 'Chasis deportivo', desc: 'Suspensión DCC Sport y configuración específica' },
      { icon: 'ri-leaf-line', title: 'Etiqueta CERO', desc: 'Máximas prestaciones con ventajas fiscales' },
      { icon: 'ri-sound-module-line', title: 'Sonido Akrapovič', desc: 'Escapes de titanio con sonido deportivo exclusivo' }
    ],
    related: [
      { slug: 'cupra-formentor-ehybrid', name: 'Formentor e-HYBRID', price: '479€/mes', image: 'https://readdy.ai/api/search-image?query=CUPRA%20Formentor%20e-HYBRID%20plug-in%20hybrid%20coupe%20SUV%20in%20dark%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20crossover&width=400&height=250&seq=cupra-formentor-rel2&orientation=landscape' },
      { slug: 'cupra-leon-ehybrid', name: 'León e-HYBRID', price: '399€/mes', image: 'https://readdy.ai/api/search-image?query=CUPRA%20Leon%20e-HYBRID%20plug-in%20hybrid%20in%20copper%20bronze%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20performance%20hatchback&width=400&height=250&seq=cupra-leon-rel4&orientation=landscape' },
      { slug: 'audi-q5-tfsi-e', name: 'Audi Q5 TFSI e', price: '649€/mes', image: 'https://readdy.ai/api/search-image?query=Audi%20Q5%20TFSI%20e%20quattro%20plug-in%20hybrid%20SUV%20in%20dark%20blue%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20premium%20crossover&width=400&height=250&seq=audi-q5-rel4&orientation=landscape' }
    ]
  },
  'skoda-octavia-iv': {
    brand: 'Skoda',
    name: 'Octavia iV',
    type: 'Híbrido Enchufable',
    price: '359€',
    pvp: '38.800€',
    badge: 'Berlina eficiente',
    tagline: 'Berlina híbrida práctica · 204 CV · Etiqueta CERO',
    image: 'https://readdy.ai/api/search-image?query=Skoda%20Octavia%20iV%20plug-in%20hybrid%20sedan%20in%20silver%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20practical%20family%20car&width=800&height=500&seq=skoda-octavia-detail&orientation=landscape',
    gallery: [
      'https://readdy.ai/api/search-image?query=Skoda%20Octavia%20iV%20plug-in%20hybrid%20sedan%20in%20silver%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20practical%20family%20car&width=900&height=600&seq=skoda-octavia-g1&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Skoda%20Octavia%20iV%20rear%20view%20silver%20studio%20background%20showing%20LED%20lights&width=900&height=600&seq=skoda-octavia-g2&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Skoda%20Octavia%20iV%20interior%20spacious%20cabin%20digital%20displays&width=900&height=600&seq=skoda-octavia-g3&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Skoda%20Octavia%20iV%20side%20profile%20silver%20showing%20sedan%20proportions&width=900&height=600&seq=skoda-octavia-g4&orientation=landscape'
    ],
    specs: {
      motor: {
        motorizacion: '1.4 TSI + Motor eléctrico',
        potenciaCombinada: '204 CV',
        parMaximo: '350 Nm',
        transmision: 'DSG 6 velocidades',
        traccion: 'Delantera',
        aceleracion: '7.7 s (0-100 km/h)',
        velocidadMaxima: '220 km/h'
      },
      bateria: {
        capacidad: '13 kWh',
        autonomiaElectrica: '62 km WLTP',
        tiempoCarga: '3h 40min (wallbox)',
        cargaAC: '3.6 kW',
        consumoMixto: '1.2 l/100km',
        emisionesCO2: '28 g/km'
      },
      dimensiones: {
        longitud: '4.689 mm',
        anchura: '1.829 mm',
        altura: '1.469 mm',
        batalla: '2.686 mm',
        maletero: '450 - 1.455 litros',
        peso: '1.620 kg',
        plazas: '5',
        puertas: '5'
      }
    },
    equipamiento: {
      exterior: ['Faros Full LED', 'Pilotos LED', 'Llantas 17"', 'Retrovisores eléctricos', 'Cristales tintados', 'Sensor de lluvia'],
      interior: ['Digital Cockpit', 'Pantalla 10"', 'Climatizador bizona', 'Volante multifunción', 'Asientos ergonómicos', 'Iluminación ambiental'],
      tecnologia: ['Skoda Connect', 'Apple CarPlay / Android Auto', 'Navegación', 'Sistema de sonido', 'Carga inalámbrica', 'Asistente de voz'],
      seguridad: ['Front Assist', 'Lane Assist', 'ACC', 'Park Assist', '9 airbags', 'Cámara trasera']
    },
    ventajas: [
      { icon: 'ri-space', title: 'Espacio interior', desc: 'Referencia en espacio interior en su categoría' },
      { icon: 'ri-flashlight-line', title: 'Gran autonomía EV', desc: 'Hasta 62 km en modo eléctrico para uso diario' },
      { icon: 'ri-leaf-line', title: 'Etiqueta CERO', desc: 'Acceso libre a zonas de bajas emisiones y ventajas fiscales' },
      { icon: 'ri-money-euro-circle-line', title: 'Relación calidad-precio', desc: 'Máximo equipamiento al mejor precio' }
    ],
    related: [
      { slug: 'skoda-octavia-combi-iv', name: 'Octavia Combi iV', price: '379€/mes', image: 'https://readdy.ai/api/search-image?query=Skoda%20Octavia%20Combi%20iV%20plug-in%20hybrid%20wagon%20in%20green%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20spacious%20estate%20car&width=400&height=250&seq=skoda-octavia-combi-rel2&orientation=landscape' },
      { slug: 'skoda-superb-iv', name: 'Superb iV', price: '499€/mes', image: 'https://readdy.ai/api/search-image?query=Skoda%20Superb%20iV%20plug-in%20hybrid%20executive%20sedan%20in%20black%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20luxury%20business%20car&width=400&height=250&seq=skoda-superb-rel&orientation=landscape' },
      { slug: 'seat-leon-ehybrid', name: 'SEAT León e-HYBRID', price: '349€/mes', image: 'https://readdy.ai/api/search-image?query=SEAT%20Leon%20e-HYBRID%20plug-in%20hybrid%20in%20red%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20compact%20sporty%20hatchback&width=400&height=250&seq=seat-leon-rel5&orientation=landscape' }
    ]
  },
  'skoda-octavia-combi-iv': {
    brand: 'Skoda',
    name: 'Octavia Combi iV',
    type: 'Híbrido Enchufable',
    price: '379€',
    pvp: '40.900€',
    badge: 'Familiar espacioso',
    tagline: 'Familiar híbrido práctico · 204 CV · Etiqueta CERO',
    image: 'https://readdy.ai/api/search-image?query=Skoda%20Octavia%20Combi%20iV%20plug-in%20hybrid%20wagon%20in%20green%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20spacious%20estate%20car&width=800&height=500&seq=skoda-octavia-combi-detail&orientation=landscape',
    gallery: [
      'https://readdy.ai/api/search-image?query=Skoda%20Octavia%20Combi%20iV%20plug-in%20hybrid%20wagon%20in%20green%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20spacious%20estate%20car&width=900&height=600&seq=skoda-octavia-combi-g1&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Skoda%20Octavia%20Combi%20iV%20rear%20view%20green%20metallic%20studio%20background%20showing%20wagon%20design&width=900&height=600&seq=skoda-octavia-combi-g2&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Skoda%20Octavia%20Combi%20iV%20interior%20spacious%20cabin%20large%20boot&width=900&height=600&seq=skoda-octavia-combi-g3&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Skoda%20Octavia%20Combi%20iV%20side%20profile%20green%20metallic%20showing%20estate%20proportions&width=900&height=600&seq=skoda-octavia-combi-g4&orientation=landscape'
    ],
    specs: {
      motor: {
        motorizacion: '1.4 TSI + Motor eléctrico',
        potenciaCombinada: '204 CV',
        parMaximo: '350 Nm',
        transmision: 'DSG 6 velocidades',
        traccion: 'Delantera',
        aceleracion: '7.8 s (0-100 km/h)',
        velocidadMaxima: '218 km/h'
      },
      bateria: {
        capacidad: '13 kWh',
        autonomiaElectrica: '63 km WLTP',
        tiempoCarga: '3h 40min (wallbox)',
        cargaAC: '3.6 kW',
        consumoMixto: '1.3 l/100km',
        emisionesCO2: '29 g/km'
      },
      dimensiones: {
        longitud: '4.689 mm',
        anchura: '1.829 mm',
        altura: '1.468 mm',
        batalla: '2.686 mm',
        maletero: '490 - 1.555 litros',
        peso: '1.660 kg',
        plazas: '5',
        puertas: '5'
      }
    },
    equipamiento: {
      exterior: ['Faros Full LED', 'Pilotos LED', 'Llantas 17"', 'Barras de techo', 'Portón eléctrico', 'Cristales tintados'],
      interior: ['Digital Cockpit', 'Pantalla 10"', 'Climatizador automático', 'Volante multifunción', 'Asientos ergonómicos', 'Iluminación ambiental'],
      tecnologia: ['Skoda Connect', 'Apple CarPlay / Android Auto', 'Navegación', 'Sistema de sonido', 'Carga inalámbrica', 'Asistente de voz'],
      seguridad: ['Front Assist', 'Lane Assist', 'ACC', 'Park Assist', '9 airbags', 'Cámara trasera']
    },
    ventajas: [
      { icon: 'ri-space', title: 'Maletero enorme', desc: '490 litros de maletero, el más grande de su categoría' },
      { icon: 'ri-flashlight-line', title: 'Gran autonomía EV', desc: 'Hasta 63 km en modo eléctrico para uso diario' },
      { icon: 'ri-leaf-line', title: 'Etiqueta CERO', desc: 'Acceso libre a zonas de bajas emisiones y ventajas fiscales' },
      { icon: 'ri-tools-line', title: 'Simply Clever', desc: 'Soluciones prácticas exclusivas de Škoda' }
    ],
    related: [
      { slug: 'skoda-octavia-iv', name: 'Octavia iV', price: '359€/mes', image: 'https://readdy.ai/api/search-image?query=Skoda%20Octavia%20iV%20plug-in%20hybrid%20sedan%20in%20silver%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20practical%20family%20car&width=400&height=250&seq=skoda-octavia-rel&orientation=landscape' },
      { slug: 'skoda-superb-iv', name: 'Superb iV', price: '499€/mes', image: 'https://readdy.ai/api/search-image?query=Skoda%20Superb%20iV%20plug-in%20hybrid%20executive%20sedan%20in%20black%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20luxury%20business%20car&width=400&height=250&seq=skoda-superb-rel2&orientation=landscape' },
      { slug: 'seat-leon-sportstourer-ehybrid', name: 'SEAT León Sportstourer', price: '369€/mes', image: 'https://readdy.ai/api/search-image?query=SEAT%20Leon%20Sportstourer%20e-HYBRID%20plug-in%20hybrid%20wagon%20in%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20family%20estate%20car&width=400&height=250&seq=seat-leon-st-rel3&orientation=landscape' }
    ]
  },
  'skoda-superb-iv': {
    brand: 'Skoda',
    name: 'Superb iV',
    type: 'Híbrido Enchufable',
    price: '499€',
    pvp: '53.900€',
    badge: 'Berlina premium',
    tagline: 'Berlina ejecutiva híbrida · 218 CV · Etiqueta CERO',
    image: 'https://readdy.ai/api/search-image?query=Skoda%20Superb%20iV%20plug-in%20hybrid%20executive%20sedan%20in%20black%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20luxury%20business%20car&width=800&height=500&seq=skoda-superb-detail&orientation=landscape',
    gallery: [
      'https://readdy.ai/api/search-image?query=Skoda%20Superb%20iV%20plug-in%20hybrid%20executive%20sedan%20in%20black%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20luxury%20business%20car&width=900&height=600&seq=skoda-superb-g1&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Skoda%20Superb%20iV%20rear%20view%20black%20studio%20background%20showing%20premium%20LED%20lights&width=900&height=600&seq=skoda-superb-g2&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Skoda%20Superb%20iV%20interior%20luxury%20cabin%20executive%20rear%20seats&width=900&height=600&seq=skoda-superb-g3&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Skoda%20Superb%20iV%20side%20profile%20black%20showing%20executive%20sedan%20proportions&width=900&height=600&seq=skoda-superb-g4&orientation=landscape'
    ],
    specs: {
      motor: {
        motorizacion: '1.4 TSI + Motor eléctrico',
        potenciaCombinada: '218 CV',
        parMaximo: '400 Nm',
        transmision: 'DSG 6 velocidades',
        traccion: 'Delantera',
        aceleracion: '7.7 s (0-100 km/h)',
        velocidadMaxima: '224 km/h'
      },
      bateria: {
        capacidad: '13 kWh',
        autonomiaElectrica: '55 km WLTP',
        tiempoCarga: '3h 50min (wallbox)',
        cargaAC: '3.6 kW',
        consumoMixto: '1.5 l/100km',
        emisionesCO2: '35 g/km'
      },
      dimensiones: {
        longitud: '4.869 mm',
        anchura: '1.864 mm',
        altura: '1.469 mm',
        batalla: '2.841 mm',
        maletero: '485 - 1.610 litros',
        peso: '1.720 kg',
        plazas: '5',
        puertas: '5'
      }
    },
    equipamiento: {
      exterior: ['Faros Full LED Matrix', 'Pilotos LED', 'Llantas 18"', 'Cristales acústicos', 'Portón eléctrico', 'Sensor de lluvia'],
      interior: ['Digital Cockpit', 'Pantalla 10"', 'Climatizador trizona', 'Volante multifunción', 'Asientos ergonómicos', 'Iluminación ambiental'],
      tecnologia: ['Skoda Connect Plus', 'Apple CarPlay / Android Auto', 'Navegación', 'Canton Sound', 'Carga inalámbrica', 'Head-up Display'],
      seguridad: ['Front Assist', 'Lane Assist', 'ACC predictivo', 'Park Assist', '9 airbags', 'Cámara 360°']
    },
    ventajas: [
      { icon: 'ri-vip-crown-line', title: 'Espacio ejecutivo', desc: 'El mayor espacio interior de su categoría, ideal para directivos' },
      { icon: 'ri-flashlight-line', title: 'Modo eléctrico', desc: 'Hasta 55 km en modo 100% eléctrico para uso urbano' },
      { icon: 'ri-leaf-line', title: 'Etiqueta CERO', desc: 'Berlina ejecutiva con acceso a todas las zonas' },
      { icon: 'ri-money-euro-circle-line', title: 'Valor excepcional', desc: 'Equipamiento premium a precio competitivo' }
    ],
    related: [
      { slug: 'skoda-octavia-iv', name: 'Octavia iV', price: '359€/mes', image: 'https://readdy.ai/api/search-image?query=Skoda%20Octavia%20iV%20plug-in%20hybrid%20sedan%20in%20silver%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20practical%20family%20car&width=400&height=250&seq=skoda-octavia-rel2&orientation=landscape' },
      { slug: 'skoda-octavia-combi-iv', name: 'Octavia Combi iV', price: '379€/mes', image: 'https://readdy.ai/api/search-image?query=Skoda%20Octavia%20Combi%20iV%20plug-in%20hybrid%20wagon%20in%20green%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20spacious%20estate%20car&width=400&height=250&seq=skoda-octavia-combi-rel3&orientation=landscape' },
      { slug: 'audi-a3-tfsi-e', name: 'Audi A3 TFSI e', price: '429€/mes', image: 'https://readdy.ai/api/search-image?query=Audi%20A3%20Sportback%20TFSI%20e%20plug-in%20hybrid%20in%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20premium%20compact%20hatchback&width=400&height=250&seq=audi-a3-rel3&orientation=landscape' }
    ]
  }
};

interface VehicleDetailPageProps {
  slug: string;
}

export default function VehicleDetailPage({ slug }: VehicleDetailPageProps) {
  const [selectedImage, setSelectedImage] = useState(0);
  const [selectedKm, setSelectedKm] = useState('15000');
  const [selectedMonths, setSelectedMonths] = useState('48');
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);

  const vehicle = hybridVehicles[slug];

  if (!vehicle) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Vehículo no encontrado</h1>
          <Link href="/promociones-hibridos" className="text-[#ad023b] hover:underline">
            Volver a vehículos híbridos
          </Link>
        </div>
      </div>
    );
  }

  const faqs = [
    { q: '¿Qué incluye exactamente la cuota de renting?', a: 'La cuota incluye mantenimiento oficial, seguro a todo riesgo, impuestos, asistencia en carretera 24h y cambio de neumáticos por desgaste.' },
    { q: '¿Puedo personalizar el equipamiento del vehículo?', a: 'Sí, puedes añadir opcionales y packs de equipamiento. Contacta con nosotros para configurar tu vehículo ideal.' },
    { q: '¿Qué ocurre si supero el kilometraje contratado?', a: 'El exceso de kilometraje se factura según tarifa vigente. Consulta con tu asesor las tarifas aplicables.' },
    { q: '¿Necesito instalar un punto de carga en casa?', a: 'Es recomendable para aprovechar al máximo el modo eléctrico. Podemos asesorarte sobre la instalación.' },
    { q: '¿El renting es deducible fiscalmente para mi empresa?', a: 'Sí, la cuota de renting es 100% deducible como gasto para empresas y autónomos.' }
  ];

  return (
    <div className="bg-white">
      <section className="relative bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 py-16 overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 w-64 h-64 bg-blue-500 rounded-full blur-3xl"></div>
          <div className="absolute bottom-10 right-10 w-64 h-64 bg-blue-500 rounded-full blur-3xl"></div>
        </div>
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="mb-6">
            <Link href="/promociones-hibridos" className="inline-flex items-center gap-2 text-white/80 hover:text-white transition-colors cursor-pointer">
              <i className="ri-arrow-left-line"></i>
              Volver a vehículos híbridos
            </Link>
          </div>
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-block px-4 py-2 bg-blue-500/20 backdrop-blur-sm text-blue-400 text-sm font-bold rounded-full mb-6 border border-blue-500/30">
                <i className="ri-plug-line mr-2"></i>Híbrido Enchufable · Etiqueta CERO
              </div>
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 leading-tight">
                {vehicle.brand} {vehicle.name}
              </h1>
              <p className="text-xl text-white/90 mb-8">{vehicle.tagline}</p>
              <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6 mb-8">
                <div className="text-sm text-white/80 mb-2">Renting desde</div>
                <div className="text-5xl font-bold text-white mb-2">{vehicle.price}<span className="text-2xl">/mes</span></div>
                <div className="text-sm text-white/70">IVA incluido · 48 meses · 15.000 km/año</div>
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <a href="#configurador" className="inline-flex items-center justify-center gap-2 bg-blue-500 text-white px-8 py-4 rounded-lg font-bold hover:bg-blue-600 transition-all shadow-xl cursor-pointer whitespace-nowrap">
                  <i className="ri-settings-3-line"></i>
                  Personalizar cuota
                </a>
                <a href="https://wa.me/34955034600" target="_blank" rel="noopener noreferrer" className="inline-flex items-center justify-center gap-2 bg-[#25D366] text-white px-8 py-4 rounded-lg font-bold hover:bg-[#20BD5A] transition-all shadow-xl cursor-pointer whitespace-nowrap">
                  <i className="ri-whatsapp-line text-xl"></i>
                  Hablar con un asesor
                </a>
              </div>
            </div>
            <div className="relative">
              <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10">
                <img
                  alt={`${vehicle.brand} ${vehicle.name}`}
                  className="w-full h-auto rounded-lg"
                  src={vehicle.image}
                />
              </div>
              <div className="absolute top-4 right-4 bg-[#ad023b] text-white px-4 py-2 rounded-full text-sm font-bold shadow-lg">
                {vehicle.badge}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-6 py-12">
        <div className="bg-slate-50 rounded-2xl p-6">
          <div className="w-full h-[400px] md:h-[500px] bg-white rounded-xl overflow-hidden mb-4">
            <img
              alt={`${vehicle.brand} ${vehicle.name}`}
              className="w-full h-full object-contain"
              src={vehicle.gallery[selectedImage]}
            />
          </div>
          <div className="grid grid-cols-4 gap-3">
            {vehicle.gallery.map((img: string, idx: number) => (
              <button
                key={idx}
                onClick={() => setSelectedImage(idx)}
                className={`w-full h-20 md:h-24 rounded-lg overflow-hidden border-2 transition-all cursor-pointer ${selectedImage === idx ? 'border-blue-500 shadow-lg' : 'border-transparent hover:border-slate-300'}`}
              >
                <img alt={`Vista ${idx + 1}`} className="w-full h-full object-cover" src={img} />
              </button>
            ))}
          </div>
        </div>
      </section>

      <section id="configurador" className="max-w-5xl mx-auto px-6 py-16">
        <div className="bg-gradient-to-br from-slate-50 to-white border-2 border-slate-200 rounded-2xl p-8 md:p-12">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold text-slate-900 mb-3">Configura tu cuota personalizada</h2>
            <p className="text-slate-600">Ajusta el kilometraje y la duración según las necesidades de tu empresa</p>
          </div>
          <div className="grid md:grid-cols-2 gap-8 mb-10">
            <div>
              <label className="block text-sm font-bold text-slate-900 mb-4">
                <i className="ri-speed-line mr-2 text-blue-500"></i>Kilometraje anual
              </label>
              <div className="space-y-3">
                {['10000', '15000', '20000', '25000', '30000'].map((km) => (
                  <button
                    key={km}
                    onClick={() => setSelectedKm(km)}
                    className={`w-full px-6 py-4 rounded-lg font-semibold transition-all cursor-pointer whitespace-nowrap ${selectedKm === km ? 'bg-slate-900 text-white shadow-lg scale-105' : 'bg-white text-slate-700 border-2 border-slate-200 hover:border-slate-900'}`}
                  >
                    {parseInt(km).toLocaleString()} km/año
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-sm font-bold text-slate-900 mb-4">
                <i className="ri-calendar-line mr-2 text-blue-500"></i>Duración del contrato
              </label>
              <div className="space-y-3">
                {['36', '48', '60'].map((months) => (
                  <button
                    key={months}
                    onClick={() => setSelectedMonths(months)}
                    className={`w-full px-6 py-4 rounded-lg font-semibold transition-all cursor-pointer whitespace-nowrap ${selectedMonths === months ? 'bg-slate-900 text-white shadow-lg scale-105' : 'bg-white text-slate-700 border-2 border-slate-200 hover:border-slate-900'}`}
                  >
                    {months} meses
                  </button>
                ))}
              </div>
            </div>
          </div>
          <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-2xl p-8 text-center">
            <div className="text-white/80 text-sm mb-2">Tu cuota personalizada</div>
            <div className="text-6xl font-bold text-white mb-3">{vehicle.price}<span className="text-3xl">/mes</span></div>
            <div className="text-white/70 mb-6">IVA incluido · {selectedMonths} meses · {parseInt(selectedKm).toLocaleString()} km/año</div>
            <p className="text-sm text-white/60 max-w-2xl mx-auto">
              La cuota puede variar según kilometraje y duración del contrato. Esta es una estimación orientativa. Contacta con nosotros para una oferta personalizada definitiva.
            </p>
          </div>
        </div>
      </section>

      <section className="bg-slate-50 py-16">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Qué incluye la cuota de renting</h2>
            <p className="text-lg text-slate-600">Todo lo que necesitas para que tu empresa solo se preocupe de conducir</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: 'ri-tools-line', title: 'Mantenimiento oficial', desc: 'Todas las revisiones, cambios de aceite, filtros y piezas de desgaste en talleres oficiales' },
              { icon: 'ri-shield-check-line', title: 'Seguro a todo riesgo', desc: 'Cobertura completa con franquicia reducida, asistencia en viaje 24h y vehículo de sustitución' },
              { icon: 'ri-steering-2-line', title: 'Neumáticos', desc: 'Cambio de neumáticos por desgaste normal, equilibrado y alineación incluidos' },
              { icon: 'ri-file-text-line', title: 'Impuestos', desc: 'Impuesto de circulación y tasas administrativas incluidas en la cuota mensual' },
              { icon: 'ri-roadster-line', title: 'Asistencia en carretera', desc: 'Servicio 24/7 en toda Europa, grúa, reparaciones de emergencia y gestión de incidencias' },
              { icon: 'ri-money-euro-circle-line', title: '100% deducible', desc: 'La cuota de renting es gasto deducible al 100% para tu empresa, optimizando la fiscalidad' }
            ].map((item, idx) => (
              <div key={idx} className="bg-white rounded-xl p-6 border border-slate-200">
                <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl flex items-center justify-center mb-4">
                  <i className={`${item.icon} text-2xl text-white`}></i>
                </div>
                <h3 className="text-lg font-bold text-slate-900 mb-2">{item.title}</h3>
                <p className="text-slate-600 text-sm">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-6 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Equipamiento de serie</h2>
          <p className="text-lg text-slate-600">Todo lo que incluye el {vehicle.brand} {vehicle.name} de serie</p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {Object.entries(vehicle.equipamiento).map(([category, items]: [string, any]) => (
            <div key={category} className="bg-white border border-slate-200 rounded-xl p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-slate-900 rounded-lg flex items-center justify-center">
                  <i className={`${category === 'exterior' ? 'ri-car-line' : category === 'interior' ? 'ri-steering-line' : category === 'tecnologia' ? 'ri-smartphone-line' : 'ri-shield-star-line'} text-white`}></i>
                </div>
                <h3 className="font-bold text-slate-900 capitalize">{category}</h3>
              </div>
              <ul className="space-y-2 text-sm text-slate-600">
                {items.map((item: string, idx: number) => (
                  <li key={idx} className="flex items-start gap-2">
                    <i className="ri-check-line text-blue-500 mt-0.5"></i>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-slate-50 py-16">
        <div className="max-w-5xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Ficha técnica completa</h2>
            <p className="text-lg text-slate-600">Especificaciones detalladas del {vehicle.brand} {vehicle.name}</p>
          </div>
          <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
            {Object.entries(vehicle.specs).map(([section, specs]: [string, any]) => (
              <div key={section} className="border-b border-slate-200 last:border-b-0">
                <div className="bg-slate-900 px-6 py-4">
                  <h3 className="text-white font-bold flex items-center gap-2">
                    <i className={`${section === 'motor' ? 'ri-dashboard-3-line' : section === 'bateria' ? 'ri-plug-line' : 'ri-ruler-line'}`}></i>
                    {section === 'motor' ? 'Motor y Rendimiento' : section === 'bateria' ? 'Batería y Carga' : 'Dimensiones y Capacidades'}
                  </h3>
                </div>
                <div className="divide-y divide-slate-100">
                  {Object.entries(specs).map(([key, value]: [string, any]) => (
                    <div key={key} className="flex justify-between px-6 py-4">
                      <span className="text-slate-600 capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}</span>
                      <span className="font-semibold text-slate-900">{value}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-gradient-to-br from-blue-600 to-blue-700 py-16">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-white mb-4">Por qué el {vehicle.brand} {vehicle.name} es perfecto para tu empresa</h2>
            <p className="text-lg text-white/80">Ventajas específicas para flotas y uso profesional</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {vehicle.ventajas.map((v: any, idx: number) => (
              <div key={idx} className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-6">
                <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center mb-4">
                  <i className={`${v.icon} text-2xl text-white`}></i>
                </div>
                <h3 className="text-lg font-bold text-white mb-2">{v.title}</h3>
                <p className="text-white/80 text-sm">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="max-w-4xl mx-auto px-6 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Preguntas frecuentes</h2>
          <p className="text-lg text-slate-600">Resolvemos tus dudas sobre el renting del {vehicle.brand} {vehicle.name}</p>
        </div>
        <div className="space-y-4">
          {faqs.map((faq, idx) => (
            <div key={idx} className="bg-white border border-slate-200 rounded-xl overflow-hidden">
              <button
                onClick={() => setExpandedFaq(expandedFaq === idx ? null : idx)}
                className="w-full px-6 py-5 flex items-center justify-between text-left cursor-pointer hover:bg-slate-50 transition-colors"
              >
                <span className="font-semibold text-slate-900 pr-4">{faq.q}</span>
                <i className={`ri-arrow-${expandedFaq === idx ? 'up' : 'down'}-s-line text-2xl text-slate-400 transition-transform`}></i>
              </button>
              {expandedFaq === idx && (
                <div className="px-6 pb-5 text-slate-600">
                  {faq.a}
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      <VehicleContactForm 
        vehicleName={vehicle.name} 
        vehicleBrand={vehicle.brand} 
        accentColor="blue" 
      />

      <section className="max-w-7xl mx-auto px-6 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Otros vehículos híbridos que pueden interesarte</h2>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {vehicle.related.map((rel: any) => (
            <Link
              key={rel.slug}
              href={`/vehiculos/hibridos/${rel.slug}`}
              className="bg-white border-2 border-slate-200 rounded-xl overflow-hidden hover:border-blue-500 transition-all hover:shadow-xl cursor-pointer"
            >
              <div className="w-full h-48 bg-slate-100">
                <img alt={rel.name} className="w-full h-full object-contain" src={rel.image} />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-slate-900 mb-2">{rel.name}</h3>
                <div className="text-2xl font-bold text-blue-600 mb-2">desde {rel.price}</div>
                <p className="text-slate-600 text-sm">Híbrido Enchufable · Etiqueta CERO</p>
              </div>
            </Link>
          ))}
        </div>
        <div className="text-center mt-10">
          <Link href="/promociones-hibridos" className="inline-flex items-center gap-2 text-slate-900 font-bold hover:text-blue-600 transition-colors cursor-pointer">
            Ver todos los vehículos híbridos
            <i className="ri-arrow-right-line"></i>
          </Link>
        </div>
      </section>

      <section className="max-w-5xl mx-auto px-6 py-12">
        <div className="bg-slate-100 rounded-xl p-6">
          <h3 className="font-bold text-slate-900 mb-4 flex items-center gap-2">
            <i className="ri-information-line"></i>
            Condiciones de la oferta
          </h3>
          <div className="text-xs text-slate-600 space-y-2 leading-relaxed">
            <p><strong>Oferta válida para empresas y autónomos.</strong> Cuota mensual de renting operativo, IVA incluido. Oferta sujeta a aprobación crediticia por parte de la entidad financiera.</p>
            <p>La cuota incluye: mantenimiento oficial, seguro a todo riesgo con franquicia, impuesto de circulación, gestión de multas, asistencia en carretera 24h y cambio de neumáticos por desgaste. No incluye combustible ni electricidad.</p>
            <p>Condiciones base: 48 meses de contrato, 15.000 km/año. El exceso de kilometraje se facturará según tarifa vigente. La cuota puede variar en función del color, equipamiento opcional y condiciones de financiación.</p>
            <p>Imágenes no contractuales. El equipamiento puede variar según versión y opciones seleccionadas. Consulta disponibilidad de unidades y plazos de entrega con tu asesor comercial.</p>
          </div>
        </div>
      </section>
    </div>
  );
}
