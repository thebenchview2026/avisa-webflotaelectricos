
import VehicleDetailPage from './VehicleDetailPage';

export async function generateStaticParams() {
  return [
    { slug: 'volkswagen-golf-gte' },
    { slug: 'volkswagen-tiguan-ehybrid' },
    { slug: 'volkswagen-touareg-ehybrid' },
    { slug: 'audi-a3-tfsi-e' },
    { slug: 'audi-q3-tfsi-e' },
    { slug: 'audi-q5-tfsi-e' },
    { slug: 'seat-leon-ehybrid' },
    { slug: 'seat-leon-sportstourer-ehybrid' },
    { slug: 'seat-tarraco-ehybrid' },
    { slug: 'cupra-leon-ehybrid' },
    { slug: 'cupra-formentor-ehybrid' },
    { slug: 'cupra-formentor-vz-ehybrid' },
    { slug: 'skoda-octavia-iv' },
    { slug: 'skoda-octavia-combi-iv' },
    { slug: 'skoda-superb-iv' },
  ];
}

export default function HybridVehiclePage({ params }: { params: { slug: string } }) {
  return <VehicleDetailPage slug={params.slug} />;
}
