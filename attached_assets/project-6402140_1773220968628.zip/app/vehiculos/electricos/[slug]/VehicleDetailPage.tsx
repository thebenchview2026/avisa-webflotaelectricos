'use client';

import { useState } from 'react';
import Link from 'next/link';
import VehicleContactForm from '@/components/VehicleContactForm';

const electricVehicles: Record<string, any> = {
  'volkswagen-id3-pro': {
    brand: 'Volkswagen',
    name: 'ID.3 Pro',
    type: '100% Eléctrico',
    price: '399€',
    pvp: '42.900€',
    badge: 'Más vendido',
    tagline: 'Compacto eléctrico · 204 CV · Etiqueta CERO',
    image: 'https://readdy.ai/api/search-image?query=Volkswagen%20ID3%20electric%20hatchback%20in%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20modern%20compact%20electric%20car&width=800&height=500&seq=vw-id3-detail&orientation=landscape',
    gallery: [
      'https://readdy.ai/api/search-image?query=Volkswagen%20ID3%20electric%20hatchback%20in%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20modern%20compact%20electric%20car&width=900&height=600&seq=vw-id3-g1&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Volkswagen%20ID3%20rear%20view%20white%20color%20studio%20background%20professional%20automotive%20photography%20showing%20LED%20tail%20lights%20and%20sporty%20hatchback%20design&width=900&height=600&seq=vw-id3-g2&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Volkswagen%20ID3%20interior%20dashboard%20digital%20cockpit%20infotainment%20screen%20modern%20minimalist%20design%20premium%20materials&width=900&height=600&seq=vw-id3-g3&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Volkswagen%20ID3%20side%20profile%20white%20color%20studio%20background%20showing%20aerodynamic%20design%20and%20alloy%20wheels&width=900&height=600&seq=vw-id3-g4&orientation=landscape'
    ],
    specs: {
      motor: {
        motorizacion: 'Motor eléctrico trasero',
        potencia: '204 CV (150 kW)',
        parMaximo: '310 Nm',
        transmision: 'Automática 1 velocidad',
        traccion: 'Trasera',
        aceleracion: '7.3 s (0-100 km/h)',
        velocidadMaxima: '160 km/h'
      },
      bateria: {
        capacidad: '58 kWh (neta)',
        autonomia: '426 km WLTP',
        cargaRapidaDC: '30 min (10-80%)',
        cargaAC: '7.2 kW',
        potenciaCargaDC: '120 kW',
        consumo: '14.5 kWh/100km'
      },
      dimensiones: {
        longitud: '4.261 mm',
        anchura: '1.809 mm',
        altura: '1.552 mm',
        batalla: '2.765 mm',
        maletero: '385 - 1.267 litros',
        peso: '1.805 kg',
        plazas: '5',
        puertas: '5'
      }
    },
    equipamiento: {
      exterior: ['Faros LED Matrix IQ.Light', 'Pilotos traseros LED 3D', 'Llantas aleación 18"', 'Techo panorámico', 'Cristales tintados', 'Retrovisores eléctricos'],
      interior: ['Digital Cockpit 5.3"', 'Pantalla táctil 10"', 'Climatizador automático', 'Volante multifunción', 'Asientos calefactados', 'Iluminación ambiental 30 colores'],
      tecnologia: ['We Connect Plus', 'Apple CarPlay / Android Auto', 'Navegación con RA', 'Carga inalámbrica', 'Sistema de sonido 6 altavoces', 'Head-up Display AR'],
      seguridad: ['Front Assist', 'Lane Assist', 'ACC adaptativo', 'Park Assist Plus', '7 airbags', 'Cámara 360°']
    },
    ventajas: [
      { icon: 'ri-money-euro-circle-line', title: 'Coste reducido', desc: 'Ahorra hasta un 70% en combustible respecto a un vehículo de gasolina' },
      { icon: 'ri-leaf-line', title: 'Etiqueta CERO', desc: 'Acceso libre a zonas de bajas emisiones y ventajas fiscales' },
      { icon: 'ri-tools-line', title: 'Bajo mantenimiento', desc: 'Sin cambios de aceite, filtros ni embrague. Menos piezas de desgaste' },
      { icon: 'ri-flashlight-line', title: 'Carga rápida', desc: 'Del 10% al 80% en solo 30 minutos en cargadores DC' }
    ],
    related: [
      { slug: 'volkswagen-id4-pro', name: 'ID.4 Pro', price: '485€/mes', image: 'https://readdy.ai/api/search-image?query=Volkswagen%20ID4%20electric%20SUV%20in%20metallic%20gray%20color%20on%20clean%20white%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20modern%20crossover&width=400&height=250&seq=vw-id4-rel&orientation=landscape' },
      { slug: 'volkswagen-id5-gtx', name: 'ID.5 GTX', price: '599€/mes', image: 'https://readdy.ai/api/search-image?query=Volkswagen%20ID5%20GTX%20electric%20coupe%20SUV%20in%20dark%20blue%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20design&width=400&height=250&seq=vw-id5-rel&orientation=landscape' },
      { slug: 'cupra-born-eboost', name: 'CUPRA Born', price: '429€/mes', image: 'https://readdy.ai/api/search-image?query=CUPRA%20Born%20electric%20hatchback%20in%20copper%20bronze%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20compact%20car&width=400&height=250&seq=cupra-born-rel&orientation=landscape' }
    ]
  },
  'volkswagen-id4-pro': {
    brand: 'Volkswagen',
    name: 'ID.4 Pro',
    type: '100% Eléctrico',
    price: '485€',
    pvp: '52.400€',
    badge: 'SUV familiar',
    tagline: 'SUV eléctrico · 204 CV · Etiqueta CERO',
    image: 'https://readdy.ai/api/search-image?query=Volkswagen%20ID4%20electric%20SUV%20in%20metallic%20gray%20color%20on%20clean%20white%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20modern%20crossover&width=800&height=500&seq=vw-id4-detail&orientation=landscape',
    gallery: [
      'https://readdy.ai/api/search-image?query=Volkswagen%20ID4%20electric%20SUV%20in%20metallic%20gray%20color%20on%20clean%20white%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20modern%20crossover&width=900&height=600&seq=vw-id4-g1&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Volkswagen%20ID4%20rear%20view%20gray%20metallic%20studio%20background%20professional%20automotive%20photography%20showing%20LED%20tail%20lights&width=900&height=600&seq=vw-id4-g2&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Volkswagen%20ID4%20interior%20dashboard%20digital%20cockpit%20spacious%20cabin%20premium%20materials&width=900&height=600&seq=vw-id4-g3&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Volkswagen%20ID4%20side%20profile%20gray%20metallic%20studio%20background%20showing%20SUV%20proportions&width=900&height=600&seq=vw-id4-g4&orientation=landscape'
    ],
    specs: {
      motor: {
        motorizacion: 'Motor eléctrico trasero',
        potencia: '204 CV (150 kW)',
        parMaximo: '310 Nm',
        transmision: 'Automática 1 velocidad',
        traccion: 'Trasera',
        aceleracion: '8.5 s (0-100 km/h)',
        velocidadMaxima: '160 km/h'
      },
      bateria: {
        capacidad: '77 kWh (neta)',
        autonomia: '521 km WLTP',
        cargaRapidaDC: '38 min (10-80%)',
        cargaAC: '11 kW',
        potenciaCargaDC: '135 kW',
        consumo: '16.3 kWh/100km'
      },
      dimensiones: {
        longitud: '4.584 mm',
        anchura: '1.865 mm',
        altura: '1.634 mm',
        batalla: '2.771 mm',
        maletero: '543 - 1.575 litros',
        peso: '2.124 kg',
        plazas: '5',
        puertas: '5'
      }
    },
    equipamiento: {
      exterior: ['Faros LED Matrix IQ.Light', 'Pilotos traseros LED 3D', 'Llantas aleación 19"', 'Barras de techo', 'Cristales tintados', 'Portón eléctrico'],
      interior: ['Digital Cockpit 5.3"', 'Pantalla táctil 12"', 'Climatizador bizona', 'Volante multifunción calefactado', 'Asientos ergonómicos', 'Iluminación ambiental'],
      tecnologia: ['We Connect Plus', 'Apple CarPlay / Android Auto', 'Navegación inteligente', 'Carga inalámbrica', 'Sistema de sonido Harman Kardon', 'Head-up Display AR'],
      seguridad: ['Front Assist', 'Lane Assist', 'ACC adaptativo', 'Park Assist Plus', '8 airbags', 'Cámara 360°']
    },
    ventajas: [
      { icon: 'ri-space', title: 'Espacio familiar', desc: 'Amplio maletero de 543L y habitáculo espacioso para toda la familia' },
      { icon: 'ri-leaf-line', title: 'Etiqueta CERO', desc: 'Acceso libre a zonas de bajas emisiones y ventajas fiscales' },
      { icon: 'ri-battery-2-charge-line', title: 'Gran autonomía', desc: 'Hasta 521 km con una sola carga para viajes largos sin preocupaciones' },
      { icon: 'ri-shield-check-line', title: 'Seguridad 5 estrellas', desc: 'Máxima puntuación Euro NCAP con sistemas de asistencia avanzados' }
    ],
    related: [
      { slug: 'volkswagen-id3-pro', name: 'ID.3 Pro', price: '399€/mes', image: 'https://readdy.ai/api/search-image?query=Volkswagen%20ID3%20electric%20hatchback%20in%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20modern%20compact%20electric%20car&width=400&height=250&seq=vw-id3-rel&orientation=landscape' },
      { slug: 'volkswagen-id5-gtx', name: 'ID.5 GTX', price: '599€/mes', image: 'https://readdy.ai/api/search-image?query=Volkswagen%20ID5%20GTX%20electric%20coupe%20SUV%20in%20dark%20blue%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20design&width=400&height=250&seq=vw-id5-rel&orientation=landscape' },
      { slug: 'audi-q4-etron-45', name: 'Audi Q4 e-tron', price: '549€/mes', image: 'https://readdy.ai/api/search-image?query=Audi%20Q4%20e-tron%20electric%20SUV%20in%20glacier%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20premium%20crossover&width=400&height=250&seq=audi-q4-rel&orientation=landscape' }
    ]
  },
  'volkswagen-id5-gtx': {
    brand: 'Volkswagen',
    name: 'ID.5 GTX',
    type: '100% Eléctrico',
    price: '599€',
    pvp: '64.900€',
    badge: 'Deportivo',
    tagline: 'SUV Coupé eléctrico · 299 CV · Etiqueta CERO',
    image: 'https://readdy.ai/api/search-image?query=Volkswagen%20ID5%20GTX%20electric%20coupe%20SUV%20in%20dark%20blue%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20design&width=800&height=500&seq=vw-id5-detail&orientation=landscape',
    gallery: [
      'https://readdy.ai/api/search-image?query=Volkswagen%20ID5%20GTX%20electric%20coupe%20SUV%20in%20dark%20blue%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20design&width=900&height=600&seq=vw-id5-g1&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Volkswagen%20ID5%20GTX%20rear%20view%20dark%20blue%20studio%20background%20showing%20coupe%20roofline%20and%20LED%20lights&width=900&height=600&seq=vw-id5-g2&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Volkswagen%20ID5%20GTX%20interior%20sporty%20cockpit%20red%20accents%20premium%20materials&width=900&height=600&seq=vw-id5-g3&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Volkswagen%20ID5%20GTX%20side%20profile%20dark%20blue%20showing%20coupe%20SUV%20silhouette&width=900&height=600&seq=vw-id5-g4&orientation=landscape'
    ],
    specs: {
      motor: {
        motorizacion: 'Doble motor eléctrico',
        potencia: '299 CV (220 kW)',
        parMaximo: '460 Nm',
        transmision: 'Automática 1 velocidad',
        traccion: 'Total (4MOTION)',
        aceleracion: '6.3 s (0-100 km/h)',
        velocidadMaxima: '180 km/h'
      },
      bateria: {
        capacidad: '77 kWh (neta)',
        autonomia: '490 km WLTP',
        cargaRapidaDC: '36 min (10-80%)',
        cargaAC: '11 kW',
        potenciaCargaDC: '150 kW',
        consumo: '17.2 kWh/100km'
      },
      dimensiones: {
        longitud: '4.599 mm',
        anchura: '1.852 mm',
        altura: '1.615 mm',
        batalla: '2.766 mm',
        maletero: '549 - 1.561 litros',
        peso: '2.224 kg',
        plazas: '5',
        puertas: '5'
      }
    },
    equipamiento: {
      exterior: ['Faros LED Matrix IQ.Light', 'Pilotos traseros LED 3D', 'Llantas aleación 20" GTX', 'Techo panorámico', 'Spoiler trasero', 'Difusor deportivo'],
      interior: ['Digital Cockpit Pro', 'Pantalla táctil 12"', 'Asientos deportivos GTX', 'Volante deportivo', 'Pedales en aluminio', 'Iluminación ambiental 30 colores'],
      tecnologia: ['We Connect Plus', 'Apple CarPlay / Android Auto', 'Navegación con RA', 'Sistema Harman Kardon', 'Head-up Display AR', 'Asistente de voz'],
      seguridad: ['Front Assist', 'Lane Assist', 'ACC predictivo', 'Travel Assist', '8 airbags', 'Cámara 360°']
    },
    ventajas: [
      { icon: 'ri-speed-line', title: 'Prestaciones GTX', desc: 'Tracción total y 299 CV para una conducción deportiva y segura' },
      { icon: 'ri-palette-line', title: 'Diseño coupé', desc: 'Líneas aerodinámicas y deportivas que destacan en cualquier lugar' },
      { icon: 'ri-leaf-line', title: 'Etiqueta CERO', desc: 'Deportividad sin emisiones y acceso a todas las zonas' },
      { icon: 'ri-vip-crown-line', title: 'Equipamiento premium', desc: 'Tecnología y confort de primer nivel en cada detalle' }
    ],
    related: [
      { slug: 'volkswagen-id4-pro', name: 'ID.4 Pro', price: '485€/mes', image: 'https://readdy.ai/api/search-image?query=Volkswagen%20ID4%20electric%20SUV%20in%20metallic%20gray%20color%20on%20clean%20white%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20modern%20crossover&width=400&height=250&seq=vw-id4-rel&orientation=landscape' },
      { slug: 'audi-q4-etron-45', name: 'Audi Q4 e-tron', price: '549€/mes', image: 'https://readdy.ai/api/search-image?query=Audi%20Q4%20e-tron%20electric%20SUV%20in%20glacier%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20premium%20crossover&width=400&height=250&seq=audi-q4-rel&orientation=landscape' },
      { slug: 'cupra-tavascan-vz', name: 'CUPRA Tavascan', price: '649€/mes', image: 'https://readdy.ai/api/search-image?query=CUPRA%20Tavascan%20electric%20coupe%20SUV%20in%20dark%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20crossover&width=400&height=250&seq=cupra-tavascan-rel3&orientation=landscape' }
    ]
  },
  'audi-q4-etron-45': {
    brand: 'Audi',
    name: 'Q4 e-tron 45',
    type: '100% Eléctrico',
    price: '549€',
    pvp: '59.400€',
    badge: 'SUV versátil',
    tagline: 'SUV premium eléctrico · 286 CV · Etiqueta CERO',
    image: 'https://readdy.ai/api/search-image?query=Audi%20Q4%20e-tron%20electric%20SUV%20in%20glacier%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20premium%20crossover&width=800&height=500&seq=audi-q4-detail&orientation=landscape',
    gallery: [
      'https://readdy.ai/api/search-image?query=Audi%20Q4%20e-tron%20electric%20SUV%20in%20glacier%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20premium%20crossover&width=900&height=600&seq=audi-q4-g1&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Audi%20Q4%20e-tron%20rear%20view%20white%20studio%20background%20showing%20LED%20light%20bar%20and%20premium%20design&width=900&height=600&seq=audi-q4-g2&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Audi%20Q4%20e-tron%20interior%20virtual%20cockpit%20MMI%20touch%20display%20premium%20materials&width=900&height=600&seq=audi-q4-g3&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Audi%20Q4%20e-tron%20side%20profile%20white%20showing%20elegant%20SUV%20proportions&width=900&height=600&seq=audi-q4-g4&orientation=landscape'
    ],
    specs: {
      motor: {
        motorizacion: 'Motor eléctrico trasero',
        potencia: '286 CV (210 kW)',
        parMaximo: '310 Nm',
        transmision: 'Automática 1 velocidad',
        traccion: 'Trasera',
        aceleracion: '6.2 s (0-100 km/h)',
        velocidadMaxima: '180 km/h'
      },
      bateria: {
        capacidad: '82 kWh (neta)',
        autonomia: '520 km WLTP',
        cargaRapidaDC: '38 min (10-80%)',
        cargaAC: '11 kW',
        potenciaCargaDC: '135 kW',
        consumo: '17.0 kWh/100km'
      },
      dimensiones: {
        longitud: '4.588 mm',
        anchura: '1.865 mm',
        altura: '1.632 mm',
        batalla: '2.764 mm',
        maletero: '520 - 1.490 litros',
        peso: '2.135 kg',
        plazas: '5',
        puertas: '5'
      }
    },
    equipamiento: {
      exterior: ['Faros LED Matrix', 'Pilotos LED con barra luminosa', 'Llantas aleación 19"', 'Barras de techo en aluminio', 'Cristales acústicos', 'Portón eléctrico'],
      interior: ['Audi Virtual Cockpit Plus', 'MMI touch 11.6"', 'Climatizador trizona', 'Volante multifunción', 'Asientos deportivos S line', 'Iluminación ambiental plus'],
      tecnologia: ['Audi connect', 'Apple CarPlay / Android Auto', 'Navegación MMI plus', 'Bang & Olufsen 3D', 'Head-up Display AR', 'Asistente Audi'],
      seguridad: ['Audi pre sense front', 'Lane Assist', 'ACC adaptativo', 'Park Assist plus', '8 airbags', 'Cámara 360°']
    },
    ventajas: [
      { icon: 'ri-vip-crown-line', title: 'Premium Audi', desc: 'Calidad de construcción y materiales de primer nivel' },
      { icon: 'ri-battery-2-charge-line', title: 'Gran autonomía', desc: 'Hasta 520 km con una sola carga para viajes sin preocupaciones' },
      { icon: 'ri-leaf-line', title: 'Etiqueta CERO', desc: 'Acceso libre a zonas de bajas emisiones y ventajas fiscales' },
      { icon: 'ri-sound-module-line', title: 'Tecnología avanzada', desc: 'Sistema MMI de última generación y sonido Bang & Olufsen' }
    ],
    related: [
      { slug: 'audi-etron-gt-quattro', name: 'e-tron GT', price: '999€/mes', image: 'https://readdy.ai/api/search-image?query=Audi%20e-tron%20GT%20electric%20sports%20car%20in%20daytona%20gray%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20luxury%20performance&width=400&height=250&seq=audi-etrongt-rel&orientation=landscape' },
      { slug: 'audi-q8-etron-55', name: 'Q8 e-tron', price: '899€/mes', image: 'https://readdy.ai/api/search-image?query=Audi%20Q8%20e-tron%20electric%20luxury%20SUV%20in%20mythos%20black%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20flagship%20crossover&width=400&height=250&seq=audi-q8-rel&orientation=landscape' },
      { slug: 'volkswagen-id4-pro', name: 'VW ID.4 Pro', price: '485€/mes', image: 'https://readdy.ai/api/search-image?query=Volkswagen%20ID4%20electric%20SUV%20in%20metallic%20gray%20color%20on%20clean%20white%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20modern%20crossover&width=400&height=250&seq=vw-id4-rel2&orientation=landscape' }
    ]
  },
  'audi-etron-gt-quattro': {
    brand: 'Audi',
    name: 'e-tron GT quattro',
    type: '100% Eléctrico',
    price: '999€',
    pvp: '107.900€',
    badge: 'Gran Turismo',
    tagline: 'Gran Turismo eléctrico · 476 CV · Etiqueta CERO',
    image: 'https://readdy.ai/api/search-image?query=Audi%20e-tron%20GT%20electric%20sports%20car%20in%20daytona%20gray%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20luxury%20performance&width=800&height=500&seq=audi-etrongt-detail&orientation=landscape',
    gallery: [
      'https://readdy.ai/api/search-image?query=Audi%20e-tron%20GT%20electric%20sports%20car%20in%20daytona%20gray%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20luxury%20performance&width=900&height=600&seq=audi-etrongt-g1&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Audi%20e-tron%20GT%20rear%20view%20gray%20studio%20background%20showing%20sporty%20design%20and%20LED%20lights&width=900&height=600&seq=audi-etrongt-g2&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Audi%20e-tron%20GT%20interior%20luxury%20cockpit%20sport%20seats%20premium%20leather&width=900&height=600&seq=audi-etrongt-g3&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Audi%20e-tron%20GT%20side%20profile%20gray%20showing%20elegant%20gran%20turismo%20silhouette&width=900&height=600&seq=audi-etrongt-g4&orientation=landscape'
    ],
    specs: {
      motor: {
        motorizacion: 'Doble motor eléctrico',
        potencia: '476 CV (350 kW)',
        parMaximo: '630 Nm',
        transmision: 'Automática 2 velocidades',
        traccion: 'Total (quattro)',
        aceleracion: '4.1 s (0-100 km/h)',
        velocidadMaxima: '245 km/h'
      },
      bateria: {
        capacidad: '93.4 kWh (neta)',
        autonomia: '488 km WLTP',
        cargaRapidaDC: '23 min (10-80%)',
        cargaAC: '22 kW',
        potenciaCargaDC: '270 kW',
        consumo: '19.6 kWh/100km'
      },
      dimensiones: {
        longitud: '4.989 mm',
        anchura: '1.964 mm',
        altura: '1.396 mm',
        batalla: '2.900 mm',
        maletero: '405 litros',
        peso: '2.347 kg',
        plazas: '4',
        puertas: '4'
      }
    },
    equipamiento: {
      exterior: ['Faros LED Matrix HD', 'Pilotos OLED', 'Llantas 20" diseño aero', 'Techo panorámico', 'Spoiler activo', 'Pintura metalizada'],
      interior: ['Audi Virtual Cockpit Plus', 'MMI touch 10.1"', 'Asientos sport plus', 'Volante deportivo', 'Cuero Nappa', 'Iluminación ambiental plus'],
      tecnologia: ['Audi connect plus', 'Apple CarPlay / Android Auto', 'Navegación MMI plus', 'Bang & Olufsen 3D', 'Head-up Display', 'Audi phone box'],
      seguridad: ['Audi pre sense 360°', 'Lane Assist', 'ACC predictivo', 'Night vision', '8 airbags', 'Cámara 360°']
    },
    ventajas: [
      { icon: 'ri-speed-line', title: 'Prestaciones extremas', desc: '476 CV y 0-100 en 4.1 segundos para emociones únicas' },
      { icon: 'ri-flashlight-line', title: 'Carga ultrarrápida', desc: 'Arquitectura 800V para cargar del 10% al 80% en 23 minutos' },
      { icon: 'ri-vip-crown-line', title: 'Lujo absoluto', desc: 'Materiales premium y acabados de la más alta calidad' },
      { icon: 'ri-leaf-line', title: 'Etiqueta CERO', desc: 'Deportividad sin emisiones y acceso a todas las zonas' }
    ],
    related: [
      { slug: 'audi-q4-etron-45', name: 'Q4 e-tron 45', price: '549€/mes', image: 'https://readdy.ai/api/search-image?query=Audi%20Q4%20e-tron%20electric%20SUV%20in%20glacier%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20premium%20crossover&width=400&height=250&seq=audi-q4-rel2&orientation=landscape' },
      { slug: 'audi-q8-etron-55', name: 'Q8 e-tron 55', price: '899€/mes', image: 'https://readdy.ai/api/search-image?query=Audi%20Q8%20e-tron%20electric%20luxury%20SUV%20in%20mythos%20black%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20flagship%20crossover&width=400&height=250&seq=audi-q8-rel2&orientation=landscape' },
      { slug: 'cupra-tavascan-vz', name: 'CUPRA Tavascan', price: '649€/mes', image: 'https://readdy.ai/api/search-image?query=CUPRA%20Tavascan%20electric%20coupe%20SUV%20in%20dark%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20crossover&width=400&height=250&seq=cupra-tavascan-rel2&orientation=landscape' }
    ]
  },
  'audi-q8-etron-55': {
    brand: 'Audi',
    name: 'Q8 e-tron 55',
    type: '100% Eléctrico',
    price: '899€',
    pvp: '97.100€',
    badge: 'Flagship SUV',
    tagline: 'SUV de lujo eléctrico · 408 CV · Etiqueta CERO',
    image: 'https://readdy.ai/api/search-image?query=Audi%20Q8%20e-tron%20electric%20luxury%20SUV%20in%20mythos%20black%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20flagship%20crossover&width=800&height=500&seq=audi-q8-detail&orientation=landscape',
    gallery: [
      'https://readdy.ai/api/search-image?query=Audi%20Q8%20e-tron%20electric%20luxury%20SUV%20in%20mythos%20black%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20flagship%20crossover&width=900&height=600&seq=audi-q8-g1&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Audi%20Q8%20e-tron%20rear%20view%20black%20studio%20background%20showing%20premium%20LED%20lights&width=900&height=600&seq=audi-q8-g2&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Audi%20Q8%20e-tron%20interior%20luxury%20cabin%20premium%20leather%20digital%20displays&width=900&height=600&seq=audi-q8-g3&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Audi%20Q8%20e-tron%20side%20profile%20black%20showing%20flagship%20SUV%20proportions&width=900&height=600&seq=audi-q8-g4&orientation=landscape'
    ],
    specs: {
      motor: {
        motorizacion: 'Doble motor eléctrico',
        potencia: '408 CV (300 kW)',
        parMaximo: '664 Nm',
        transmision: 'Automática 1 velocidad',
        traccion: 'Total (quattro)',
        aceleracion: '5.6 s (0-100 km/h)',
        velocidadMaxima: '200 km/h'
      },
      bateria: {
        capacidad: '114 kWh (neta)',
        autonomia: '582 km WLTP',
        cargaRapidaDC: '31 min (10-80%)',
        cargaAC: '22 kW',
        potenciaCargaDC: '170 kW',
        consumo: '20.6 kWh/100km'
      },
      dimensiones: {
        longitud: '4.915 mm',
        anchura: '1.937 mm',
        altura: '1.633 mm',
        batalla: '2.928 mm',
        maletero: '569 - 1.637 litros',
        peso: '2.585 kg',
        plazas: '5',
        puertas: '5'
      }
    },
    equipamiento: {
      exterior: ['Faros Digital Matrix LED', 'Pilotos OLED', 'Llantas 21"', 'Retrovisores virtuales', 'Techo panorámico', 'Portón eléctrico'],
      interior: ['Audi Virtual Cockpit Plus', 'MMI touch dual screen', 'Asientos confort plus', 'Volante calefactado', 'Cuero Valcona', 'Iluminación ambiental plus'],
      tecnologia: ['Audi connect plus', 'Apple CarPlay / Android Auto', 'Navegación e-tron', 'Bang & Olufsen 3D', 'Head-up Display', 'Audi phone box'],
      seguridad: ['Audi pre sense 360°', 'Lane Assist', 'ACC predictivo', 'Night vision', '8 airbags', 'Cámara 360°']
    },
    ventajas: [
      { icon: 'ri-battery-2-charge-line', title: 'Máxima autonomía', desc: 'Hasta 582 km con la batería más grande de la gama Audi' },
      { icon: 'ri-space', title: 'Espacio de lujo', desc: 'Habitáculo premium con espacio para 5 adultos y gran maletero' },
      { icon: 'ri-vip-crown-line', title: 'Flagship Audi', desc: 'Lo mejor de la tecnología y el confort en un SUV eléctrico' },
      { icon: 'ri-leaf-line', title: 'Etiqueta CERO', desc: 'Lujo sostenible con acceso a todas las zonas' }
    ],
    related: [
      { slug: 'audi-q4-etron-45', name: 'Q4 e-tron 45', price: '549€/mes', image: 'https://readdy.ai/api/search-image?query=Audi%20Q4%20e-tron%20electric%20SUV%20in%20glacier%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20premium%20crossover&width=400&height=250&seq=audi-q4-rel3&orientation=landscape' },
      { slug: 'audi-etron-gt-quattro', name: 'e-tron GT', price: '999€/mes', image: 'https://readdy.ai/api/search-image?query=Audi%20e-tron%20GT%20electric%20sports%20car%20in%20daytona%20gray%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20luxury%20performance&width=400&height=250&seq=audi-etrongt-rel2&orientation=landscape' },
      { slug: 'volkswagen-id5-gtx', name: 'VW ID.5 GTX', price: '599€/mes', image: 'https://readdy.ai/api/search-image?query=Volkswagen%20ID5%20GTX%20electric%20coupe%20SUV%20in%20dark%20blue%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20design&width=400&height=250&seq=vw-id5-rel2&orientation=landscape' }
    ]
  },
  'cupra-born-eboost': {
    brand: 'CUPRA',
    name: 'Born e-Boost',
    type: '100% Eléctrico',
    price: '429€',
    pvp: '46.400€',
    badge: 'Deportivo compacto',
    tagline: 'Compacto deportivo eléctrico · 231 CV · Etiqueta CERO',
    image: 'https://readdy.ai/api/search-image?query=CUPRA%20Born%20electric%20hatchback%20in%20copper%20bronze%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20compact%20car&width=800&height=500&seq=cupra-born-detail&orientation=landscape',
    gallery: [
      'https://readdy.ai/api/search-image?query=CUPRA%20Born%20electric%20hatchback%20in%20copper%20bronze%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20compact%20car&width=900&height=600&seq=cupra-born-g1&orientation=landscape',
      'https://readdy.ai/api/search-image?query=CUPRA%20Born%20rear%20view%20copper%20bronze%20studio%20background%20showing%20sporty%20design&width=900&height=600&seq=cupra-born-g2&orientation=landscape',
      'https://readdy.ai/api/search-image?query=CUPRA%20Born%20interior%20sporty%20cockpit%20bucket%20seats%20copper%20accents&width=900&height=600&seq=cupra-born-g3&orientation=landscape',
      'https://readdy.ai/api/search-image?query=CUPRA%20Born%20side%20profile%20copper%20bronze%20showing%20dynamic%20hatchback%20design&width=900&height=600&seq=cupra-born-g4&orientation=landscape'
    ],
    specs: {
      motor: {
        motorizacion: 'Motor eléctrico trasero',
        potencia: '231 CV (170 kW)',
        parMaximo: '310 Nm',
        transmision: 'Automática 1 velocidad',
        traccion: 'Trasera',
        aceleracion: '6.6 s (0-100 km/h)',
        velocidadMaxima: '160 km/h'
      },
      bateria: {
        capacidad: '77 kWh (neta)',
        autonomia: '548 km WLTP',
        cargaRapidaDC: '35 min (10-80%)',
        cargaAC: '11 kW',
        potenciaCargaDC: '135 kW',
        consumo: '15.4 kWh/100km'
      },
      dimensiones: {
        longitud: '4.322 mm',
        anchura: '1.809 mm',
        altura: '1.537 mm',
        batalla: '2.765 mm',
        maletero: '385 - 1.267 litros',
        peso: '1.900 kg',
        plazas: '5',
        puertas: '5'
      }
    },
    equipamiento: {
      exterior: ['Faros LED', 'Pilotos LED 3D', 'Llantas 19" CUPRA', 'Spoiler trasero', 'Difusor deportivo', 'Pintura mate disponible'],
      interior: ['Digital Cockpit', 'Pantalla 12"', 'Asientos deportivos CUPBucket', 'Volante CUPRA', 'Pedales en aluminio', 'Iluminación ambiental cobre'],
      tecnologia: ['CUPRA Connect', 'Apple CarPlay / Android Auto', 'Navegación', 'Beats Audio', 'Carga inalámbrica', 'Asistente de voz'],
      seguridad: ['Front Assist', 'Lane Assist', 'ACC', 'Park Assist', '7 airbags', 'Cámara trasera']
    },
    ventajas: [
      { icon: 'ri-speed-line', title: 'ADN deportivo', desc: 'Diseño y prestaciones CUPRA para una conducción emocionante' },
      { icon: 'ri-battery-2-charge-line', title: 'Gran autonomía', desc: 'Hasta 548 km con una sola carga, líder en su segmento' },
      { icon: 'ri-leaf-line', title: 'Etiqueta CERO', desc: 'Deportividad sin emisiones y acceso a todas las zonas' },
      { icon: 'ri-money-euro-circle-line', title: 'Precio competitivo', desc: 'La mejor relación prestaciones-precio en eléctricos deportivos' }
    ],
    related: [
      { slug: 'cupra-born-vz', name: 'Born VZ', price: '479€/mes', image: 'https://readdy.ai/api/search-image?query=CUPRA%20Born%20VZ%20electric%20hot%20hatch%20in%20matte%20gray%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20performance%20compact&width=400&height=250&seq=cupra-born-vz-rel&orientation=landscape' },
      { slug: 'cupra-tavascan-vz', name: 'Tavascan VZ', price: '649€/mes', image: 'https://readdy.ai/api/search-image?query=CUPRA%20Tavascan%20electric%20coupe%20SUV%20in%20dark%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20crossover&width=400&height=250&seq=cupra-tavascan-rel3&orientation=landscape' },
      { slug: 'volkswagen-id3-pro', name: 'VW ID.3 Pro', price: '399€/mes', image: 'https://readdy.ai/api/search-image?query=Volkswagen%20ID3%20electric%20hatchback%20in%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20modern%20compact%20electric%20car&width=400&height=250&seq=vw-id3-rel2&orientation=landscape' }
    ]
  },
  'cupra-tavascan-vz': {
    brand: 'CUPRA',
    name: 'Tavascan VZ',
    type: '100% Eléctrico',
    price: '649€',
    pvp: '70.100€',
    badge: 'SUV Coupé',
    tagline: 'SUV Coupé deportivo eléctrico · 340 CV · Etiqueta CERO',
    image: 'https://readdy.ai/api/search-image?query=CUPRA%20Tavascan%20electric%20coupe%20SUV%20in%20dark%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20crossover&width=800&height=500&seq=cupra-tavascan-detail&orientation=landscape',
    gallery: [
      'https://readdy.ai/api/search-image?query=CUPRA%20Tavascan%20electric%20coupe%20SUV%20in%20dark%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20crossover&width=900&height=600&seq=cupra-tavascan-g1&orientation=landscape',
      'https://readdy.ai/api/search-image?query=CUPRA%20Tavascan%20rear%20view%20dark%20metallic%20studio%20background%20showing%20coupe%20roofline&width=900&height=600&seq=cupra-tavascan-g2&orientation=landscape',
      'https://readdy.ai/api/search-image?query=CUPRA%20Tavascan%20interior%20sporty%20cockpit%20premium%20materials%20copper%20accents&width=900&height=600&seq=cupra-tavascan-g3&orientation=landscape',
      'https://readdy.ai/api/search-image?query=CUPRA%20Tavascan%20side%20profile%20dark%20metallic%20showing%20SUV%20coupe%20silhouette&width=900&height=600&seq=cupra-tavascan-g4&orientation=landscape'
    ],
    specs: {
      motor: {
        motorizacion: 'Doble motor eléctrico',
        potencia: '340 CV (250 kW)',
        parMaximo: '545 Nm',
        transmision: 'Automática 1 velocidad',
        traccion: 'Total (4Drive)',
        aceleracion: '5.6 s (0-100 km/h)',
        velocidadMaxima: '180 km/h'
      },
      bateria: {
        capacidad: '77 kWh (neta)',
        autonomia: '520 km WLTP',
        cargaRapidaDC: '35 min (10-80%)',
        cargaAC: '11 kW',
        potenciaCargaDC: '135 kW',
        consumo: '16.8 kWh/100km'
      },
      dimensiones: {
        longitud: '4.644 mm',
        anchura: '1.861 mm',
        altura: '1.597 mm',
        batalla: '2.766 mm',
        maletero: '540 - 1.438 litros',
        peso: '2.158 kg',
        plazas: '5',
        puertas: '5'
      }
    },
    equipamiento: {
      exterior: ['Faros LED Matrix', 'Pilotos LED 3D', 'Llantas 21" CUPRA', 'Techo panorámico', 'Spoiler trasero', 'Difusor deportivo'],
      interior: ['Digital Cockpit 5.3"', 'Pantalla 15"', 'Asientos deportivos CUPBucket', 'Volante CUPRA', 'Pedales en aluminio', 'Iluminación ambiental'],
      tecnologia: ['CUPRA Connect Plus', 'Apple CarPlay / Android Auto', 'Navegación AR', 'Sennheiser Audio', 'Head-up Display AR', 'Asistente de voz'],
      seguridad: ['Front Assist', 'Lane Assist', 'ACC predictivo', 'Travel Assist', '8 airbags', 'Cámara 360°']
    },
    ventajas: [
      { icon: 'ri-speed-line', title: 'Prestaciones VZ', desc: 'Tracción total y 340 CV para una conducción deportiva y segura' },
      { icon: 'ri-palette-line', title: 'Diseño único', desc: 'Líneas de SUV coupé que definen una nueva categoría' },
      { icon: 'ri-leaf-line', title: 'Etiqueta CERO', desc: 'Deportividad sin emisiones y acceso a todas las zonas' },
      { icon: 'ri-sound-module-line', title: 'Tecnología premium', desc: 'Pantalla de 15" y sonido Sennheiser de alta fidelidad' }
    ],
    related: [
      { slug: 'cupra-born-eboost', name: 'Born e-Boost', price: '429€/mes', image: 'https://readdy.ai/api/search-image?query=CUPRA%20Born%20electric%20hatchback%20in%20copper%20bronze%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20compact%20car&width=400&height=250&seq=cupra-born-rel2&orientation=landscape' },
      { slug: 'cupra-born-vz', name: 'Born VZ', price: '479€/mes', image: 'https://readdy.ai/api/search-image?query=CUPRA%20Born%20VZ%20electric%20hot%20hatch%20in%20matte%20gray%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20performance%20compact&width=400&height=250&seq=cupra-born-vz-rel2&orientation=landscape' },
      { slug: 'volkswagen-id5-gtx', name: 'VW ID.5 GTX', price: '599€/mes', image: 'https://readdy.ai/api/search-image?query=Volkswagen%20ID5%20GTX%20electric%20coupe%20SUV%20in%20dark%20blue%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20design&width=400&height=250&seq=vw-id5-rel3&orientation=landscape' }
    ]
  },
  'cupra-born-vz': {
    brand: 'CUPRA',
    name: 'Born VZ',
    type: '100% Eléctrico',
    price: '479€',
    pvp: '51.800€',
    badge: 'Máxima potencia',
    tagline: 'Hot hatch eléctrico · 326 CV · Etiqueta CERO',
    image: 'https://readdy.ai/api/search-image?query=CUPRA%20Born%20VZ%20electric%20hot%20hatch%20in%20matte%20gray%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20performance%20compact&width=800&height=500&seq=cupra-born-vz-detail&orientation=landscape',
    gallery: [
      'https://readdy.ai/api/search-image?query=CUPRA%20Born%20VZ%20electric%20hot%20hatch%20in%20matte%20gray%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20performance%20compact&width=900&height=600&seq=cupra-born-vz-g1&orientation=landscape',
      'https://readdy.ai/api/search-image?query=CUPRA%20Born%20VZ%20rear%20view%20matte%20gray%20studio%20background%20showing%20sporty%20design&width=900&height=600&seq=cupra-born-vz-g2&orientation=landscape',
      'https://readdy.ai/api/search-image?query=CUPRA%20Born%20VZ%20interior%20racing%20cockpit%20bucket%20seats%20copper%20accents&width=900&height=600&seq=cupra-born-vz-g3&orientation=landscape',
      'https://readdy.ai/api/search-image?query=CUPRA%20Born%20VZ%20side%20profile%20matte%20gray%20showing%20hot%20hatch%20proportions&width=900&height=600&seq=cupra-born-vz-g4&orientation=landscape'
    ],
    specs: {
      motor: {
        motorizacion: 'Motor eléctrico trasero',
        potencia: '326 CV (240 kW)',
        parMaximo: '545 Nm',
        transmision: 'Automática 1 velocidad',
        traccion: 'Trasera',
        aceleracion: '5.6 s (0-100 km/h)',
        velocidadMaxima: '160 km/h'
      },
      bateria: {
        capacidad: '77 kWh (neta)',
        autonomia: '511 km WLTP',
        cargaRapidaDC: '35 min (10-80%)',
        cargaAC: '11 kW',
        potenciaCargaDC: '185 kW',
        consumo: '16.2 kWh/100km'
      },
      dimensiones: {
        longitud: '4.322 mm',
        anchura: '1.809 mm',
        altura: '1.537 mm',
        batalla: '2.765 mm',
        maletero: '385 - 1.267 litros',
        peso: '1.960 kg',
        plazas: '5',
        puertas: '5'
      }
    },
    equipamiento: {
      exterior: ['Faros LED Matrix', 'Pilotos LED 3D', 'Llantas 20" VZ', 'Spoiler trasero VZ', 'Difusor deportivo', 'Pintura mate exclusiva'],
      interior: ['Digital Cockpit', 'Pantalla 12"', 'Asientos CUPBucket VZ', 'Volante CUPRA VZ', 'Pedales en aluminio', 'Iluminación ambiental cobre'],
      tecnologia: ['CUPRA Connect Plus', 'Apple CarPlay / Android Auto', 'Navegación', 'Beats Audio', 'Carga inalámbrica', 'Asistente de voz'],
      seguridad: ['Front Assist', 'Lane Assist', 'ACC', 'DCC Sport', '7 airbags', 'Cámara trasera']
    },
    ventajas: [
      { icon: 'ri-speed-line', title: 'Máxima potencia', desc: '326 CV y 0-100 en 5.6 segundos, el Born más potente' },
      { icon: 'ri-steering-2-line', title: 'Chasis VZ', desc: 'Suspensión DCC Sport y configuración específica para circuito' },
      { icon: 'ri-leaf-line', title: 'Etiqueta CERO', desc: 'Prestaciones de hot hatch sin emisiones' },
      { icon: 'ri-flashlight-line', title: 'Carga rápida', desc: 'Hasta 185 kW de potencia de carga para mínimas paradas' }
    ],
    related: [
      { slug: 'cupra-born-eboost', name: 'Born e-Boost', price: '429€/mes', image: 'https://readdy.ai/api/search-image?query=CUPRA%20Born%20electric%20hatchback%20in%20copper%20bronze%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20compact%20car&width=400&height=250&seq=cupra-born-rel3&orientation=landscape' },
      { slug: 'cupra-tavascan-vz', name: 'Tavascan VZ', price: '649€/mes', image: 'https://readdy.ai/api/search-image?query=CUPRA%20Tavascan%20electric%20coupe%20SUV%20in%20dark%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20crossover&width=400&height=250&seq=cupra-tavascan-rel4&orientation=landscape' },
      { slug: 'volkswagen-id3-pro', name: 'VW ID.3 Pro', price: '399€/mes', image: 'https://readdy.ai/api/search-image?query=Volkswagen%20ID3%20electric%20hatchback%20in%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20modern%20compact%20electric%20car&width=400&height=250&seq=vw-id3-rel3&orientation=landscape' }
    ]
  },
  'skoda-enyaq-iv-80': {
    brand: 'Skoda',
    name: 'Enyaq iV 80',
    type: '100% Eléctrico',
    price: '499€',
    pvp: '53.900€',
    badge: 'SUV espacioso',
    tagline: 'SUV familiar eléctrico · 204 CV · Etiqueta CERO',
    image: 'https://readdy.ai/api/search-image?query=Skoda%20Enyaq%20iV%20electric%20SUV%20in%20green%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20family%20crossover&width=800&height=500&seq=skoda-enyaq-detail&orientation=landscape',
    gallery: [
      'https://readdy.ai/api/search-image?query=Skoda%20Enyaq%20iV%20electric%20SUV%20in%20green%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20family%20crossover&width=900&height=600&seq=skoda-enyaq-g1&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Skoda%20Enyaq%20iV%20rear%20view%20green%20metallic%20studio%20background%20showing%20LED%20lights&width=900&height=600&seq=skoda-enyaq-g2&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Skoda%20Enyaq%20iV%20interior%20spacious%20cabin%20digital%20displays%20practical%20design&width=900&height=600&seq=skoda-enyaq-g3&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Skoda%20Enyaq%20iV%20side%20profile%20green%20metallic%20showing%20SUV%20proportions&width=900&height=600&seq=skoda-enyaq-g4&orientation=landscape'
    ],
    specs: {
      motor: {
        motorizacion: 'Motor eléctrico trasero',
        potencia: '204 CV (150 kW)',
        parMaximo: '310 Nm',
        transmision: 'Automática 1 velocidad',
        traccion: 'Trasera',
        aceleracion: '8.6 s (0-100 km/h)',
        velocidadMaxima: '160 km/h'
      },
      bateria: {
        capacidad: '82 kWh (neta)',
        autonomia: '534 km WLTP',
        cargaRapidaDC: '36 min (10-80%)',
        cargaAC: '11 kW',
        potenciaCargaDC: '135 kW',
        consumo: '16.7 kWh/100km'
      },
      dimensiones: {
        longitud: '4.649 mm',
        anchura: '1.879 mm',
        altura: '1.616 mm',
        batalla: '2.765 mm',
        maletero: '585 - 1.710 litros',
        peso: '2.090 kg',
        plazas: '5',
        puertas: '5'
      }
    },
    equipamiento: {
      exterior: ['Faros LED Matrix', 'Pilotos LED', 'Llantas 19"', 'Barras de techo', 'Cristales tintados', 'Portón eléctrico'],
      interior: ['Digital Cockpit 5.3"', 'Pantalla 13"', 'Climatizador trizona', 'Volante multifunción', 'Asientos ergonómicos', 'Iluminación ambiental'],
      tecnologia: ['Skoda Connect', 'Apple CarPlay / Android Auto', 'Navegación', 'Canton Sound', 'Carga inalámbrica', 'Head-up Display'],
      seguridad: ['Front Assist', 'Lane Assist', 'ACC', 'Park Assist', '9 airbags', 'Cámara 360°']
    },
    ventajas: [
      { icon: 'ri-space', title: 'Máximo espacio', desc: 'El maletero más grande de su categoría con 585 litros' },
      { icon: 'ri-battery-2-charge-line', title: 'Gran autonomía', desc: 'Hasta 534 km con una sola carga para viajes largos' },
      { icon: 'ri-leaf-line', title: 'Etiqueta CERO', desc: 'Acceso libre a zonas de bajas emisiones y ventajas fiscales' },
      { icon: 'ri-money-euro-circle-line', title: 'Relación calidad-precio', desc: 'El SUV eléctrico más completo por su precio' }
    ],
    related: [
      { slug: 'skoda-enyaq-coupe-rs', name: 'Enyaq Coupé RS', price: '649€/mes', image: 'https://readdy.ai/api/search-image?query=Skoda%20Enyaq%20Coupe%20RS%20electric%20SUV%20coupe%20in%20black%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20design&width=400&height=250&seq=skoda-enyaq-coupe-rel&orientation=landscape' },
      { slug: 'skoda-enyaq-iv-60', name: 'Enyaq iV 60', price: '429€/mes', image: 'https://readdy.ai/api/search-image?query=Skoda%20Enyaq%20iV%2060%20electric%20SUV%20in%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20affordable%20crossover&width=400&height=250&seq=skoda-enyaq-60-rel&orientation=landscape' },
      { slug: 'volkswagen-id4-pro', name: 'VW ID.4 Pro', price: '485€/mes', image: 'https://readdy.ai/api/search-image?query=Volkswagen%20ID4%20electric%20SUV%20in%20metallic%20gray%20color%20on%20clean%20white%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20modern%20crossover&width=400&height=250&seq=vw-id4-rel3&orientation=landscape' }
    ]
  },
  'skoda-enyaq-coupe-rs': {
    brand: 'Skoda',
    name: 'Enyaq Coupé RS',
    type: '100% Eléctrico',
    price: '649€',
    pvp: '70.200€',
    badge: 'Deportivo',
    tagline: 'SUV Coupé deportivo eléctrico · 340 CV · Etiqueta CERO',
    image: 'https://readdy.ai/api/search-image?query=Skoda%20Enyaq%20Coupe%20RS%20electric%20SUV%20coupe%20in%20black%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20design&width=800&height=500&seq=skoda-enyaq-coupe-detail&orientation=landscape',
    gallery: [
      'https://readdy.ai/api/search-image?query=Skoda%20Enyaq%20Coupe%20RS%20electric%20SUV%20coupe%20in%20black%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20design&width=900&height=600&seq=skoda-enyaq-coupe-g1&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Skoda%20Enyaq%20Coupe%20RS%20rear%20view%20black%20studio%20background%20showing%20coupe%20roofline&width=900&height=600&seq=skoda-enyaq-coupe-g2&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Skoda%20Enyaq%20Coupe%20RS%20interior%20sporty%20cockpit%20RS%20details&width=900&height=600&seq=skoda-enyaq-coupe-g3&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Skoda%20Enyaq%20Coupe%20RS%20side%20profile%20black%20showing%20coupe%20SUV%20silhouette&width=900&height=600&seq=skoda-enyaq-coupe-g4&orientation=landscape'
    ],
    specs: {
      motor: {
        motorizacion: 'Doble motor eléctrico',
        potencia: '340 CV (250 kW)',
        parMaximo: '679 Nm',
        transmision: 'Automática 1 velocidad',
        traccion: 'Total',
        aceleracion: '6.5 s (0-100 km/h)',
        velocidadMaxima: '180 km/h'
      },
      bateria: {
        capacidad: '82 kWh (neta)',
        autonomia: '513 km WLTP',
        cargaRapidaDC: '36 min (10-80%)',
        cargaAC: '11 kW',
        potenciaCargaDC: '135 kW',
        consumo: '17.4 kWh/100km'
      },
      dimensiones: {
        longitud: '4.653 mm',
        anchura: '1.879 mm',
        altura: '1.607 mm',
        batalla: '2.765 mm',
        maletero: '570 - 1.610 litros',
        peso: '2.247 kg',
        plazas: '5',
        puertas: '5'
      }
    },
    equipamiento: {
      exterior: ['Faros LED Matrix', 'Pilotos LED', 'Llantas 21" RS', 'Techo panorámico', 'Spoiler trasero', 'Difusor RS'],
      interior: ['Digital Cockpit 5.3"', 'Pantalla 13"', 'Asientos deportivos RS', 'Volante RS', 'Pedales en aluminio', 'Iluminación ambiental'],
      tecnologia: ['Skoda Connect Plus', 'Apple CarPlay / Android Auto', 'Navegación', 'Canton Sound', 'Head-up Display', 'Asistente de voz'],
      seguridad: ['Front Assist', 'Lane Assist', 'ACC predictivo', 'Travel Assist', '9 airbags', 'Cámara 360°']
    },
    ventajas: [
      { icon: 'ri-speed-line', title: 'Prestaciones RS', desc: 'Tracción total y 340 CV para una conducción deportiva' },
      { icon: 'ri-palette-line', title: 'Diseño coupé', desc: 'Líneas deportivas que combinan elegancia y dinamismo' },
      { icon: 'ri-space', title: 'Practicidad', desc: 'Amplio maletero de 570 litros a pesar del diseño coupé' },
      { icon: 'ri-leaf-line', title: 'Etiqueta CERO', desc: 'Deportividad sin emisiones y acceso a todas las zonas' }
    ],
    related: [
      { slug: 'skoda-enyaq-iv-80', name: 'Enyaq iV 80', price: '499€/mes', image: 'https://readdy.ai/api/search-image?query=Skoda%20Enyaq%20iV%20electric%20SUV%20in%20green%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20family%20crossover&width=400&height=250&seq=skoda-enyaq-rel&orientation=landscape' },
      { slug: 'skoda-enyaq-iv-60', name: 'Enyaq iV 60', price: '429€/mes', image: 'https://readdy.ai/api/search-image?query=Skoda%20Enyaq%20iV%2060%20electric%20SUV%20in%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20affordable%20crossover&width=400&height=250&seq=skoda-enyaq-60-rel2&orientation=landscape' },
      { slug: 'cupra-tavascan-vz', name: 'CUPRA Tavascan', price: '649€/mes', image: 'https://readdy.ai/api/search-image?query=CUPRA%20Tavascan%20electric%20coupe%20SUV%20in%20dark%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20crossover&width=400&height=250&seq=cupra-tavascan-rel5&orientation=landscape' }
    ]
  },
  'skoda-enyaq-iv-60': {
    brand: 'Skoda',
    name: 'Enyaq iV 60',
    type: '100% Eléctrico',
    price: '429€',
    pvp: '46.400€',
    badge: 'Mejor precio',
    tagline: 'SUV eléctrico accesible · 180 CV · Etiqueta CERO',
    image: 'https://readdy.ai/api/search-image?query=Skoda%20Enyaq%20iV%2060%20electric%20SUV%20in%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20affordable%20crossover&width=800&height=500&seq=skoda-enyaq-60-detail&orientation=landscape',
    gallery: [
      'https://readdy.ai/api/search-image?query=Skoda%20Enyaq%20iV%2060%20electric%20SUV%20in%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20affordable%20crossover&width=900&height=600&seq=skoda-enyaq-60-g1&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Skoda%20Enyaq%20iV%2060%20rear%20view%20white%20studio%20background%20showing%20LED%20lights&width=900&height=600&seq=skoda-enyaq-60-g2&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Skoda%20Enyaq%20iV%2060%20interior%20practical%20cabin%20digital%20displays&width=900&height=600&seq=skoda-enyaq-60-g3&orientation=landscape',
      'https://readdy.ai/api/search-image?query=Skoda%20Enyaq%20iV%2060%20side%20profile%20white%20showing%20SUV%20proportions&width=900&height=600&seq=skoda-enyaq-60-g4&orientation=landscape'
    ],
    specs: {
      motor: {
        motorizacion: 'Motor eléctrico trasero',
        potencia: '180 CV (132 kW)',
        parMaximo: '310 Nm',
        transmision: 'Automática 1 velocidad',
        traccion: 'Trasera',
        aceleracion: '9.0 s (0-100 km/h)',
        velocidadMaxima: '160 km/h'
      },
      bateria: {
        capacidad: '62 kWh (neta)',
        autonomia: '417 km WLTP',
        cargaRapidaDC: '36 min (10-80%)',
        cargaAC: '11 kW',
        potenciaCargaDC: '120 kW',
        consumo: '15.9 kWh/100km'
      },
      dimensiones: {
        longitud: '4.649 mm',
        anchura: '1.879 mm',
        altura: '1.616 mm',
        batalla: '2.765 mm',
        maletero: '585 - 1.710 litros',
        peso: '1.990 kg',
        plazas: '5',
        puertas: '5'
      }
    },
    equipamiento: {
      exterior: ['Faros LED', 'Pilotos LED', 'Llantas 19"', 'Barras de techo', 'Cristales tintados', 'Portón eléctrico'],
      interior: ['Digital Cockpit 5.3"', 'Pantalla 13"', 'Climatizador bizona', 'Volante multifunción', 'Asientos ergonómicos', 'Iluminación ambiental'],
      tecnologia: ['Skoda Connect', 'Apple CarPlay / Android Auto', 'Navegación', 'Sistema de sonido', 'Carga inalámbrica', 'Asistente de voz'],
      seguridad: ['Front Assist', 'Lane Assist', 'ACC', 'Park Assist', '9 airbags', 'Cámara trasera']
    },
    ventajas: [
      { icon: 'ri-money-euro-circle-line', title: 'Mejor precio', desc: 'El SUV eléctrico más accesible del grupo Volkswagen' },
      { icon: 'ri-space', title: 'Máximo espacio', desc: 'El mismo espacio interior que el Enyaq 80 a menor precio' },
      { icon: 'ri-leaf-line', title: 'Etiqueta CERO', desc: 'Acceso libre a zonas de bajas emisiones y ventajas fiscales' },
      { icon: 'ri-battery-2-charge-line', title: 'Autonomía suficiente', desc: '417 km ideales para uso urbano y periurbano' }
    ],
    related: [
      { slug: 'skoda-enyaq-iv-80', name: 'Enyaq iV 80', price: '499€/mes', image: 'https://readdy.ai/api/search-image?query=Skoda%20Enyaq%20iV%20electric%20SUV%20in%20green%20metallic%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20family%20crossover&width=400&height=250&seq=skoda-enyaq-rel2&orientation=landscape' },
      { slug: 'skoda-enyaq-coupe-rs', name: 'Enyaq Coupé RS', price: '649€/mes', image: 'https://readdy.ai/api/search-image?query=Skoda%20Enyaq%20Coupe%20RS%20electric%20SUV%20coupe%20in%20black%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20sporty%20design&width=400&height=250&seq=skoda-enyaq-coupe-rel2&orientation=landscape' },
      { slug: 'volkswagen-id3-pro', name: 'VW ID.3 Pro', price: '399€/mes', image: 'https://readdy.ai/api/search-image?query=Volkswagen%20ID3%20electric%20hatchback%20in%20white%20color%20on%20clean%20studio%20background%20professional%20automotive%20photography%20front%20three%20quarter%20view%20modern%20compact%20electric%20car&width=400&height=250&seq=vw-id3-rel4&orientation=landscape' }
    ]
  }
};

interface VehicleDetailPageProps {
  slug: string;
}

export default function VehicleDetailPage({ slug }: VehicleDetailPageProps) {
  const [selectedImage, setSelectedImage] = useState(0);
  const [selectedKm, setSelectedKm] = useState('15000');
  const [selectedMonths, setSelectedMonths] = useState('48');
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);

  const vehicle = electricVehicles[slug];

  if (!vehicle) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold text-gray-900 mb-4">Vehículo no encontrado</h1>
          <Link href="/promociones-electricos" className="text-[#ad023b] hover:underline">
            Volver a vehículos eléctricos
          </Link>
        </div>
      </div>
    );
  }

  const faqs = [
    { q: '¿Qué incluye exactamente la cuota de renting?', a: 'La cuota incluye mantenimiento oficial, seguro a todo riesgo, impuestos, asistencia en carretera 24h y cambio de neumáticos por desgaste.' },
    { q: '¿Puedo personalizar el equipamiento del vehículo?', a: 'Sí, puedes añadir opcionales y packs de equipamiento. Contacta con nosotros para configurar tu vehículo ideal.' },
    { q: '¿Qué ocurre si supero el kilometraje contratado?', a: 'El exceso de kilometraje se factura según tarifa vigente. Consulta con tu asesor las tarifas aplicables.' },
    { q: '¿Cuánto tarda en llegar el vehículo?', a: 'El plazo de entrega varía según disponibilidad. Consulta plazos actualizados con tu asesor comercial.' },
    { q: '¿El renting es deducible fiscalmente para mi empresa?', a: 'Sí, la cuota de renting es 100% deducible como gasto para empresas y autónomos.' }
  ];

  return (
    <div className="bg-white">
      <section className="relative bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 py-16 overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 w-64 h-64 bg-green-500 rounded-full blur-3xl"></div>
          <div className="absolute bottom-10 right-10 w-64 h-64 bg-green-500 rounded-full blur-3xl"></div>
        </div>
        <div className="max-w-7xl mx-auto px-6 relative z-10">
          <div className="mb-6">
            <Link href="/promociones-electricos" className="inline-flex items-center gap-2 text-white/80 hover:text-white transition-colors cursor-pointer">
              <i className="ri-arrow-left-line"></i>
              Volver a vehículos eléctricos
            </Link>
          </div>
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <div className="inline-block px-4 py-2 bg-green-500/20 backdrop-blur-sm text-green-400 text-sm font-bold rounded-full mb-6 border border-green-500/30">
                <i className="ri-flashlight-line mr-2"></i>100% Eléctrico · Etiqueta CERO
              </div>
              <h1 className="text-4xl md:text-5xl font-bold text-white mb-4 leading-tight">
                {vehicle.brand} {vehicle.name}
              </h1>
              <p className="text-xl text-white/90 mb-8">{vehicle.tagline}</p>
              <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6 mb-8">
                <div className="text-sm text-white/80 mb-2">Renting desde</div>
                <div className="text-5xl font-bold text-white mb-2">{vehicle.price}<span className="text-2xl">/mes</span></div>
                <div className="text-sm text-white/70">IVA incluido · 48 meses · 15.000 km/año</div>
              </div>
              <div className="flex flex-col sm:flex-row gap-4">
                <a href="#configurador" className="inline-flex items-center justify-center gap-2 bg-green-500 text-white px-8 py-4 rounded-lg font-bold hover:bg-green-600 transition-all shadow-xl cursor-pointer whitespace-nowrap">
                  <i className="ri-settings-3-line"></i>
                  Personalizar cuota
                </a>
                <a href="https://wa.me/34955034600" target="_blank" rel="noopener noreferrer" className="inline-flex items-center justify-center gap-2 bg-[#25D366] text-white px-8 py-4 rounded-lg font-bold hover:bg-[#20BD5A] transition-all shadow-xl cursor-pointer whitespace-nowrap">
                  <i className="ri-whatsapp-line text-xl"></i>
                  Hablar con un asesor
                </a>
              </div>
            </div>
            <div className="relative">
              <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10">
                <img
                  alt={`${vehicle.brand} ${vehicle.name}`}
                  className="w-full h-auto rounded-lg"
                  src={vehicle.image}
                />
              </div>
              <div className="absolute top-4 right-4 bg-[#ad023b] text-white px-4 py-2 rounded-full text-sm font-bold shadow-lg">
                {vehicle.badge}
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-6 py-12">
        <div className="bg-slate-50 rounded-2xl p-6">
          <div className="w-full h-[400px] md:h-[500px] bg-white rounded-xl overflow-hidden mb-4">
            <img
              alt={`${vehicle.brand} ${vehicle.name}`}
              className="w-full h-full object-contain"
              src={vehicle.gallery[selectedImage]}
            />
          </div>
          <div className="grid grid-cols-4 gap-3">
            {vehicle.gallery.map((img: string, idx: number) => (
              <button
                key={idx}
                onClick={() => setSelectedImage(idx)}
                className={`w-full h-20 md:h-24 rounded-lg overflow-hidden border-2 transition-all cursor-pointer ${selectedImage === idx ? 'border-green-500 shadow-lg' : 'border-transparent hover:border-slate-300'}`}
              >
                <img alt={`Vista ${idx + 1}`} className="w-full h-full object-cover" src={img} />
              </button>
            ))}
          </div>
        </div>
      </section>

      <section id="configurador" className="max-w-5xl mx-auto px-6 py-16">
        <div className="bg-gradient-to-br from-slate-50 to-white border-2 border-slate-200 rounded-2xl p-8 md:p-12">
          <div className="text-center mb-10">
            <h2 className="text-3xl font-bold text-slate-900 mb-3">Configura tu cuota personalizada</h2>
            <p className="text-slate-600">Ajusta el kilometraje y la duración según las necesidades de tu empresa</p>
          </div>
          <div className="grid md:grid-cols-2 gap-8 mb-10">
            <div>
              <label className="block text-sm font-bold text-slate-900 mb-4">
                <i className="ri-speed-line mr-2 text-green-500"></i>Kilometraje anual
              </label>
              <div className="space-y-3">
                {['10000', '15000', '20000', '25000', '30000'].map((km) => (
                  <button
                    key={km}
                    onClick={() => setSelectedKm(km)}
                    className={`w-full px-6 py-4 rounded-lg font-semibold transition-all cursor-pointer whitespace-nowrap ${selectedKm === km ? 'bg-slate-900 text-white shadow-lg scale-105' : 'bg-white text-slate-700 border-2 border-slate-200 hover:border-slate-900'}`}
                  >
                    {parseInt(km).toLocaleString()} km/año
                  </button>
                ))}
              </div>
            </div>
            <div>
              <label className="block text-sm font-bold text-slate-900 mb-4">
                <i className="ri-calendar-line mr-2 text-green-500"></i>Duración del contrato
              </label>
              <div className="space-y-3">
                {['36', '48', '60'].map((months) => (
                  <button
                    key={months}
                    onClick={() => setSelectedMonths(months)}
                    className={`w-full px-6 py-4 rounded-lg font-semibold transition-all cursor-pointer whitespace-nowrap ${selectedMonths === months ? 'bg-slate-900 text-white shadow-lg scale-105' : 'bg-white text-slate-700 border-2 border-slate-200 hover:border-slate-900'}`}
                  >
                    {months} meses
                  </button>
                ))}
              </div>
            </div>
          </div>
          <div className="bg-gradient-to-br from-green-600 to-green-700 rounded-2xl p-8 text-center">
            <div className="text-white/80 text-sm mb-2">Tu cuota personalizada</div>
            <div className="text-6xl font-bold text-white mb-3">{vehicle.price}<span className="text-3xl">/mes</span></div>
            <div className="text-white/70 mb-6">IVA incluido · {selectedMonths} meses · {parseInt(selectedKm).toLocaleString()} km/año</div>
            <p className="text-sm text-white/60 max-w-2xl mx-auto">
              La cuota puede variar según kilometraje y duración del contrato. Esta es una estimación orientativa. Contacta con nosotros para una oferta personalizada definitiva.
            </p>
          </div>
        </div>
      </section>

      <section className="bg-slate-50 py-16">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Qué incluye la cuota de renting</h2>
            <p className="text-lg text-slate-600">Todo lo que necesitas para que tu empresa solo se preocupe de conducir</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: 'ri-tools-line', title: 'Mantenimiento oficial', desc: 'Todas las revisiones, cambios de aceite, filtros y piezas de desgaste en talleres oficiales' },
              { icon: 'ri-shield-check-line', title: 'Seguro a todo riesgo', desc: 'Cobertura completa con franquicia reducida, asistencia en viaje 24h y vehículo de sustitución' },
              { icon: 'ri-steering-2-line', title: 'Neumáticos', desc: 'Cambio de neumáticos por desgaste normal, equilibrado y alineación incluidos' },
              { icon: 'ri-file-text-line', title: 'Impuestos', desc: 'Impuesto de circulación y tasas administrativas incluidas en la cuota mensual' },
              { icon: 'ri-roadster-line', title: 'Asistencia en carretera', desc: 'Servicio 24/7 en toda Europa, grúa, reparaciones de emergencia y gestión de incidencias' },
              { icon: 'ri-money-euro-circle-line', title: '100% deducible', desc: 'La cuota de renting es gasto deducible al 100% para tu empresa, optimizando la fiscalidad' }
            ].map((item, idx) => (
              <div key={idx} className="bg-white rounded-xl p-6 border border-slate-200">
                <div className="w-14 h-14 bg-gradient-to-br from-green-500 to-green-600 rounded-xl flex items-center justify-center mb-4">
                  <i className={`${item.icon} text-2xl text-white`}></i>
                </div>
                <h3 className="text-lg font-bold text-slate-900 mb-2">{item.title}</h3>
                <p className="text-slate-600 text-sm">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="max-w-7xl mx-auto px-6 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Equipamiento de serie</h2>
          <p className="text-lg text-slate-600">Todo lo que incluye el {vehicle.brand} {vehicle.name} de serie</p>
        </div>
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {Object.entries(vehicle.equipamiento).map(([category, items]: [string, any]) => (
            <div key={category} className="bg-white border border-slate-200 rounded-xl p-6">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 bg-slate-900 rounded-lg flex items-center justify-center">
                  <i className={`${category === 'exterior' ? 'ri-car-line' : category === 'interior' ? 'ri-steering-line' : category === 'tecnologia' ? 'ri-smartphone-line' : 'ri-shield-star-line'} text-white`}></i>
                </div>
                <h3 className="font-bold text-slate-900 capitalize">{category}</h3>
              </div>
              <ul className="space-y-2 text-sm text-slate-600">
                {items.map((item: string, idx: number) => (
                  <li key={idx} className="flex items-start gap-2">
                    <i className="ri-check-line text-green-500 mt-0.5"></i>
                    {item}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-slate-50 py-16">
        <div className="max-w-5xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-slate-900 mb-4">Ficha técnica completa</h2>
            <p className="text-lg text-slate-600">Especificaciones detalladas del {vehicle.brand} {vehicle.name}</p>
          </div>
          <div className="bg-white border border-slate-200 rounded-2xl overflow-hidden">
            {Object.entries(vehicle.specs).map(([section, specs]: [string, any]) => (
              <div key={section} className="border-b border-slate-200 last:border-b-0">
                <div className="bg-slate-900 px-6 py-4">
                  <h3 className="text-white font-bold flex items-center gap-2">
                    <i className={`${section === 'motor' ? 'ri-dashboard-3-line' : section === 'bateria' ? 'ri-battery-2-charge-line' : 'ri-ruler-line'}`}></i>
                    {section === 'motor' ? 'Motor y Rendimiento' : section === 'bateria' ? 'Batería y Carga' : 'Dimensiones y Capacidades'}
                  </h3>
                </div>
                <div className="divide-y divide-slate-100">
                  {Object.entries(specs).map(([key, value]: [string, any]) => (
                    <div key={key} className="flex justify-between px-6 py-4">
                      <span className="text-slate-600 capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}</span>
                      <span className="font-semibold text-slate-900">{value}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-gradient-to-br from-green-600 to-green-700 py-16">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-white mb-4">Por qué el {vehicle.brand} {vehicle.name} es perfecto para tu empresa</h2>
            <p className="text-lg text-white/80">Ventajas específicas para flotas y uso profesional</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {vehicle.ventajas.map((v: any, idx: number) => (
              <div key={idx} className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-6">
                <div className="w-12 h-12 bg-white/20 rounded-lg flex items-center justify-center mb-4">
                  <i className={`${v.icon} text-2xl text-white`}></i>
                </div>
                <h3 className="text-lg font-bold text-white mb-2">{v.title}</h3>
                <p className="text-white/80 text-sm">{v.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="max-w-4xl mx-auto px-6 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Preguntas frecuentes</h2>
          <p className="text-lg text-slate-600">Resolvemos tus dudas sobre el renting del {vehicle.brand} {vehicle.name}</p>
        </div>
        <div className="space-y-4">
          {faqs.map((faq, idx) => (
            <div key={idx} className="bg-white border border-slate-200 rounded-xl overflow-hidden">
              <button
                onClick={() => setExpandedFaq(expandedFaq === idx ? null : idx)}
                className="w-full px-6 py-5 flex items-center justify-between text-left cursor-pointer hover:bg-slate-50 transition-colors"
              >
                <span className="font-semibold text-slate-900 pr-4">{faq.q}</span>
                <i className={`ri-arrow-${expandedFaq === idx ? 'up' : 'down'}-s-line text-2xl text-slate-400 transition-transform`}></i>
              </button>
              {expandedFaq === idx && (
                <div className="px-6 pb-5 text-slate-600">
                  {faq.a}
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      <VehicleContactForm 
        vehicleName={vehicle.name} 
        vehicleBrand={vehicle.brand} 
        accentColor="green" 
      />

      <section className="max-w-7xl mx-auto px-6 py-16">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-slate-900 mb-4">Otros vehículos eléctricos que pueden interesarte</h2>
        </div>
        <div className="grid md:grid-cols-3 gap-6">
          {vehicle.related.map((rel: any) => (
            <Link
              key={rel.slug}
              href={`/vehiculos/electricos/${rel.slug}`}
              className="bg-white border-2 border-slate-200 rounded-xl overflow-hidden hover:border-green-500 transition-all hover:shadow-xl cursor-pointer"
            >
              <div className="w-full h-48 bg-slate-100">
                <img alt={rel.name} className="w-full h-full object-contain" src={rel.image} />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-slate-900 mb-2">{rel.name}</h3>
                <div className="text-2xl font-bold text-green-600 mb-2">desde {rel.price}</div>
                <p className="text-slate-600 text-sm">100% Eléctrico · Etiqueta CERO</p>
              </div>
            </Link>
          ))}
        </div>
        <div className="text-center mt-10">
          <Link href="/promociones-electricos" className="inline-flex items-center gap-2 text-slate-900 font-bold hover:text-green-600 transition-colors cursor-pointer">
            Ver todos los vehículos eléctricos
            <i className="ri-arrow-right-line"></i>
          </Link>
        </div>
      </section>

      <section className="max-w-5xl mx-auto px-6 py-12">
        <div className="bg-slate-100 rounded-xl p-6">
          <h3 className="font-bold text-slate-900 mb-4 flex items-center gap-2">
            <i className="ri-information-line"></i>
            Condiciones de la oferta
          </h3>
          <div className="text-xs text-slate-600 space-y-2 leading-relaxed">
            <p><strong>Oferta válida para empresas y autónomos.</strong> Cuota mensual de renting operativo, IVA incluido. Oferta sujeta a aprobación crediticia por parte de la entidad financiera.</p>
            <p>La cuota incluye: mantenimiento oficial, seguro a todo riesgo con franquicia, impuesto de circulación, gestión de multas, asistencia en carretera 24h y cambio de neumáticos por desgaste. No incluye electricidad.</p>
            <p>Condiciones base: 48 meses de contrato, 15.000 km/año. El exceso de kilometraje se facturará según tarifa vigente. La cuota puede variar en función del color, equipamiento opcional y condiciones de financiación.</p>
            <p>Imágenes no contractuales. El equipamiento puede variar según versión y opciones seleccionadas. Consulta disponibilidad de unidades y plazos de entrega con tu asesor comercial.</p>
          </div>
        </div>
      </section>
    </div>
  );
}
