
import VehicleDetailPage from './VehicleDetailPage';

export async function generateStaticParams() {
  return [
    { slug: 'volkswagen-id3-pro' },
    { slug: 'volkswagen-id4-pro' },
    { slug: 'volkswagen-id5-gtx' },
    { slug: 'audi-q4-etron-45' },
    { slug: 'audi-etron-gt-quattro' },
    { slug: 'audi-q8-etron-55' },
    { slug: 'cupra-born-eboost' },
    { slug: 'cupra-tavascan-vz' },
    { slug: 'cupra-born-vz' },
    { slug: 'skoda-enyaq-iv-80' },
    { slug: 'skoda-enyaq-coupe-rs' },
    { slug: 'skoda-enyaq-iv-60' },
  ];
}

export default function ElectricVehiclePage({ params }: { params: { slug: string } }) {
  return <VehicleDetailPage slug={params.slug} />;
}
