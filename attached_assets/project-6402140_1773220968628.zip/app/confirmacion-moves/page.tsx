
import ConfirmacionMovesContent from './ConfirmacionMovesContent';
import { Suspense } from 'react';

export default function ConfirmacionMovesPage() {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center"><div className="animate-spin w-8 h-8 border-4 border-green-600 border-t-transparent rounded-full"></div></div>}>
      <ConfirmacionMovesContent />
    </Suspense>
  );
}
