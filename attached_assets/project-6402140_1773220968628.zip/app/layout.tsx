import type { Metadata, Viewport } from "next";
import { Inter, Playfair_Display } from "next/font/google";
import "./globals.css";
import Script from "next/script";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ScrollToTop from "@/components/ScrollToTop";
import CookieBanner from "@/components/CookieBanner";

const inter = Inter({ 
  subsets: ["latin"],
  variable: "--font-inter",
  display: "swap"
});

const playfair = Playfair_Display({ 
  subsets: ["latin"],
  variable: "--font-playfair",
  display: "swap"
});

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
};

export const metadata: Metadata = {
  title: "Grupo Avisa - Vehículos Eléctricos e Híbridos Enchufables | Concesionario Oficial",
  description: "✓ Concesionario oficial de vehículos eléctricos e híbridos enchufables ✓ Plan MOVES ✓ Financiación flexible ✓ Postventa especializada ✓ Test drive gratuito ✓ Ahorra hasta 7.000€ en ayudas",
  keywords: "coches eléctricos, híbridos enchufables, PHEV, BEV, Plan MOVES, Grupo Avisa, concesionario oficial, vehículos eléctricos Sevilla",
  openGraph: {
    title: "Grupo Avisa - Vehículos Eléctricos e Híbridos Enchufables",
    description: "Concesionario oficial líder en movilidad eléctrica. Amplia gama de vehículos eléctricos e híbridos con Plan MOVES, financiación y postventa especializada.",
    type: "website",
    url: "https://grupoavisa.com/",
    locale: "es_ES",
  },
  twitter: {
    card: "summary_large_image",
    title: "Grupo Avisa - Vehículos Eléctricos e Híbridos Enchufables",
    description: "Concesionario oficial líder en movilidad eléctrica. Amplia gama de vehículos eléctricos e híbridos con Plan MOVES, financiación y postventa especializada.",
  },
  other: {
    "geo.region": "ES-AN",
    "geo.placename": "Sevilla",
    "geo.position": "37.3891;-5.9845",
    "ICBM": "37.3891, -5.9845",
  }
};

const criticalImages = [
  {
    href: "https://readdy.ai/api/search-image?query=modern%20electric%20vehicle%20driving%20on%20scenic%20highway%20with%20sustainable%20green%20landscape%20and%20blue%20sky%20background%20cinematic%20wide%20angle%20view%20emphasizing%20eco-friendly%20transportation%20and%20clean%20energy%20future%20with%20natural%20lighting%20and%20professional%20photography%20style&width=1440&height=580&seq=hero-electric-road-1&orientation=landscape&format=webp",
    as: "image",
    type: "image/webp"
  },
  {
    href: "https://readdy.ai/api/search-image?query=modern%20electric%20vehicle%20charging%20station%20at%20sunset%20with%20sleek%20electric%20car%20connected%20to%20charger%2C%20futuristic%20urban%20environment%20with%20clean%20energy%20infrastructure%2C%20professional%20automotive%20photography%20with%20dramatic%20lighting%20and%20reflections%2C%20premium%20luxury%20feel%20with%20blue%20and%20purple%20ambient%20lighting&width=1440&height=810&seq=promo-electricos-hero-1&orientation=landscape&format=webp",
    as: "image",
    type: "image/webp"
  },
  {
    href: "https://readdy.ai/api/search-image?query=modern%20plug-in%20hybrid%20SUV%20driving%20on%20scenic%20mountain%20road%20at%20golden%20hour%2C%20professional%20automotive%20photography%20with%20dramatic%20lighting%20showing%20eco-friendly%20vehicle%20in%20natural%20environment%2C%20premium%20luxury%20feel%20with%20warm%20sunset%20colors%20and%20motion%20blur&width=1440&height=810&seq=promo-hibridos-hero-1&orientation=landscape&format=webp",
    as: "image",
    type: "image/webp"
  },
  {
    href: "https://readdy.ai/api/search-image?query=Professional%20automotive%20service%20center%20with%20modern%20electric%20vehicle%20being%20serviced%20by%20technicians%20in%20clean%20white%20uniforms%20high%20tech%20diagnostic%20equipment%20bright%20clean%20workshop%20environment%20premium%20car%20dealership%20service%20area&width=1440&height=600&seq=postventa-hero-1&orientation=landscape&format=webp",
    as: "image",
    type: "image/webp"
  },
  {
    href: "https://readdy.ai/api/search-image?query=Modern%20electric%20vehicle%20charging%20station%20with%20sleek%20electric%20car%20connected%20to%20charger%20in%20urban%20setting%20with%20green%20energy%20concept%20clean%20minimalist%20background%20professional%20automotive%20photography%20soft%20natural%20lighting&width=1440&height=600&seq=moves-hero-1&orientation=landscape&format=webp",
    as: "image",
    type: "image/webp"
  }
];

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="es" className={`${inter.variable} ${playfair.variable}`}>
      <head>
        {criticalImages.map((img, index) => (
          <link
            key={index}
            rel="preload"
            href={img.href}
            as={img.as}
            type={img.type}
            fetchPriority={index === 0 ? "high" : "low"}
          />
        ))}
        <link rel="preconnect" href="https://readdy.ai" />
        <link rel="dns-prefetch" href="https://readdy.ai" />
      </head>
      <body className={inter.className}>
        <Header />
        {children}
        <Footer />
        <ScrollToTop />
        <CookieBanner />
        <Script 
          src="https://readdy.ai/api/public/assistant/widget?projectId=39d5a1eb-e93c-4449-94ca-f8a959961b7f"
          strategy="afterInteractive"
          data-mode="hybrid"
          data-voice-show-transcript="true"
          data-theme="light"
          data-size="compact"
          data-accent-color="#ad023b"
          data-button-base-color="#000000"
          data-button-accent-color="#FFFFFF"
        />
      </body>
    </html>
  );
}
