import dynamic from 'next/dynamic';
import Header from '@/components/Header';
import HeroSection from '@/components/home/HeroSection';
import VehicleSelector from '@/components/home/VehicleSelector';
import ScrollToTop from '@/components/ScrollToTop';

const ElectricPromotions = dynamic(() => import('@/components/home/ElectricPromotions'), {
  loading: () => <div className="h-96 bg-gray-50 animate-pulse" />
});

const HybridPromotions = dynamic(() => import('@/components/home/HybridPromotions'), {
  loading: () => <div className="h-96 bg-gray-50 animate-pulse" />
});

const PostventaSection = dynamic(() => import('@/components/home/PostventaSection'), {
  loading: () => <div className="h-96 bg-gray-50 animate-pulse" />
});

const PlanMovesSection = dynamic(() => import('@/components/home/PlanMovesSection'), {
  loading: () => <div className="h-96 bg-gray-50 animate-pulse" />
});

const FAQSection = dynamic(() => import('@/components/home/FAQSection'), {
  loading: () => <div className="h-96 bg-gray-50 animate-pulse" />
});

const DealerMapSection = dynamic(() => import('@/components/home/DealerMapSection'), {
  loading: () => <div className="h-96 bg-gray-50 animate-pulse" />
});

const MyBusinessSection = dynamic(() => import('@/components/home/MyBusinessSection'), {
  loading: () => <div className="h-96 bg-gray-50 animate-pulse" />
});

const CTASection = dynamic(() => import('@/components/home/CTASection'), {
  loading: () => <div className="h-48 bg-gray-50 animate-pulse" />
});

const ContactSection = dynamic(() => import('@/components/home/ContactSection'), {
  loading: () => <div className="h-96 bg-gray-50 animate-pulse" />
});

export default function Home() {
  return (
    <>
      <Header />
      <main className="pt-[120px]">
        <HeroSection />
        <VehicleSelector />
        <ElectricPromotions />
        <HybridPromotions />
        <PostventaSection />
        <PlanMovesSection />
        <FAQSection />
        <DealerMapSection />
        <MyBusinessSection />
        <CTASection />
        <ContactSection />
      </main>
      <ScrollToTop />
    </>
  );
}
