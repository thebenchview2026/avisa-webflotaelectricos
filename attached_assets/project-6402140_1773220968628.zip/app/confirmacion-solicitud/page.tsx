
import ConfirmacionContent from './ConfirmacionContent';
import { Suspense } from 'react';

export default function ConfirmacionPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-green-500 border-t-transparent rounded-full"></div>
      </div>
    }>
      <ConfirmacionContent />
    </Suspense>
  );
}
