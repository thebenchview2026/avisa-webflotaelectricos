
import ConfirmacionContactoContent from './ConfirmacionContactoContent';
import { Suspense } from 'react';

export default function ConfirmacionContactoPage() {
  return (
    <Suspense fallback={<div className="min-h-screen flex items-center justify-center"><div className="animate-spin w-8 h-8 border-4 border-[#ad023b] border-t-transparent rounded-full"></div></div>}>
      <ConfirmacionContactoContent />
    </Suspense>
  );
}
